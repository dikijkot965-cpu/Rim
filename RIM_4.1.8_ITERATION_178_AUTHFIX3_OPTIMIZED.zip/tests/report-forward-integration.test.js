import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
const root = join(dirname(fileURLToPath(import.meta.url)), '..');
test('app owns report and forward routes', () => {
  const app = readFileSync(join(root, 'src/app.js'), 'utf8');
  const social = readFileSync(join(root, 'src/composition/social-surface.js'), 'utf8');
  assert.match(app, /bindSocialSurface/);
  // class lives in composition modules: // moved to composition: assert.match(app, /ReportService/);
  // class lives in composition modules: // moved to composition: assert.match(app, /ForwardMessageService/);
  assert.match(social, /__RIM_REPORTS_OWNED\s*=\s*true/);
  assert.match(social, /__RIM_FORWARD_OWNED\s*=\s*true/);
  assert.match(social, /rimForwardChoose/);
  assert.match(social, /rimForwardMessage/);
  assert.match(app, /4\.1\.8-iteration\.163/);
});
