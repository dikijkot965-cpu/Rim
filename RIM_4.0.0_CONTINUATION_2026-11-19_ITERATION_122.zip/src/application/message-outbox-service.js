import { Err, Ok } from '../core/result.js';
import {
  createOutboxItem,
  markOutboxSending,
  markOutboxSent,
  markOutboxFailed,
  listRetryable,
  isNetworkLikeError
} from '../domain/outbox.js';

const STORAGE_KEY = 'rim.outbox.v1';

/**
 * Local outbox for text messages when the network fails or the device is offline.
 * Flush is idempotent per item id; successful items are dropped from storage.
 */
export class MessageOutboxService {
  constructor({
    storage = globalThis.localStorage,
    sendText = null,
    notify = () => {},
    logger = null,
    windowRef = globalThis.window
  } = {}) {
    this.storage = storage;
    this.sendText = sendText;
    this.notify = notify;
    this.logger = logger;
    this.window = windowRef;
    this.flushing = false;
    this._onOnline = () => { void this.flush(); };
  }

  #read() {
    try {
      const raw = this.storage?.getItem?.(STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  #write(items) {
    try {
      const live = (items || []).filter(i => i && i.status !== 'sent');
      this.storage?.setItem?.(STORAGE_KEY, JSON.stringify(live));
    } catch (error) {
      this.logger?.warn?.('outbox.persist.failed', error);
    }
  }

  list() {
    return this.#read();
  }

  listForConversation(conversationId) {
    const id = String(conversationId || '');
    return this.#read().filter(i => i && String(i.conversationId) === id && i.status !== 'sent');
  }

  toLocalMessages(conversationId, userId) {
    return this.listForConversation(conversationId).map(item => ({
      id: `outbox:${item.id}`,
      conversation_id: item.conversationId,
      sender_id: userId,
      body: item.body,
      created_at: new Date(item.clientCreatedAt || Date.now()).toISOString(),
      clientCreatedAt: item.clientCreatedAt,
      _rimOutboxPending: true,
      _rimOutboxId: item.id,
      _rimOutboxStatus: item.status
    }));
  }

  enqueueText({ conversationId, body, replyToMessageId = null, topicId = null }) {
    const created = createOutboxItem({
      conversationId,
      body,
      replyToMessageId,
      topicId
    });
    if (!created.ok) return Err(new Error(created.error));
    const items = this.#read();
    items.push(created.value);
    this.#write(items);
    this.logger?.info?.('outbox.enqueued', { id: created.value.id, conversationId });
    return Ok(created.value);
  }

  async flush() {
    if (this.flushing) return Ok({ skipped: true });
    if (!this.sendText) return Err(new Error('sendText не привязан к outbox.'));
    if (this.window?.navigator && this.window.navigator.onLine === false) {
      return Ok({ offline: true });
    }
    this.flushing = true;
    try {
      let items = this.#read();
      const retryable = listRetryable(items);
      let sent = 0;
      for (const item of retryable) {
        const sending = markOutboxSending(item);
        if (!sending.ok) continue;
        items = items.map(i => (i.id === item.id ? sending.value : i));
        this.#write(items);
        try {
          const result = await this.sendText(item.body, {
            conversationId: item.conversationId,
            replyToMessageId: item.replyToMessageId,
            topicId: item.topicId,
            fromOutbox: true,
            outboxId: item.id,
            skipPolicy: true
          });
          if (result && result.ok === false) {
            throw result.error || new Error('Не удалось отправить из outbox.');
          }
          const done = markOutboxSent(sending.value);
          items = items.filter(i => i.id !== item.id);
          this.#write(items);
          sent += 1;
          this.logger?.info?.('outbox.sent', { id: item.id });
        } catch (error) {
          const failed = markOutboxFailed(sending.value, error?.message || error);
          items = items.map(i => (i.id === item.id ? failed.value : i));
          this.#write(items);
          this.logger?.warn?.('outbox.item.failed', { id: item.id, message: error?.message });
          if (!isNetworkLikeError(error)) {
            // permanent-ish failure: keep failed for manual retry, continue others
            continue;
          }
          // network: stop flush to avoid tight loop
          break;
        }
      }
      return Ok({ sent, remaining: listRetryable(this.#read()).length });
    } finally {
      this.flushing = false;
    }
  }

  bindOnlineListener() {
    try {
      this.window?.addEventListener?.('online', this._onOnline);
    } catch { /* ignore */ }
  }

  dispose() {
    try {
      this.window?.removeEventListener?.('online', this._onOnline);
    } catch { /* ignore */ }
  }
}

export { isNetworkLikeError };
