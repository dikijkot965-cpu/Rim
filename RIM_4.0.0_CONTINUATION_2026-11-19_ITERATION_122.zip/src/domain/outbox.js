/**
 * Pure outbox / offline-queue rules for message sends.
 * Persistence and network live outside this module.
 */

export const OUTBOX_STATUSES = Object.freeze([
  'pending',
  'sending',
  'sent',
  'failed'
]);

/**
 * @param {object} input
 * @returns {{ ok: true, value: object } | { ok: false, error: string }}
 */
export function createOutboxItem(input = {}) {
  const conversationId = String(input.conversationId || '').trim();
  const body = String(input.body || '').trim();
  if (!conversationId) return { ok: false, error: 'Нет conversationId для outbox.' };
  if (!body) return { ok: false, error: 'Пустое тело нельзя ставить в очередь.' };
  const id = String(input.id || `obx_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`);
  return {
    ok: true,
    value: Object.freeze({
      id,
      conversationId,
      body,
      replyToMessageId: input.replyToMessageId ? String(input.replyToMessageId) : null,
      topicId: input.topicId ? String(input.topicId) : null,
      clientCreatedAt: Number(input.clientCreatedAt) || Date.now(),
      status: 'pending',
      attempts: 0,
      lastError: null
    })
  };
}

export function markOutboxSending(item) {
  if (!item?.id) return { ok: false, error: 'Нет элемента outbox.' };
  if (item.status === 'sent') return { ok: false, error: 'Уже отправлено.' };
  return {
    ok: true,
    value: Object.freeze({
      ...item,
      status: 'sending',
      attempts: Number(item.attempts || 0) + 1
    })
  };
}

export function markOutboxSent(item) {
  if (!item?.id) return { ok: false, error: 'Нет элемента outbox.' };
  return {
    ok: true,
    value: Object.freeze({
      ...item,
      status: 'sent',
      lastError: null,
      sentAt: Date.now()
    })
  };
}

export function markOutboxFailed(item, errorMessage) {
  if (!item?.id) return { ok: false, error: 'Нет элемента outbox.' };
  return {
    ok: true,
    value: Object.freeze({
      ...item,
      status: 'failed',
      lastError: String(errorMessage || 'Ошибка отправки')
    })
  };
}

export function listRetryable(items) {
  return (items || []).filter(i => i && (i.status === 'pending' || i.status === 'failed'));
}

export function isNetworkLikeError(error) {
  const msg = String(error?.message || error || '').toLowerCase();
  if (!msg) return false;
  return /network|fetch|offline|failed to fetch|timeout|econn|socket|temporar|503|502|504/.test(msg);
}
