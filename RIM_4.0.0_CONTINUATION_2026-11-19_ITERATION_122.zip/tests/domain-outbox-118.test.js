import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createOutboxItem,
  markOutboxSending,
  markOutboxSent,
  markOutboxFailed,
  listRetryable,
  isNetworkLikeError
} from '../src/domain/outbox.js';
import { MessageOutboxService } from '../src/application/message-outbox-service.js';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

test('outbox item lifecycle', () => {
  const created = createOutboxItem({ conversationId: 'c1', body: 'Слава' });
  assert.equal(created.ok, true);
  const sending = markOutboxSending(created.value);
  assert.equal(sending.value.status, 'sending');
  assert.equal(sending.value.attempts, 1);
  const sent = markOutboxSent(sending.value);
  assert.equal(sent.value.status, 'sent');
  const failed = markOutboxFailed(sending.value, 'offline');
  assert.equal(failed.value.status, 'failed');
  assert.equal(listRetryable([created.value, failed.value]).length, 2);
});

test('network error detection', () => {
  assert.equal(isNetworkLikeError(new Error('Failed to fetch')), true);
  assert.equal(isNetworkLikeError(new Error('validation failed')), false);
});

test('MessageOutboxService persists and flushes', async () => {
  const mem = {
    data: {},
    getItem(k) { return this.data[k] ?? null; },
    setItem(k, v) { this.data[k] = String(v); }
  };
  let calls = 0;
  const service = new MessageOutboxService({
    storage: mem,
    sendText: async (body) => {
      calls += 1;
      assert.equal(body, 'Привет');
      return { ok: true, value: { id: 'm1' } };
    },
    windowRef: { navigator: { onLine: true }, addEventListener() {}, removeEventListener() {} }
  });
  const queued = service.enqueueText({ conversationId: 'c1', body: 'Привет' });
  assert.equal(queued.ok, true);
  assert.equal(service.list().length, 1);
  const flushed = await service.flush();
  assert.equal(flushed.ok, true);
  assert.equal(calls, 1);
  assert.equal(service.list().length, 0);
});

test('surface owns outbox flag', () => {
  const src = readFileSync(join(root, 'src/composition/message-commands-surface.js'), 'utf8');
  assert.match(src, /MessageOutboxService/);
  assert.match(src, /__RIM_MESSAGE_OUTBOX_OWNED/);
  assert.match(src, /isNetworkLikeError/);
});
