# Императорский Мессенджер (RIM) — инженерная сборка 4.0.0 (итерация 17)

Это продолжение существующего RIM, а не отдельный новый мессенджер. Сохранены исходный имперский интерфейс, HTML-структура основных экранов, Supabase и совместимость с прежними функциями. Работа ведётся вертикальными инженерными срезами: новая логика переносится в модули, а старый интерфейс остаётся совместимым до подтверждения паритета.

## Что уже перенесено в модульный runtime

- **Личные переписки:** пакетное разрешение собеседников, имён и аватаров; защита от устаревших ответов.
- **История сообщений:** загрузка последних 50 сообщений, курсорная подгрузка старых, инкрементальная обработка Realtime INSERT/UPDATE/DELETE.
- **Команды сообщений:** текст, стикеры, изображения, редактирование и удаление проходят через `MessageCommandService`; старый renderer и разметка composer сохранены.
- **Команды сообщений — защита:** проверка длины текста, MIME/размера фото, блокировка параллельных повторных нажатий, привязка мутаций к текущей переписке и автору.
- **Изображения:** загрузка в `chat-files` с неперезаписывающим UUID-путём; при ошибке записи сообщения предпринимается очистка только что загруженного объекта.
- **Lite Writer:** модульный редактор без обязательного CDN-бандла, список документов, создание, выбор, сохранение и локальный fallback.
- **Избранное и локальная музыка:** вынесены в отдельные feature-модули.
- **Инфраструктура:** контейнер зависимостей, события, журналирование, health checks, disposable lifecycle и единая граница совместимости с legacy.

- **Legacy loader unification:** поздний `rimLoadMessagesStable`, который реально вызывался при открытии чата, теперь направлен в модульный курсорный загрузчик. Старый параллельный загрузчик больше не выполняет отдельный запрос `SELECT *` перед модульной историей.
- **Realtime race protection:** события, пришедшие во время запроса истории или catch-up, повторно применяются к результату чтения; поколение запроса отделено от срока жизни Realtime-подписки.
- **Chat-list query reduction:** удалён устаревший legacy-резолвер собеседников, который делал отдельные запросы участников и профилей. Эту задачу выполняет модульный контроллер; загрузка списка не запрашивает last-seen, а открытие уже разрешённого личного чата обновляет только присутствие.
- **Channel feed staged loading:** заголовок и ограниченная первая страница канала отображаются до загрузки реакций, голосов, авторов и рекламы; комментарии загружаются отдельно только при раскрытии конкретной публикации. Добавлена защита от устаревших ответов при переключении каналов.

## Проверка текущей сборки

Из корня проекта:

```bash
npm run verify
```

Последняя проверка (итерация 17):
- project integrity check — PASS, 34 модуля в карте и 24 legacy-скрипта;
- syntax check — PASS, 93 JavaScript-файла;
- Node test suite — 156 passed, 0 failed.

Это автоматические проверки модулей и репозитория. Они не заменяют запуск в браузере с двумя реальными аккаунтами и проверку на Android.

## Supabase и ограничения

- Выполнена read-only проверка схемы и политик, относящихся к `chat_messages`, `user_blocks` и Storage bucket `chat-files`.
- В рабочую базу не применялись SQL, миграции, изменения RLS, Storage или Auth.
- Проверка блокировки личных сообщений видит блокировки, созданные текущим пользователем. Политика `user_blocks` не раскрывает чужие блокировки; проверять их на клиенте нельзя без отдельного серверного контракта.
- Защита от повторного одновременного нажатия действует в одной вкладке. Durable exactly-once после сетевого таймаута не реализован: для него нужна отдельная схема idempotency key и серверная транзакционная логика.
- Не проводились Android/two-account E2E и нагрузочные испытания. Нет сертификации на 10 000 одновременных активных пользователей.

## Полная спецификация и учёт миграции

- `docs/RIM_4.0.0_EXECUTION_SPEC.md` — целевая архитектура и этапы миграции.
- `docs/FEATURE_PARITY_MATRIX.md` — реестр функций и их статуса.
- `docs/BASELINE_3.1.0_PRESERVATION_MANIFEST.md` — исходная база сохранения.
- `docs/SUPABASE_PRODUCTION_AUDIT_2026-11-13.md` — предыдущий аудит Supabase.
- `docs/RIM_4.0.0_ITERATION_3_REPORT.md` — отчёт предыдущего прохода.
- `docs/RIM_4.0.0_ITERATION_17_REPORT.md` — подробный отчёт текущего прохода.
- `NEXT_CHAT_HANDOFF.md` — инструкция и точка продолжения в новом чате.

## Важное ограничение объёма

Это не завершённая полная перепись всех legacy-скриптов и не заявление о production-ready. Существующие legacy-модули продолжают обслуживать значительную часть функций ради сохранения поведения. Каждый следующий срез должен мигрировать функциональность с тестами и проверкой совместимости, а не удалять старые механизмы вслепую.


## Iteration 6 — conversation state projection

The application layer now owns conversation activity ordering, unread counters, latest-message previews, read cursor writes, and chat-list/read-state Realtime projection. Unread cursor rows are fetched once; exact per-conversation counts run with bounded concurrency to avoid the former sequential N+1 latency chain. Read cursors use the timestamp of the newest loaded message, not the wall clock, so messages arriving after the loaded page are not silently marked read. The old unread-count, sort-wrapper and chat-list Realtime blocks were removed from three legacy files. The 25 legacy script files themselves remain until their remaining responsibilities have been migrated and verified; no wholesale deletion was performed.


Legacy retirement in iteration 6: one fully unused decorative legacy script was deleted and its `<script>` tag removed (the related ornament layer is globally hidden by the existing stylesheet). The legacy chain is now 24 files rather than 25. Additional duplicate unread, sort and list-Realtime code was removed from three legacy files and the separate `rim-core-release.js`; its remaining presence, typing, voice, music and channel-settings functions stay active until their own migration is complete.

## Iteration 8 — channel directory migration

The channel directory's read model and subscription filter now live in `src/application/channel-directory-controller.js` and `src/infrastructure/supabase/channel-repository.js`. The existing channel-list classes, labels and open/join commands are preserved. The directory uses actual `channel_members` rows for subscription state, selects only the five fields it renders, escapes dynamic values, and ignores stale requests. Legacy `17` still contains join/leave RPCs, moderation, settings and admin utilities; all 24 legacy scripts remain loaded. See `docs/RIM_4.0.0_ITERATION_8_REPORT.md` and `NEXT_CHAT_HANDOFF.md`.


## Текущее состояние — итерация 17

- Активный чат и сброс reply-target фиксируются через `ConversationNavigationController`; устаревшая навигация не может перезаписать более новую.
- Подгрузка старой истории блокируется отдельно для каждой переписки.
- Замена Realtime-подписок защищена от гонок при быстром переключении чатов.
- `npm run verify`: 156 тестов пройдены; синтаксис проверен в 93 JavaScript-файлах.
- Браузерная E2E-проверка и проверка реального Supabase в этой итерации не выполнялись.
