import test from 'node:test';
import assert from 'node:assert/strict';
import { ConversationRepository } from '../src/infrastructure/supabase/conversation-repository.js';

test('privacy projection fails closed when visibility is missing or null', async () => {
  const client = { from(table) { const q = { select() { return q; }, eq() { return q; }, neq() { return q; }, limit() { return Promise.resolve({ data: [{ user_id: 'peer' }], error: null }); }, maybeSingle() { return Promise.resolve({ data: { id: 'peer', display_name: 'Пользователь', show_online: null }, error: null }); } }; return q; } };
  const result = await new ConversationRepository(client).getDirectPeer('c1', 'me');
  assert.equal(result.ok, true);
  assert.equal(result.value.display_name, 'Пользователь');
  assert.equal(result.value.showOnline, false);
});

test('direct peer query returns a missing peer without throwing', async () => {
  const client = { from() { const q = { select() { return q; }, eq() { return q; }, neq() { return q; }, limit() { return Promise.resolve({ data: [], error: null }); } }; return q; } };
  const result = await new ConversationRepository(client).getDirectPeer('c1', 'me');
  assert.deepEqual(result, { ok: true, value: null });
});
