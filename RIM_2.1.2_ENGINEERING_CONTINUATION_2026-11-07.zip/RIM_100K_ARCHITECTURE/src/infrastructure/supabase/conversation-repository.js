import { Err, Ok } from '../../core/result.js';

export class ConversationRepository {
  constructor(client) { this.client = client; }

  async getDirectPeer(conversationId, currentUserId) {
    const members = await this.client
      .from('conversation_members')
      .select('user_id')
      .eq('conversation_id', conversationId)
      .neq('user_id', currentUserId)
      .limit(1);
    if (members.error) return Err(members.error);

    const peerId = members.data?.[0]?.user_id;
    if (!peerId) return Ok(null);

    // The peer's user_settings row is intentionally private (RLS: own row only).
    // profiles.show_online is the authenticated-readable projection used for peer UI.
    const profile = await this.client.from('profiles')
      .select('id,username,display_name,avatar_url,avatar_path,last_seen_at,show_online')
      .eq('id', peerId).maybeSingle();
    if (profile.error) return Err(profile.error);
    return Ok({ ...profile.data, showOnline: profile.data?.show_online === true });
  }
}
