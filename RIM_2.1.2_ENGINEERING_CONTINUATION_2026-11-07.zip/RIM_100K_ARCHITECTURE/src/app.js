import { Container } from './core/container.js';
import { EventBus } from './core/event-bus.js';
import { Logger } from './core/logger.js';
import { HealthRegistry } from './core/health.js';
import { ConversationRepository } from './infrastructure/supabase/conversation-repository.js';
import { resolveChatHeader } from './application/resolve-chat-header.js';
import { FavoritesWorkspace } from './features/favorites-workspace.js';
import { LocalMusicLibrary } from './features/local-music.js';
import { createLegacyBridge } from './compatibility/legacy-bridge.js';

const context = window.__RIM_LEGACY_CONTEXT;
if (!context?.db) throw new Error('RIM bootstrap: legacy database client is unavailable');
const legacy = createLegacyBridge(context);
const container = new Container();
const logger = new Logger({ version: '2.1.2' });
const events = new EventBus();
const health = new HealthRegistry();
container.value('db', legacy.db).value('logger', logger).value('events', events).value('health', health);
container.factory('conversationRepository', c => new ConversationRepository(c.get('db')));
const favorites = new FavoritesWorkspace({ db: legacy.db, getUser: legacy.getUser, writer: () => window.rimOpenWriter?.(), logger });
const musicRoot = document.createElement('div'); musicRoot.id = 'rimLocalMusicRoot'; document.body.append(musicRoot);
const music = new LocalMusicLibrary({ root: musicRoot, logger });
health.register('supabase-data-api', async () => { const { error } = await legacy.db.from('profiles').select('id').limit(1); if (error) throw error; });
health.register('local-indexeddb', async () => { if (!('indexedDB' in window)) throw new Error('IndexedDB unavailable'); });

window.RIM = Object.freeze({ version: '2.1.2', container, events, logger, health, features: Object.freeze({ favorites, music }), diagnostics: async () => health.run() });

// Fix direct-message header by resolving the other participant from authoritative membership data.
const originalOpenConversation = window.openConversation;
if (typeof originalOpenConversation === 'function' && !window.__rimOpenConversationV21) {
  window.__rimOpenConversationV21 = true;
  window.openConversation = async function (id, ...args) {
    // Flush Lite Writer before removing its overlay, then close both workspace implementations.
    const writerOverlay = document.getElementById('rimWorkspaceOverlay');
    if (writerOverlay && typeof window.rimSaveDocument === 'function') { try { await window.rimSaveDocument(); } catch (error) { logger.error('writer.flush.before.navigation.failed', error); return; } }
    writerOverlay?.remove();
    favorites.close();
    const result = await originalOpenConversation.call(this, id, ...args);
    try {
      const state = context.getActiveConversation();
      if (state?.type === 'direct') {
        const resolved = await resolveChatHeader({ conversation: state, user: legacy.getUser(), repository: container.get('conversationRepository'), logger });
        // A slow profile request must never overwrite the header of a newer chat.
        const current = context.getActiveConversation();
        if (current?.id !== state.id) return result;
        const title = document.getElementById('chatHeadName'); if (title) title.textContent = resolved.title;
        const status = document.getElementById('chatHeadStatus');
        const avatar = document.getElementById('chatHeadAvatar');
        const seenAt = resolved.peer?.last_seen_at ? new Date(resolved.peer.last_seen_at) : null;
        const visible = resolved.peer?.showOnline === true;
        const validSeen = seenAt && Number.isFinite(seenAt.getTime()) && seenAt.getTime() <= Date.now();
        const online = visible && validSeen && (Date.now() - seenAt.getTime() < 120000);
        if (status) status.textContent = !visible ? 'Статус скрыт' : (online ? 'В сети' : (validSeen ? `Был(а) в сети ${seenAt.toLocaleString('ru-RU')}` : 'Время посещения неизвестно'));
        if (avatar) {
          const src = resolved.peer?.avatar_url || resolved.peer?.avatar_path;
          avatar.replaceChildren();
          if (src && /^https:\/\//i.test(src)) { const img = document.createElement('img'); img.src = src; img.alt = ''; img.loading = 'lazy'; img.referrerPolicy = 'no-referrer'; avatar.append(img); }
          else avatar.textContent = (resolved.title || '?').trim().slice(0, 1).toUpperCase();
        }
        events.emit('chat.opened', { conversation: state, peer: resolved.peer });
      }
    } catch (error) { logger.error('chat.header.resolve.failed', error, { conversationId: id }); }
    return result;
  };
}

// Favorites is one ordinary row; keep its existing visual identity, change only the inner workspace.
window.openFavorites = async () => {
  const writerOverlay = document.getElementById('rimWorkspaceOverlay');
  if (writerOverlay && typeof window.rimSaveDocument === 'function') { await window.rimSaveDocument(); }
  writerOverlay?.remove();
  favorites.mount();
};
window.rimSaveMessageToFavorites = async id => {
  const messages = context.getMessages?.() || [];
  const message = messages.find(item => item.id === id);
  if (!message) { alert('Сообщение не найдено в текущей переписке.'); return; }
  await favorites.saveMessage(message);
};

// Add a compact save action to each rendered message; event delegation keeps listener count constant.
const messagesRoot = document.getElementById('messages');
if (messagesRoot && !messagesRoot.dataset.rimSaveBound) {
  messagesRoot.dataset.rimSaveBound = '1';
  const addSaveButtons = () => messagesRoot.querySelectorAll('.message[data-id]:not([data-rim-save-ready])').forEach(node => {
    node.dataset.rimSaveReady = '1'; const button = document.createElement('button'); button.type = 'button'; button.className = 'rim-save-message-btn'; button.textContent = '☆'; button.title = 'Сохранить в Избранное'; button.dataset.rimSave = node.dataset.id; node.append(button);
  });
  new MutationObserver(addSaveButtons).observe(messagesRoot, { childList: true, subtree: true }); addSaveButtons();
  messagesRoot.addEventListener('click', event => { const button = event.target.closest('[data-rim-save]'); if (button) { event.preventDefault(); event.stopPropagation(); window.rimSaveMessageToFavorites(button.dataset.rimSave); } });
}

// Local-only music: file selection is always user initiated; browsers do not permit silent phone-library scanning.
const musicButton = document.getElementById('tabMusic');
if (musicButton) {
  musicButton.removeAttribute('onclick');
  musicButton.addEventListener('click', event => { event.preventDefault(); event.stopImmediatePropagation(); document.getElementById('app')?.classList.add('rim-feature-hidden'); music.render(); }, true);
}

logger.info('app.ready', { modules: ['core', 'supabase-adapter', 'chat-header', 'favorites', 'local-music'] });
window.dispatchEvent(new CustomEvent('rim:ready', { detail: { version: '2.1.2' } }));
