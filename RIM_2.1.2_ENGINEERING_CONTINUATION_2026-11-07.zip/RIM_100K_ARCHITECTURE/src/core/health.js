export class HealthRegistry {
  #checks = new Map();
  register(name, check) { this.#checks.set(name, check); }
  async run() {
    const checks = await Promise.all([...this.#checks].map(async ([name, check]) => {
      const started = performance.now();
      try { await check(); return { name, status: 'ok', durationMs: Math.round(performance.now() - started) }; }
      catch (error) { return { name, status: 'error', durationMs: Math.round(performance.now() - started), message: error?.message || 'failed' }; }
    }));
    return { status: checks.every(x => x.status === 'ok') ? 'ok' : 'degraded', checks, at: new Date().toISOString() };
  }
}
