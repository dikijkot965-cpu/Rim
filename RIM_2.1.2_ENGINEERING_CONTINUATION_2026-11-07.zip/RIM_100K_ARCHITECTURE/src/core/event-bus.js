export class EventBus {
  #listeners = new Map();
  on(type, handler, { signal } = {}) {
    if (!this.#listeners.has(type)) this.#listeners.set(type, new Set());
    const bucket = this.#listeners.get(type); bucket.add(handler);
    const off = () => { bucket.delete(handler); if (!bucket.size) this.#listeners.delete(type); };
    signal?.addEventListener('abort', off, { once: true });
    return off;
  }
  emit(type, payload) { for (const handler of this.#listeners.get(type) || []) { try { handler(payload); } catch (error) { queueMicrotask(() => { throw error; }); } } }
  clear() { this.#listeners.clear(); }
}
