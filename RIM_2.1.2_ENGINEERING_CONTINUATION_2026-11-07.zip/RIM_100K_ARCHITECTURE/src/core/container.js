export class Container {
  #providers = new Map(); #instances = new Map();
  value(token, value) { this.#instances.set(token, value); return this; }
  factory(token, factory) { this.#providers.set(token, factory); return this; }
  get(token) {
    if (this.#instances.has(token)) return this.#instances.get(token);
    const provider = this.#providers.get(token);
    if (!provider) throw new Error(`Dependency not registered: ${String(token)}`);
    const instance = provider(this); this.#instances.set(token, instance); return instance;
  }
}
