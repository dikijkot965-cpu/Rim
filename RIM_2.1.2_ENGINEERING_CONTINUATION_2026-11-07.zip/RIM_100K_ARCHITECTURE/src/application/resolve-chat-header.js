import { displayConversationTitle, isDirectConversation } from '../domain/conversation.js';
export async function resolveChatHeader({ conversation, user, repository, logger }) {
  let peer = null;
  if (isDirectConversation(conversation)) {
    const result = await repository.getDirectPeer(conversation.id, user.id);
    if (result.ok) peer = result.value;
    else logger.warn('chat.peer.resolve.failed', { conversationId: conversation.id, message: result.error?.message });
  }
  return { title: displayConversationTitle(conversation, peer), peer };
}
