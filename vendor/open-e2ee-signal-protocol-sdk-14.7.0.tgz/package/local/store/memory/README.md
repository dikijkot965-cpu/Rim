# In-Memory Store

`InMemorySignalProtocolStore` implements `SignalProtocolLocalStore` in memory for examples, local
development, and deterministic application prototypes.

The protocol and cryptography are real. The adapter simulates the
infrastructure in memory.

## Why it exists

It lets developers exercise client composition without choosing a durable
platform database first. It is intentionally a development adapter, not a
security or persistence boundary.

## Usage

<!-- doc-snippet:run memory-store-client expect="" -->
```ts
// Real protocol and cryptography; simulated in-memory infrastructure.
import { createSignalProtocolClient } from "@open-e2ee/signal-protocol-sdk";
import { inMemoryStore } from "@open-e2ee/signal-protocol-sdk/local/store/memory";

const client = await createSignalProtocolClient({
  identity: { userId: "alice" },
  adapters: { storage: inMemoryStore() },
});
```

All keys, sessions, and trust decisions disappear when the process ends or the
application discards the adapter. Never use this adapter for production accounts.

## Deterministic storage failures

Failure mode is opt-in. A seed and cadence replay the same failing writes, or
you can target the next named store operation:

<!-- doc-snippet:run memory-store-failure-injection expect="" -->
```ts
// Real protocol and cryptography; simulated in-memory infrastructure.
import {
  inMemoryStore,
  InjectedStorageWriteError,
} from "@open-e2ee/signal-protocol-sdk/local/store/memory";

const storage = inMemoryStore({ failures: { seed: 7 } });
storage.failures.failNextWrite("setMetadata");

try {
  await storage.setMetadata("draft", "encrypted-pointer");
} catch (error) {
  if (error instanceof InjectedStorageWriteError) {
    // The explicitly injected failure is consumed, so this retry succeeds.
    await storage.setMetadata("draft", "encrypted-pointer");
  }
}
```

Use `writeFailureEvery` for a repeatable cadence. Failure selection uses the
configured seed and operation count, never `Math.random()` or wall-clock time.

See the parent [storage guide](../README.md).
