# Error Handling Guide

How to handle the errors that the `@open-e2ee/signal-protocol-sdk` library throws.

## Overview

The library uses a structured error system with stable programmatic codes:

- **EncryptionError**: Base error class with error codes and context
- **Specialized Error Classes**: For specific error types requiring special handling
- **Error Codes**: Enumerated codes for programmatic error handling

## Error Classes

### EncryptionError (Base Class)

Every error in the `EncryptionErrorCode` family extends `EncryptionError`:

<!-- doc-snippet:skip requires-existing-client-and-session -->
```typescript
import { EncryptionError, EncryptionErrorCode } from '@open-e2ee/signal-protocol-sdk';

try {
  await signal.encryptMessage(remoteAddress, plaintext);
} catch (error) {
  if (error instanceof EncryptionError) {
    console.log('Error code:', error.code);
    console.log('Context:', error.context);
    console.log('Original error:', error.originalError);
  }
}
```

### Specialized Error Classes

#### UntrustedIdentityError

Thrown when an identity key is not trusted. Requires user intervention (safety number verification).

<!-- doc-snippet:skip requires-untrusted-identity-fixture -->
```typescript
import { isUntrustedIdentityError } from '@open-e2ee/signal-protocol-sdk';

try {
  await signal.establishSession(remoteAddress, bundle);
} catch (error) {
  if (isUntrustedIdentityError(error)) {
    // Show safety number verification UI
    const safetyNumber = await signal.verify(remoteUserId);
    // Ask user to verify safety number
    showVerificationDialog(safetyNumber);
    // Pass back the exact immutable evidence that was displayed.
    await signal.confirmSafetyNumber(safetyNumber.confirmation);
  }
}
```

## Error Codes

The SDK throws every code below. An error-surface check parses the SDK for the
construction sites that decide that. It fails the build if a code or a subclass
survives that nothing produces. A code documented here is therefore one an
application can branch on. The check runs on every change, with the rest of the
checks that [ASSURANCE.md](./ASSURANCE.md) describes.

The tables list the complete `EncryptionErrorCode` enum. The error-surface check
holds each member to a production construction site.

### Session Errors

| Code | Cause | Application response |
|---|---|---|
| `SESSION_NOT_FOUND` | No session exists for the address. | Establish a new session. |
| `SESSION_CORRUPTED` | Stored session data is invalid. | Delete the damaged session, then establish one. |
| `RECIPIENT_NOT_REGISTERED` | The recipient has no published prekey bundle. | Wait for recipient registration, then retry. |
| `PREKEY_FETCH_RATE_LIMITED` | The relay refused another prekey fetch. | Wait for the relay limit, then retry. |
| `SESSION_ESTABLISHMENT_FAILED` | Session setup failed after retries. | Inspect `originalError`, then retry after its cause is fixed. |

### Message Errors

| Code | Cause | Application response |
|---|---|---|
| `INVALID_CIPHERTEXT` | The ciphertext format is invalid. | Reject the message. |
| `DECRYPTION_FAILED` | Available session state could not decrypt the message. | Let the retry flow recover, or inspect the session state. |
| `ENCRYPTION_FAILED` | The SDK could not encrypt the message. | Inspect the session state and `originalError`. |
| `INVALID_SEND_TIMESTAMP` | A new send carries a `timestamp`, or a sync to linked devices carries an application time, that is not a safe positive integer, or that is more than 5 minutes ahead of or more than 24 hours behind the SDK clock. A new send also gets it for a `timestamp` that a different send of the device used. The SDK's own sends, the profile key offer and the sender key distribution, reserve from the same index of the device, so an application that passes `timestamp: Date.now()` can get `already_used` when it did not use the value again itself. The SDK throws `InvalidSendTimestampError` from `@open-e2ee/signal-protocol-sdk/types` and stores or posts nothing for the send. The `reason` is `not_safe_positive_integer`, `too_far_ahead`, `too_old` or `already_used`. `earliest` and `latest` give the window, and are absent for `already_used`. | Omit `timestamp`, so that the SDK picks a free value. On `already_used`, send again with no timestamp. Otherwise send again with a timestamp in the window that no other send used. |
| `SEND_ACCEPTANCE_UNKNOWN` | The posting deadline of a direct or group send ended, and the Relay acceptance of a device is not known. The SDK throws `SendAcceptanceUnknownError` from `@open-e2ee/signal-protocol-sdk/types`. The message might have arrived. | Tell the user that the message might already have arrived. Do not replay the send. |
| `SEND_NEVER_ACCEPTED` | The posting deadline of a direct or group send ended, the call raised no refusal (a thrown refusal or a refusal in the receipt of a shared body), and no refused device has a stored refusal code. The SDK throws `SendNeverAcceptedBySignalProtocolRelayError` from `@open-e2ee/signal-protocol-sdk/types`. | Tell the user which devices did not get the message. |
| `MESSAGE_DUPLICATE` | The session processed this message before. | Discard the duplicate. |
| `TOO_MANY_SKIPPED_MESSAGES` | The message exceeded the skipped-key bound. | Reset the affected session. |
| `REPLAY_DETECTED` | Envelope and encrypted-content timestamps differ. | Reject the message as a replay. |
| `SENDER_KEY_EXPIRED` | The sender key exceeded its rotation period. | Rotate and redistribute the sender key. |
| `GROUP_MASTER_KEY_MISSING` | A client with a `groups` config has no master key for a managed group in its group store, and a new send, an attachment send, or a manual resend of content with no logged group context goes to that group. Receivers deny managed group content with no group context, so the SDK stores and posts nothing for the send, and an attachment send uploads nothing. A manual resend of logged content that carries a group context keeps that context and does not throw. A replay that must build a sent transcript for an own device skips that transcript, keeps its posts, and logs one warning with this code. | Store the group master key through the link or sync path, then send again. |

### Identity and Trust Errors

| Code | Cause | Application response |
|---|---|---|
| `UNTRUSTED_IDENTITY` | The peer identity is unverified or changed. | Verify the safety number before acceptance. |
| `IDENTITY_MISMATCH` | The message identity does not match the expected sender. | Reject the message and inspect the identity state. |
| `SIGNATURE_VERIFICATION_FAILED` | A signature is invalid. | Reject the signed value. |

### Prekey and Session Establishment Errors

| Code | Cause | Application response |
|---|---|---|
| `INVALID_PREKEY_BUNDLE` | A prekey bundle is malformed or inconsistent. | Reject it and fetch a current bundle. |
| `PREKEY_NOT_FOUND` | The required prekey is unavailable. | Fetch current peer keys or rotate local keys, as the operation requires. |
| `PREKEY_ROTATION_REQUIRED` | A local signed or Kyber prekey is too old. | Rotate prekeys before another send. |

### Ratchet Errors

| Code | Cause | Application response |
|---|---|---|
| `COUNTER_OVERFLOW` | A message counter reached its safe bound. | Rotate the session or ratchet epoch. |
| `INVALID_DH_KEY` | A DH public key is malformed or invalid. | Reject the key and its message. |

### Storage Errors

| Code | Cause | Application response |
|---|---|---|
| `KEY_STORAGE_ERROR` | A key-storage operation failed. | Inspect `originalError`, then retry or reinitialize storage. |
| `STORAGE_QUOTA_EXCEEDED` | The storage origin ran out of space. | Free storage space, then retry the rejected write or open. |
| `SECRET_VAULT_REQUIRED` | An operation that keeps a local secret ran without a `SignalProtocolLocalSecretVault`. | Pass a vault, such as `ExpoSecureStoreSignalProtocolSecretVault`, or the application's own. |
| `LOCAL_STORE_KEY_LOST` | A local store holds data, but its secret vault holds no key for that data. | Restore the vault entry, or reset the store. A reset deletes the local data. |
| `SQLITE_ENGINE_UNAVAILABLE` | The SQLite Wasm engine did not load in its web worker. Usually the worker's Content Security Policy does not allow `'wasm-unsafe-eval'`. | Allow `'wasm-unsafe-eval'` in `script-src` on the worker script response, and serve the Wasm file as `application/wasm`. |
| `OPFS_UNAVAILABLE` | The browser cannot keep a SQLite database in the origin private file system, for example in a private or ephemeral context. | Use the IndexedDB store in this runtime. |
| `OPFS_FILE_BUSY` | The web SQLite store could not open its database file this time, usually because another tab of the origin still holds the file. The file is unchanged. | Retry later. Do not change to another store: the data stays in this one. |

### Initialization and Protocol Policy Errors

| Code | Cause | Application response |
|---|---|---|
| `INITIALIZATION_FAILED` | Client or group initialization failed. | Inspect `originalError` and the configuration. |
| `SECURE_RANDOM_UNAVAILABLE` | The runtime has no global `crypto.getRandomValues`. The SDK throws `SecureRandomUnavailableError` from `@open-e2ee/signal-protocol-sdk/types`. | On React Native and Expo, install `react-native-get-random-values` 2.x or `react-native-quick-crypto` and load it before the first SDK call. |
| `PQXDH_REQUIRED` | Every new session requires PQXDH, and the peer bundle has no ML-KEM prekey. No classical key agreement exists. | Wait for new peer keys or queue the message. |
| `PQXDH_FAILED` | The PQXDH exchange failed. | Abort setup and inspect `originalError`. |
| `TRIPLE_RATCHET_REQUIRED` | Triple Ratchet applies, but the session has no PQXDH result. | Establish a PQXDH session first. |

### SPQR Errors

| Code | Cause | Application response |
|---|---|---|
| `SPQR_EPOCH_OUT_OF_RANGE` | The requested epoch is too old or not established. | Reject the message and synchronize session state. |
| `SPQR_MESSAGE_JUMP_TOO_LARGE` | The message jump exceeds the configured bound. | Reject the message. |
| `SPQR_COUNTER_OVERFLOW` | The SPQR message counter reached its bound. | Rotate the SPQR epoch. |
| `SPQR_INVALID_CIPHERTEXT` | An SPQR ML-KEM ciphertext has an invalid form. | Reject the message. |
| `SPQR_VERSION_MISMATCH` | Peer and local SPQR version ranges do not overlap. | Update the peer or the required protocol policy. |

### Sealed Sender and State Errors

| Code | Cause | Application response |
|---|---|---|
| `SEALED_SENDER_AUTH_FAILED` | The relay rejected sealed-sender authorization. | Reauthorize or use identified delivery when policy permits it. |
| `INVALID_STATE` | The requested operation is invalid for current state. | Correct the call order or synchronize state. |

## Relay Protocol Errors

The Relay serves a set of Relay protocol versions. This SDK speaks
protocol version 3, with version 2 as its fallback. It does not speak
version 1. Two errors come from that set. Neither is an `EncryptionError`.

| Error | Cause | Application response |
|---|---|---|
| `HostedSignalProtocolRelayUpgradeRequiredError` | The Relay no longer serves the version that the client sent. The message names that version. `code` is `UPGRADE_REQUIRED`, `status` is the HTTP status (426), and `retryable` is false. | Ship a newer SDK. The same request fails again, so do not retry it. |
| `PROTOCOL_UNSUPPORTED` | The Relay does not serve version 2. The request fails with status 400, the `code` `PROTOCOL_UNSUPPORTED`, and `retryable` true. A send keeps the device open until its posting deadline. | Retry later. The Relay never rolls back below a version that a published SDK sends, so this is a transient fault, not a planned state. |

Versions 2 and 3 have the Relay code `DELIVERY_ALREADY_ACCEPTED`. The Relay
gives it with HTTP status 409, `retryable` false and the `details` reason
`message-id-held`, when it already holds an accepted post under the message
ID of the post. The Relay stored nothing for this post. The SDK reads it as
it reads `RETRY_CONFLICT`:

- A direct post, a sealed direct post, a pre-message and a group shared body
  count the answer as an earlier acceptance, under the rules of
  `RETRY_CONFLICT`. A device whose session the SDK replaced stays unknown.
  The answer has no receipt.
- A retry request that gets `DELIVERY_ALREADY_ACCEPTED` reads it as the
  acceptance of its stored attempt, as it reads `RETRY_CONFLICT`. No
  replacement attempt posts.

A send error can carry the code `DELIVERY_ALREADY_ACCEPTED` when the SDK
cannot count the answer as an acceptance. Handle it as `RETRY_CONFLICT`.

The SDK does not retry an HTTP request that `UPGRADE_REQUIRED` refuses. Each
Relay route that answers with a JSON body throws
`HostedSignalProtocolRelayUpgradeRequiredError`. An attachment download does not read the
response body, so it reports the 426 as a
[`MediaAttachmentError`](./api/namespaces/media/classes/MediaAttachmentError.md)
with the code `download-failed` and the `status` 426.

The mailbox subscription stops for the same refusal on its socket, with the
state `stopped` and the reason `upgrade-required`. It does not reconnect and
does not pull. For `PROTOCOL_UNSUPPORTED` on its socket, the subscription
reconnects with its usual backoff. See [`SignalProtocolRelayConnectionReason`](./api/type-aliases/SignalProtocolRelayConnectionReason.md).

The subscription also stops when the Relay refuses its socket token request or
a pull conclusively. The refusal has `retryable` false and the code
`AUTHORITY_DENIED`, `NOT_FOUND`, or `OPERATION_EXPIRED`. The state is `stopped`
and the reason is `authority-refused`. A conclusive `NOT_FOUND` first gets one
device token refresh. When that refresh gets `DEVICE_REVOKED`, the reason is
`device-revoked`. A refusal with `retryable` true, for
example a missing Relay binding, goes to the retry schedule. A `NOT_FOUND` on
the socket token request is a refusal of this device instead, as
[Signal Protocol Relay Device Errors](#signal-protocol-relay-device-errors) describes. See
[`SignalProtocolRelayConnectionState`](./api/interfaces/SignalProtocolRelayConnectionState.md).

A client call can wrap the error in an `EncryptionError`. It is then the
`originalError`.

<!-- doc-snippet:skip requires-existing-client -->
```typescript
import {
  EncryptionError,
  HostedSignalProtocolRelayUpgradeRequiredError,
} from '@open-e2ee/signal-protocol-sdk';

function upgradeRequired(error: unknown): boolean {
  return (
    error instanceof HostedSignalProtocolRelayUpgradeRequiredError ||
    (error instanceof EncryptionError &&
      error.originalError instanceof HostedSignalProtocolRelayUpgradeRequiredError)
  );
}

try {
  await signal.send(remoteUserId, plaintext);
} catch (error) {
  // Only a newer SDK can send again. Ask the user to update the app.
  if (upgradeRequired(error)) showUpdateRequired();
  else throw error;
}
```

### Stale Devices

A direct message, a sync copy, a sender-key distribution, a group device
message, a receipt, and a retry request go to one device. Each of these
posts names the registration ID of the recipient session. A shared group
message names the registration of each destination device. The identified
route and both sealed routes send the registration. A sealed post sends no
sender identity. A post to a device with no session names none.

The Relay compares this value with the current registration of the device.
A device that was reinstalled with the same device ID has a new
registration. The Relay then refuses the post:

- The identified route and the sealed direct route answer HTTP 410 with
  the code `STALE_DEVICE`. The sealed direct route takes an access key or
  the group endorsement of the one recipient account.
- The sealed group route refuses only that destination. Its receipt names
  each refused destination with the code `STALE_DEVICE`. The refused count
  alone names no device, so the SDK infers no code from it. A one-device post
  goes on this route only after a fallback from the direct route. See
  [Sealed Route Rejections](#sealed-route-rejections).

The SDK handles this refusal for each of these post kinds. It refreshes
the session of the device once and posts again. A direct message, a sync
copy, a sender-key distribution, a group device message, and a receipt are
encrypted again under the new session and get a new transport ID. A retry
request is not encrypted, so it keeps its envelope: the second post has the
same transport ID and names the registration of the new session. The
application does not have to act. A retry request ends with the terminal
class `missing-sender` only when the Relay has no bundle for the device, or
when the device refuses the request again after the refresh. When the
refresh of a receipt or a retry request fails for another reason, the SDK
keeps the stale session and posts the item again later. A device that a
shared group message names gets the same repair when the receipt refuses it.

The registration field never identifies the sender. A sealed post that
names an old registration tells the Relay only that some sender still has
a session from before the reinstall. The post carries no sender identity,
so it does not tell the Relay which sender that is.

### Sealed Route Rejections

A post to one device can use the group endorsement on the sealed direct
route. The Relay answers a rejection in one of two ways:

| Answer | Meaning | SDK behavior |
|---|---|---|
| 401 `ANONYMOUS_AUTH_REJECTED` | The direct route does not take the endorsement. The post did not start. | The SDK posts the message once on the sealed group route for that device, and writes one `info` log line with the behavior `GROUP_ROUTE_FALLBACK`. The post stays sealed. |
| 401 `GROUP_CREDENTIAL_REJECTED` | The Relay rejected the endorsement. | No route fallback. In `required` mode, the send fails with `SEALED_SENDER_AUTH_FAILED` and makes no identified post. In `preferred` mode, the SDK posts identified and calls `onIdentifiedFallback`. |

A resend that answers a retry request uses the same authorization as its
original send. A resend of a group send to a member with no access key is
sealed with the group endorsement. A resend in `required` mode that has no
sealed authorization fails with `SEALED_SENDER_REQUIRED` and makes no
identified post.

### Device Sets

A Relay that compares device sets checks each declared post. Each post to an
account declares the device IDs that the sender holds records for. The Relay
refuses a declaration that does not match its device list:

- HTTP 409 with the code `DEVICE_SET_MISMATCH` names the missing and the extra
  devices of each account.
- HTTP 410 with the code `STALE_DEVICE` names each declared device whose
  registration changed.

The SDK repairs the set and posts again. It removes each extra device record,
starts a new session with each missing or stale device, and encrypts the
message again only for those devices. A device that the Relay accepted keeps
its stored post. The application does not have to act.

A send has two phases: the recipient phase, and then the sync phase for the
own devices. Each phase can restart 10 times. When the Relay refuses the
declaration of the recipient phase after the 10th restart, or refuses a
restart post with `OPERATION_EXPIRED`, the send throws
[`DeviceSetReconciliationError`](./api/classes/DeviceSetReconciliationError.md).
`isOutgoingMessageError` is true for it. Its fields:

| Field | Meaning |
|---|---|
| `reason` | `exhausted` after the 10th restart, or `expired` after `OPERATION_EXPIRED` |
| `phase` | `recipient` or `sync` |
| `restarts` | The restarts of the phase |
| `lastRefusal` | The code and the devices of the last refusal. `BUNDLE_NOT_FOUND` is a listed device with no prekey bundle |
| `acceptedDevices` | The devices that the Relay accepted. They stay accepted |
| `unresolvedDevices` | The devices that did not get the message |
| `clientMessageId` | The ID of the send |
| `outcome` | `failed` or `acceptance-unknown`. With `acceptance-unknown`, the message might have arrived. Treat it like `SendAcceptanceUnknownError` |

After a recipient-phase end, the outbox keeps the send as terminal with its
`outcome`, and the SDK does not post it again. A replay with the same
`clientMessageId` throws the stored-end class of its outcome,
`SendAcceptanceUnknownError` or the failed-end error below, and posts
nothing. `expired` gives `acceptance-unknown`, because the Relay can have
accepted an earlier post. A sync-phase end has no `outcome`. The send keeps
its result with `syncPending`, and a later `send()` with the same
`clientMessageId` posts the sync phase again.

A direct or group send has a posting deadline, `deadlineAt`. It is the earlier of 24
hours after the SDK first stores the send and 24 hours after its timestamp. A
replay or a restart never moves it. At or after `deadlineAt`, the SDK starts
no Relay request for the send. A request that started before it still counts
when its answer arrives later. Before `deadlineAt`, a send error that leaves a
device open has `retryable: true`, and `relayRetryable` keeps the hint of the
Relay. With a store that implements `listMetadataKeys`, as every built-in
store does, the SDK replays the send at start and on reconnect until
`deadlineAt`. It reports the end once through `onSendOutcome`. An internal
send of the SDK, such as a sender key distribution, never reaches
`onSendOutcome`. The SDK keeps no content of a sender key distribution at
rest, so it does not replay one. With the listing method, it ends an open
distribution at its deadline and reports nothing, and a retry request of the
receiver recovers a lost distribution, as in Signal. An open sender key
distribution that an earlier SDK version stored carries no marker, so the SDK
reports `content-required` for it once for each client run before its
deadline, and reports its end through `onSendOutcome` once, at its deadline.
With a custom store that does not implement `listMetadataKeys`, replay with
the same `clientMessageId` before `deadlineAt`. A call of `send()` with the same `clientMessageId` before
`deadlineAt` is always safe. A replay posts only devices that the Relay did
not accept. The send also ends before
`deadlineAt` when each open device got `OPERATION_EXPIRED` as the last answer
in the call or has a stored refusal that the SDK cannot recover. That early
end has `retryable: false` and follows the rule below. A Relay answer
`UPGRADE_REQUIRED` or `DEVICE_REVOKED` ends the send at once by the same
rule: with no device of unknown acceptance, the answer is the error of the
failed end. When another device of the call has an unknown acceptance, the
send ends as acceptance-unknown instead, because that device can hold the
post. When the deadline
ends, the send throws `SendAcceptanceUnknownError` or the failed-end error of
the rule below. The two deadline classes come from
`@open-e2ee/signal-protocol-sdk/types`:

| Error | Cause | Application response |
|---|---|---|
| `SendAcceptanceUnknownError` | The Relay acceptance of a device is not known. An answer was lost, or it followed an uncertain request | Tell the user that the message might already have arrived. Do not replay the send |
| `SendNeverAcceptedBySignalProtocolRelayError` | The Relay accepted no request for an open device, the call raised no refusal, and no refused device has a stored refusal code. No request started before the deadline, or each answer was a refusal for now, such as `QUOTA_EXCEEDED` | Tell the user which devices did not get the message |

When no device has an unknown acceptance, the send ends failed, and one rule
gives its error:

1. When the call that ends the send raised a refusal, the first such refusal
   is the error. A raised refusal is a thrown refusal or a refusal in the
   receipt of a shared body. A thrown refusal keeps its class. A refusal in a
   receipt is an `Error` with the `code` of that refusal.
2. Otherwise, the error is an `Error` with the stored `code` of the first
   refused device that has one, in the order of the destinations.
3. Otherwise, the error is `SendNeverAcceptedBySignalProtocolRelayError` with code
   `SEND_NEVER_ACCEPTED`.

A replay of the ended send raises no refusal, so its error comes from case 2
or case 3. Each of these errors has `deadlineAt`, `acceptedDevices`,
`refusedDevices` and `retryable: false`. A replay of the ended send posts
nothing.

A replay or a resend after `SendAcceptanceUnknownError` can add one charged
unit within 24 hours, when the Relay no longer holds its record of the first
acceptance. The SDK does not promise that such a retry has no cost.

To post an ended send again, call `resendMessage(clientMessageId)`. The
resend keeps the `clientMessageId`, the timestamp and the content of the
send. It encrypts the content again for each recipient device that the
Relay did not accept, and posts each copy under the message ID
`<clientMessageId>:manual:N`, N from 1. A resend of a group send posts the
content of its send log entry, so each copy carries the group context of the
original send, not the current one. It is a new Relay operation, so the
Relay can charge a resend as a new message. It has its own posting deadline,
24 hours after the call, and its end has the same classes as the end of a
send. `onSendOutcome` reports the end of a resend once, with `manualResend`
set to N. Only a send younger than 30 days takes a new resend. At or after
30 days from the send, `resendMessage` throws `Only a send younger than 30
days takes a manual resend` and posts nothing. An open resend of an older
send still posts until its own deadline.

The receive queue of a recipient device drops a copy whose sender and
timestamp match a message that it already processed, for 60 days. A later
message of the same sender with the same timestamp drops too, with any body
and from any device of the sender. The drop needs the timestamp that the
content adapter reads from the message. Content with no timestamp, such as
raw string or byte content, takes no drop key, and a recipient that holds
it receives the copy again. The recipient records the message with the
completion of its receive record. When a delivery receipt is due, it records the message right
after the receipt-due write and again with the completion of the receipt.
When no receipt is owed, a stop before the completion of the receive record
runs `onMessageDecrypted` again. When a receipt is owed, only a stop before
the receipt-due write runs it again. The caller-origin receive path gives
every decrypted message to the caller, and a caller that keeps its own
records removes a copy itself. A recipient device on an SDK
version without that check can show the message twice.

The sync phase does not fail the send. The recipient result is stored first.
When the sync phase does not complete, or the own device list cannot be read,
the result carries `syncPending: true`. Call `send()` again with the same
`clientMessageId` before `deadlineAt` to post the pending copies. At or after
`deadlineAt`, a replay posts nothing. It returns the stored result with
`syncPending`, with one exception. When the send has no sync messages, the
replay reads the own device list again. If that read finds no other own
device, the replay completes the send and returns the result without
`syncPending`.

The Relay marks each accepted declared post with `deviceSetChecked`. When an
accepted post has no mark, the Relay did not compare its device set. The send
is delivered and its result does not change. The client reports a
[`SignalProtocolRelayProtocolError`](./api/classes/SignalProtocolRelayProtocolError.md) with the code
`DEVICE_SET_UNCHECKED` once for the send through the `onRelayProtocolError`
hook. Its `route` names the post route. A sync copy to another own device is
an `identified-direct` post. A sync payload of a method such as
`syncReadToLinkedDevices` reports the error once, with no `clientMessageId`.
Report it to the Relay operator. A device that the SDK counts as accepted from
a `RETRY_CONFLICT` or `DELIVERY_ALREADY_ACCEPTED` answer has no receipt, so
the SDK reports no `DEVICE_SET_UNCHECKED` error for it.

A relay that does not compare device sets gets no declaration. The Convex
relay is one. With it, the SDK reads the device lists as before, and none of
these errors occur.

## Signal Protocol Relay Device Errors

The Relay can refuse this device, and a managed device link can refuse its
linked store or its active device. Five errors name these refusals. None is an `EncryptionError`,
and the SDK retries none of them.

| Error | Cause | Application response |
|---|---|---|
| [`HostedSignalProtocolRelayDeviceRevokedError`](./api/classes/HostedSignalProtocolRelayDeviceRevokedError.md) | An account recovery or a device removal revoked this device. `code` is `DEVICE_REVOKED`, `status` is 403, and `retryable` is false. | Sign the user out of this device. The Relay refuses a registration with the revoked key, so a re-registration fails too. To join the account again with the same store, stop each client, call `resetRemovedHostedSignalProtocolRelayDevice`, and then call `joinHostedSignalProtocolRelayAccount`. |
| [`HostedSignalProtocolRelayDeviceUnknownError`](./api/classes/HostedSignalProtocolRelayDeviceUnknownError.md) | The Relay has no device for the stored session. `code` is `NOT_FOUND`, `status` is 404, and `retryable` is false. The message is the Relay's own message. | Ask the user to confirm a re-registration of this device. Do not re-register without that confirmation. |
| [`HostedSignalProtocolRelayDeviceLinkRequiredError`](./api/classes/HostedSignalProtocolRelayDeviceLinkRequiredError.md) | The Relay refused a registration, because the account already has a device and no device of the account holds this device key. `code` is `DEVICE_LINK_REQUIRED`, `status` is 409, and `retryable` is false. The Relay registered no device. The error is a `HostedSignalProtocolRelayHttpError`. | Link this device from the primary device with `joinHostedSignalProtocolRelayAccount` and `approveHostedSignalProtocolRelayDeviceLink`. On a Relay without the device link routes, link it with `linkHostedSignalProtocolRelayDevice` from the primary device. Without the primary device, recover the account. The same registration is refused again. |
| [`HostedSignalProtocolRelayDeviceLinkError`](./api/classes/HostedSignalProtocolRelayDeviceLinkError.md) | `linkHostedSignalProtocolRelayDevice` found state in the linked store that the link did not write: a group in the linked group store, or a device-authentication key for this Relay connection with no registration of this link. `code` is `DEVICE_LINK_STORE_NOT_EMPTY`, and `retryable` is false. The link wrote nothing. | Link the device again with a new, empty store. The same store is refused again. |
| [`HostedSignalProtocolRelayDeviceProvisioningError`](./api/classes/HostedSignalProtocolRelayDeviceProvisioningError.md) with the code `NOT_PRIMARY` | `linkHostedSignalProtocolRelayDevice` ran with the store of a device that is not device 1, or the Relay refused the link because the device that authorized it is not device 1. Only the primary device can link a device. `retryable` is false. | Call `linkHostedSignalProtocolRelayDevice` with the store of the primary device as `activeDeviceStorage`. The call removes the link state and keeps the identity records and the registration, so the next call sends the same registration ID. |

`createHostedSignalProtocolClient` throws `HostedSignalProtocolRelayDeviceRevokedError`
and `HostedSignalProtocolRelayDeviceUnknownError` when the stored session
cannot get a device token. It does not register a new device in their
place. A running client throws them from its Relay calls.

A Relay request with the unexpired device token of a removed device gets
`NOT_FOUND` with `retryable` false. A missing destination gets the same
refusal. So the SDK refreshes the device token one time. When the refresh
throws one of these two errors, the call throws it. Each other result of the
refresh, for example a new token or a network failure, gives the `NOT_FOUND`
of the request. After a refresh succeeds, a `NOT_FOUND` in the next 60 s
gets no refresh. After a refresh gets `DEVICE_REVOKED`, each later call of
that client that needs the device token throws
`HostedSignalProtocolRelayDeviceRevokedError` and sends no request.

A client call can
wrap them in an `EncryptionError`, as the `originalError`. The mailbox subscription
stops with the reason `device-revoked` or `device-unknown`. See
[`SignalProtocolRelayConnectionReason`](./api/type-aliases/SignalProtocolRelayConnectionReason.md).

`createHostedSignalProtocolClient` throws
`HostedSignalProtocolRelayDeviceLinkRequiredError` when it registers a new
store, or re-registers a device, on an account that has a device. A recovery
never throws this error.

To re-register, create the client again with `assertionPurpose: 'reregister'`.
It keeps the stored identity and device key, and it asks for a `register`
assertion. It throws before any assertion when the store holds no identity or
no device key. A retry after a failed call sends the same registration again.

A re-registration has these effects:

- When the account has a device, the Relay refuses the re-registration with
  `HostedSignalProtocolRelayDeviceLinkRequiredError`. No device of the account
  holds the device key of this store.
- When the account has no device, the Relay gives this device a device ID.
  The ID can be new, so the messages queued for the old device are lost.
- For a new device ID, the Relay skips each ID that a device or an earlier
  registration holds. An account has five device IDs. When devices and
  earlier registrations hold all five, the registration fails with the code
  `CONFLICT`.
- When the account itself was deleted, the re-registration makes a new account
  address. Contacts of the old address do not reach the new one.

<!-- doc-snippet:skip requires-existing-client -->
```typescript
import {
  HostedSignalProtocolRelayDeviceRevokedError,
  HostedSignalProtocolRelayDeviceUnknownError,
  createHostedSignalProtocolClient,
} from '@open-e2ee/signal-protocol-sdk';

try {
  signal = await createHostedSignalProtocolClient(options);
} catch (error) {
  if (error instanceof HostedSignalProtocolRelayDeviceRevokedError) {
    signOutThisDevice();
  } else if (
    error instanceof HostedSignalProtocolRelayDeviceUnknownError &&
    (await confirmReregistration())
  ) {
    signal = await createHostedSignalProtocolClient({
      ...options,
      hosted: { ...options.hosted, assertionPurpose: 'reregister' },
    });
  } else {
    throw error;
  }
}
```

## Group Receive Errors

Three error classes describe a managed group receive that gives no content.
None of them is an `EncryptionError`. Each one tells the caller what to do
with the message.

| Error | Cause | Keep rule |
|---|---|---|
| [`GroupReceiveUnavailableError`](./api/classes/GroupReceiveUnavailableError.md) | The group state is not current. `reason` names the wait, and `retryAfterMs` gives the time to the next try. The client stored the content in a receive record under `messageId`. | No client method throws it. `processIncomingEnvelope` gives a `pending` outcome for it. Acknowledge the envelope. The receive queue decides the stored content when the group updates, with no second decrypt. |
| [`GroupReceiveRefusedError`](./api/classes/GroupReceiveRefusedError.md) | The client refused the content. `reason` names the refusal, for example `sender-not-member` or `sync-from-other-account`. The client asked for no resend. | Drop the message. A redelivery is dropped as a processed duplicate. |
| [`GroupResendDeferredError`](./api/classes/GroupResendDeferredError.md) | A resend to a group member waits for the group state. The client neither sent nor refused the resend. | The Relay keeps the retry request. Do not acknowledge it. A later delivery decides again. |

`decryptEnvelope` throws `GroupReceiveRefusedError` for a group context that
is malformed or names another group. `processIncomingEnvelope` throws none
of them. It returns a receive outcome: `pending` for content that waits for
its group state, and `denied` for refused content. Acknowledge the envelope
for both. The receive queue keeps pending content on the device and decides
it when its group updates. Do not acknowledge an envelope whose outcome is
`refused`: the receive queue had no room, and the client stored nothing.

Content from another account that carries a sync message is refused as
`sync-from-other-account` on the Relay subscription, in
`receiveIncomingEnvelopes`, in `decryptEnvelope`, and in
`processIncomingEnvelope` as a `denied` outcome. The raw decrypt methods
`receive`, `decryptMessage`, and `decryptMessages` return the plaintext with
no group classification and do not refuse it.

A `GroupKeySync` from an own device carries the master key of a managed
group. `processIncomingEnvelope`, the Relay subscription, and the receive
queue consume it and never give it to the application.
`processIncomingEnvelope` gives the outcome `null-message` for it, so
acknowledge the envelope. `decryptEnvelope` and the raw decrypt methods
`receive`, `decryptMessage`, and `decryptMessages` return it unapplied,
master key included. A sender device reinstalled with the same device ID
between the arrival and the consumption of its `GroupKeySync` is marked in
the key sync ledger with the new registration, so that install gets the key
from another own device or from group traffic. A device without
`config.groups` drops the sync, the
sender does not send it again, and that device gets the key only from group
traffic. A sync whose key is not a 32-byte master key with a non-negative
revision, which a custom content adapter can give, is consumed and writes
nothing. A `GroupKeySync` from another account is refused as
`sync-from-other-account` before the client writes a group record or a master
key. An own device on an older SDK version does not know this sync. It gives
the raw group key sync, with the master key, to `onMessageDecrypted`. So
upgrade every own device of one account in one release.

The Relay subscription applies the rule itself. It acknowledges an envelope
after its content is committed, also when the content waits for its group
or is denied. An envelope that the receive queue refuses for lack of room
stays unacknowledged. `receiveIncomingEnvelopes` commits each envelope and sends
no acknowledgment. It reports the committed envelopes in
`processedMessageIds`, ready for the transport acknowledgment. It reports a
deferred retry request and an envelope that the receive queue had no room
for in `failedMessageIds`.

<!-- doc-snippet:skip requires-existing-client -->
```typescript
const outcome = await signal.processIncomingEnvelope(envelope, {
  onPersist: (processed) => saveMessage(processed.messageId, processed.plaintext),
});
if (outcome.kind === 'refused') {
  keepForLater(envelope);
} else {
  acknowledge(envelope);
}
```

## Key Transparency Errors

A hosted client checks identities against the identity log of the Relay when
the build pins the log keys of the Relay profile. A failed check gives a
[`KeyTransparencyVerificationError`](./api/classes/KeyTransparencyVerificationError.md).
It is not an `EncryptionError`, and no client method throws it. A background
check gives it to the `onKeyTransparencyFailure` hook, in `event.error`.
`checkContactKeyTransparency()` returns it in a `failure` result, in
`outcome.error`, and runs no hook. A failure never refuses a send or a
decrypt.

`event.subject` is `contact` for the check of a contact identity that the
client fetched, and `self` for the weekly check of the own account. A check
that cannot get a result, such as on a network error, is not a failure and
runs no hook.

A requested check applies none of the rules in the next paragraph. It returns
the result of one search, and a key mismatch gives `LOGGED_KEY_MISMATCH` on the
first call.

A contact key mismatch, or a contact that is not in the log, runs no hook on
the first result. The client checks again 2 hours later. It runs the hook only
when that check again gives a key mismatch or a not-logged result, with the
code of the second result. When the Relay says that
the append of the identity waits, the client checks again. It stops when the
identity is in the log, or after 24 hours. A self failure runs the hook on the
second consecutive failed weekly check. For the own account, a not-logged
result is a failure, and a pending append follows the contact waits.

| Code | Cause |
|---|---|
| `VRF_PROOF_INVALID` | The VRF proof of the log index is not valid for the pinned VRF public key and the account address. |
| `SEARCH_POSITION_INVALID` | The position of the entry is not inside the tree of the signed head. |
| `INCLUSION_PROOF_INVALID` | The entry, its opening, and the inclusion path do not give the root of the signed head. |
| `TREE_HEAD_SIGNATURE_INVALID` | No pinned head key signed the head for the project of the connection. |
| `TREE_HEAD_STALE` | The head time is more than 24 hours from the local clock. |
| `TREE_HEAD_INCONSISTENT` | The head does not extend the last head that the client verified. |
| `LOGGED_KEY_MISMATCH` | The latest logged key of the account is not the identity that the client has for it. |
| `LOGGED_TOMBSTONE` | The latest log entry of the account is a deletion. |
| `IDENTITY_NOT_LOGGED` | The Relay served the identity of a contact, but the log has no entry for it. For the self-check, the log has no entry for the own account. |
| `LOG_APPEND_OVERDUE` | The Relay said for 24 hours that the append of an identity waits. |
| `MALFORMED_RESPONSE` | The Relay response does not have the form of an identity log result. |

Report the subject and the code to your monitoring. The error message names
the failed step and holds no key bytes and no account address.

<!-- doc-snippet:skip requires-external-context -->
```typescript
onKeyTransparencyFailure: (event) => {
  monitoring.report('key-transparency', { subject: event.subject, code: event.error.code });
}
```

## Error Handling Patterns

### One Handler for Every Error

<!-- doc-snippet:skip application-handler-fragment -->
```typescript
import {
  EncryptionError,
  EncryptionErrorCode,
  isUntrustedIdentityError,
  isSealedSenderAuthError,
} from '@open-e2ee/signal-protocol-sdk';

async function handleEncryptionError(error: unknown): Promise<void> {
  if (!(error instanceof EncryptionError)) {
    // Not a signal error, re-throw
    throw error;
  }

  // Handle specialized errors first
  if (isUntrustedIdentityError(error)) {
    await handleUntrustedIdentity(error);
    return;
  }

  if (isSealedSenderAuthError(error)) {
    await reauthorizeSealedSender(error);
    return;
  }

  // Handle by error code
  switch (error.code) {
    case EncryptionErrorCode.SESSION_NOT_FOUND:
      await establishNewSession(error.address);
      break;

    case EncryptionErrorCode.TOO_MANY_SKIPPED_MESSAGES:
      // Message is unrecoverable, notify user
      notifyMessageLost(error.context?.operation);
      break;

    case EncryptionErrorCode.DECRYPTION_FAILED:
      // Possible tampering or corruption
      logSecurityEvent(error);
      break;

    case EncryptionErrorCode.KEY_STORAGE_ERROR:
      // Storage issue, retry with backoff
      await retryWithBackoff(() => reinitializeStorage());
      break;

    default:
      // Unknown error, log and notify
      logError(error);
      notifyUnexpectedError(error.message);
  }
}
```

### Retry with Exponential Backoff

The library provides a built-in retry utility:

<!-- doc-snippet:skip requires-existing-client -->
```typescript
import { withRetry } from '@open-e2ee/signal-protocol-sdk/utils/retry';

await withRetry(
  async () => {
    await signal.rotatePreKeys();
  },
  {
    operationName: 'rotatePreKeys',
    maxRetries: 2,
    baseDelay: 2000,
    maxDelay: 30000,
  }
);
```

### Session Recovery Pattern

<!-- doc-snippet:skip application-session-recovery-fragment -->
```typescript
import {
  EncryptionError,
  EncryptionErrorCode,
  ProtocolAddress,
  type SignalProtocolClient,
} from '@open-e2ee/signal-protocol-sdk';

async function ensureSession(
  signal: SignalProtocolClient,
  userId: string,
  deviceId: number
): Promise<void> {
  const remoteAddress = ProtocolAddress.create(userId, deviceId);

  try {
    const hasSession = await signal.hasSession(remoteAddress);
    if (!hasSession) {
      // Fetch prekey bundle and establish session
      const bundle = await fetchPreKeyBundle(userId, deviceId);
      await signal.establishSession(remoteAddress, bundle);
    }
  } catch (error) {
    if (error instanceof EncryptionError) {
      switch (error.code) {
        case EncryptionErrorCode.SESSION_CORRUPTED:
          // Delete corrupted session and retry
          await signal.deleteSession(remoteAddress);
          const bundle = await fetchPreKeyBundle(userId, deviceId);
          await signal.establishSession(remoteAddress, bundle);
          break;

        case EncryptionErrorCode.INVALID_PREKEY_BUNDLE:
          // Bundle was invalid, try fetching again
          const newBundle = await fetchPreKeyBundle(userId, deviceId);
          await signal.establishSession(remoteAddress, newBundle);
          break;

        default:
          throw error;
      }
    } else {
      throw error;
    }
  }
}
```

## Logging Errors

The library includes structured logging for errors:

<!-- doc-snippet:skip requires-platform-adapters -->
```typescript
import { DefaultSignalProtocolClient } from '@open-e2ee/signal-protocol-sdk';

const signal = await DefaultSignalProtocolClient.create(userId, {
  storage,
  relay,
  logger: {
    debug: console.debug,
    info: console.info,
    warn: console.warn,
    error: console.error,
    breadcrumb: console.debug,
  },
});

// Errors are automatically logged with context through the client logger.
void signal;
```

## Best Practices

### 1. Always Use Type Guards

<!-- doc-snippet:skip type-guard-comparison-fragment -->
```typescript
// Prefer the exported guard so narrowing stays behind one public function.
if (isUntrustedIdentityError(error)) {
  // Handle untrusted identity
}

// Current guards delegate to instanceof. Bundle one copy of the SDK.
```

### 2. Preserve Error Context

<!-- doc-snippet:skip error-wrapping-comparison-fragment -->
```typescript
// Good: Wrap errors with context
throw new EncryptionError('Failed to establish session', EncryptionErrorCode.SESSION_NOT_FOUND, {
  address: remoteAddress,
  operation: 'establishSession',
  originalError: error,
});

// Bad: Lose original error
throw new Error('Session error');
```

### 3. Handle Security-Critical Errors Prominently

<!-- doc-snippet:skip requires-identity-change-fixture -->
```typescript
// Identity changes require prominent user warning
if (isUntrustedIdentityError(error)) {
  // Don't silently accept - show security dialog
  const accepted = await showSecurityWarningDialog(error);
  if (accepted) {
    // acceptIdentityRotation() takes the peer's new composite identity tuple and
    // resets the sessions bound to the retired identity. Read that tuple from the
    // relay rather than from `error.identity`: the error carries whichever tuple
    // failed the trust check, which on the three session-bound throw sites is the
    // pinned one being rejected, not the one the peer now publishes.
    const userId = error.untrustedAddress.userId;
    const identity = await relay.getIdentityKey(userId);
    if (identity) {
      await signal.acceptIdentityRotation(userId, identity);
    }
  }
}
```

## See Also

- [SECURITY.md](./SECURITY.md) - Security guidelines
- [ARCHITECTURE.md](../ARCHITECTURE.md) - System architecture
- [Signal Protocol Specification](https://signal.org/docs/) - Official spec
