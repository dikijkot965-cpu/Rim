# Client Composition Guide

> Navigation: [README](../README.md) | [ARCHITECTURE](../ARCHITECTURE.md) | [Getting Started](./GETTING_STARTED.md) | **Client Composition**

Use `createHostedSignalProtocolClient()` to connect to the OpenE2EE Signal
Protocol Relay. Supply device-local storage, the environment connection URL,
and an identity-assertion callback. Advanced integrations can compose an
application-owned transport with `createSignalProtocolClient()`.

This guide documents the current stable composition API. It groups local
persistence under device storage, and an explicit object-store adapter supplies
remote encrypted bytes. The current API passes protocol storage as
`adapters.storage` and remote attachment storage as `adapters.remoteObjectStore`.

## Local Client

<!-- doc-snippet:run client-composition-local-client expect="" -->
```ts
// Real protocol and cryptography; simulated in-memory infrastructure.
import { createSignalProtocolClient } from "@open-e2ee/signal-protocol-sdk";
import { inMemoryStore } from "@open-e2ee/signal-protocol-sdk/local/store/memory";

const signal = await createSignalProtocolClient({
  // One Signal Protocol client represents one app account/device.
  identity: { userId: "alice" },
  // Local-only clients can omit a relay, but still need device-local storage.
  adapters: { storage: inMemoryStore() },
});
```

## Expo client on the Signal Protocol Relay

`oe new` creates the Relay project and its Sandbox environment, and it writes
the environment connection URL to your application configuration.
`getIdentityAssertion` returns a short-lived signed assertion. The hosted
factory uses it for device registration and authentication. In a Sandbox
environment, `hostedSignalProtocolRelaySandboxIdentity(storage)` supplies it. In a production
project in device-owned mode, `hostedSignalProtocolRelayDeviceOwnedIdentity(storage)`
supplies it. In a production project in application-bound mode, it returns an
assertion for the signed-in user from your backend. With a
[native Clerk or Firebase profile](./RECIPES.md#native-provider-profiles), it
returns the provider token instead.

<!-- doc-snippet:skip requires-external-context -->
```ts
import { createHostedSignalProtocolClient } from "@open-e2ee/signal-protocol-sdk";
import { expoStore } from "@open-e2ee/signal-protocol-sdk/local/store/expo";

const signal = await createHostedSignalProtocolClient({
  adapters: {
    // Expo storage owns this device's private keys and session state.
    storage: await expoStore(),
  },
  hosted: {
    // The environment-scoped connection URL from the OpenE2EE console.
    relayUrl: process.env.EXPO_PUBLIC_OPEN_E2EE_SIGNAL_RELAY_URL ?? process.env.EXPO_PUBLIC_OPEN_E2EE_RELAY_URL!,
    // Returns a short-lived signed assertion for the signed-in user.
    getIdentityAssertion,
  },
  logger,
});
```

## Attachments

<!-- doc-snippet:skip requires-external-context -->
```ts
import { convexR2ObjectStore } from "@open-e2ee/signal-protocol-sdk/remote/object-store/convex-r2";
import { api } from "../convex/_generated/api";

const signal = await createSignalProtocolClient({
  identity: { userId },
  adapters: {
    storage,
    relay,
    // Brokered remote storage of encrypted byte objects.
    remoteObjectStore: convexR2ObjectStore({
      convex,
      api: api.signalObjectStore,
    }),
  },
  media: {
    preparedUploads: appPreparedUploads,
    maxPreparedUploadBytes: appUploadBudgetBytes,
    // The existing Signal Protocol storage adapter persists queue metadata.
    // These callbacks keep app-owned files, plaintext cache, and UI state
    // outside the protocol package.
    loadLocalAttachment: async ({ localMediaId }) =>
      appDraftMedia.readBytes(localMediaId),
    saveUploadedAttachment: async ({ localMediaId, attachment }) =>
      appMediaPointers.save(localMediaId, attachment),
    saveDownloadedAttachment: async ({ attachmentId, downloaded }) =>
      appMediaCache.save(attachmentId, downloaded.data),
    deleteLocalAttachment: async ({ attachmentId }) =>
      appMediaCache.delete(attachmentId),
  },
});
```

The current durable media queue does not require a second queue adapter. It
stores bounded job metadata in `adapters.storage` under SDK-owned namespaced
keys. The intended future shape moves this behind grouped device storage, so
app code does not have to compose queue callbacks for ordinary sends. See
[Future direction](#future-direction-not-shipped). Do not add a parallel public
`signal.media.*` API once message attachment helpers exist.

## Direct Client Creation

`DefaultSignalProtocolClient.create()` remains the low-level primitive. It uses the same
developer-facing protocol config:

<!-- doc-snippet:skip requires-external-context -->
```ts
import { DefaultSignalProtocolClient } from "@open-e2ee/signal-protocol-sdk";

const signal = await DefaultSignalProtocolClient.create(userId, {
  // Low-level creation uses the same storage, Relay, and protocol concepts.
  storage,
  relay,
  protocol: { postQuantum: "required", braid: "required" },
});
```

## Composition Rules

- Keep platform choices in `adapters`.
- Keep account/device identity in `identity`.
- Keep product security policy in `protocol`.
- Keep app logging, hooks, sealed sender, groups, and sender-key options at the
  top level so they match `DefaultSignalProtocolClient.create()`.
- Leave `protocol.postQuantum` unset or set it to `'required'`, its only
  value. A peer with no post-quantum prekeys is refused.
- Use `protocol.braid: 'disabled'` only when a product-reviewed constraint
  explicitly selects direct SPQR.

## Future Direction (Not Shipped)

> **Nothing in this section exists in the package.** `deviceStorage`,
> `createExpoDeviceStorage`, and `signal.messages.subscribe` are design intent
> for a future release, recorded here so the direction is public. Importing
> them fails today. The shipped API is everything above this heading.

The intended future shape makes platform setup a factory problem rather than a
store-by-store wiring exercise:

- a grouped `deviceStorage` adapter with `protocol`, `messages`, and `files`
  facets in place of today's flat `adapters.storage`
- a per-platform factory such as a future
  `createExpoDeviceStorage({ database, files })`
- a message-first receive path shaped like
  `signal.messages.subscribe({ conversationId }, handler)` in place of hook
  registration plus manual `startRelaySubscription()`

Low-level hooks would remain for advanced integrations. When this lands it will
be a breaking change and this guide will lead with it. Until then, wire the
current API.
