# Getting Started

> Navigation: [README](../README.md) | [ARCHITECTURE](../ARCHITECTURE.md) | **Getting Started**

Use the OpenE2EE Signal Protocol SDK with the OpenE2EE Signal Protocol Relay
for authenticated delivery. The SDK owns device-local encryption and protocol
state. The Relay holds public key material, encrypted envelopes, and routing
metadata. The relay never needs message plaintext or device private keys.

## Install

```bash
npm install @open-e2ee/signal-protocol-sdk
```

Install the runtime dependencies that your device-local store requires.
The [adapter guide](../ADAPTERS.md) lists the supported stores.

## What You Need

- A Relay project and its environment connection URL. In the application
  directory, `oe new` creates the project and its Sandbox environment, and it
  writes the connection URL to `.env.local` as `OPEN_E2EE_SIGNAL_RELAY_URL`. In
  a Next.js, Expo, or Vite application, the name has the public prefix of the
  framework, for example `EXPO_PUBLIC_OPEN_E2EE_SIGNAL_RELAY_URL`. An `oe`
  release before 5.0.0 wrote the earlier name, such as
  `EXPO_PUBLIC_OPEN_E2EE_RELAY_URL`. The examples read the new name first and
  the earlier name second.
- A `getIdentityAssertion` callback that returns a short-lived signed assertion.
- Device-local storage for private keys, sessions, and delivery state.
- Application storage for decrypted messages and attachment bytes.

A Sandbox environment uses device-owned identity. `hostedSignalProtocolRelaySandboxIdentity`
creates its `getIdentityAssertion` callback. The callback keeps a key in the device-local store. It signs each assertion
with that key. The device gets the same account each time it registers.

A device that loses its store loses that Sandbox account. The helper works only in a Sandbox environment.

Production supports application-bound and explicitly configured device-owned
accounts. For application-bound accounts, `getIdentityAssertion` returns a
short-lived Relay-specific assertion from your backend after it verifies the
server session and current application membership. With a
[native Clerk or Firebase profile](./RECIPES.md#native-provider-profiles),
`getIdentityAssertion` returns the provider token instead, and no backend
assertion is needed.

Device-owned accounts prove possession of a persistent account key. They do
not bind to an application login, and provider sign-in cannot recover a lost
account key. For device-owned accounts, pass
`hostedSignalProtocolRelayDeviceOwnedIdentity(storage)` as `getIdentityAssertion`. The SDK
does not supply an identity provider or a relay server implementation.
See [identity and authentication](https://docs.open-e2ee.dev/signal-relay/identity)
for Production configuration.

For a tested backend path, see the [Better Auth recipe](https://docs.open-e2ee.dev/signal-relay/better-auth)
and the [application callback recipe](./RECIPES.md#application-bound-identity-callback).

## Setup Sequence

1. Run `oe new` to create the Relay project and its Sandbox environment.
2. Open the device-local store for the device.
3. Create the client with `createHostedSignalProtocolClient()`. In a Sandbox
   environment, pass `hostedSignalProtocolRelaySandboxIdentity(storage)` as
   `hosted.getIdentityAssertion`.
4. Register a receive handler that persists decrypted messages.
5. Start the relay subscription.

The hosted factory authenticates and registers the current device, then publishes
its public prekeys. A linked device gets the account identity by device
transfer or by a channel that the application owns, then joins the account
with `linkHostedSignalProtocolRelayDevice()`. Only the primary device (device 1)
can link a device. That call runs in one process that holds the primary
device's store and the new device's store. It copies each group master key from
the primary device and gives the new device its own registration ID.

It refuses a new device's store that already lists a group, with
`HostedSignalProtocolRelayDeviceLinkError`. See the [device guide](../device/README.md). The
default policy requires post-quantum session establishment and Braid
ratcheting.

A new device with an empty store can also join with the two-device link. The
new device calls `joinHostedSignalProtocolRelayAccount()` and shows a link
code. The primary device scans the code and calls
`approveHostedSignalProtocolRelayDeviceLink()`. Show a confirmation screen on
the primary device before it approves.

The link token expires after 10 minutes, and an account has at most 5 devices.
SDK 14.6.0 and later ship these calls. See
[`joinHostedSignalProtocolRelayAccount()`](./api/functions/joinHostedSignalProtocolRelayAccount.md)
and
[`approveHostedSignalProtocolRelayDeviceLink()`](./api/functions/approveHostedSignalProtocolRelayDeviceLink.md).

Private keys can move between the devices of one user. They move only inside an
end-to-end encrypted envelope.

Omit `hosted.adapter` when linking through the OpenE2EE Signal Protocol Relay.
The SDK uses the active device's stored session and persists the linked session
before synchronization. It does not register another account or request another
provider assertion. An explicit adapter keeps application-owned composition.
Retry with the same stores to retain the original operation and prekeys.

## Expo Client

<!-- doc-snippet:skip requires-external-context -->
```ts
import {
  createHostedSignalProtocolClient,
  hostedSignalProtocolRelaySandboxIdentity,
} from "@open-e2ee/signal-protocol-sdk";
import { expoStore } from "@open-e2ee/signal-protocol-sdk/local/store/expo";

const storage = await expoStore();
const signal = await createHostedSignalProtocolClient({
  adapters: { storage },
  hosted: {
    relayUrl: process.env.EXPO_PUBLIC_OPEN_E2EE_SIGNAL_RELAY_URL ?? process.env.EXPO_PUBLIC_OPEN_E2EE_RELAY_URL!,
    // Sandbox only. Select the Production identity mode explicitly.
    getIdentityAssertion: hostedSignalProtocolRelaySandboxIdentity(storage),
  },
});
```

Complete the [Expo database setup](../local/store/expo/README.md) before creating
the client. Use a Sandbox connection URL during development. Keep each
account's device-local state separate.

## Custom Transport

Advanced integrations can use `createSignalProtocolClient()` with an
application-owned `SignalProtocolRelayServer` client transport. That transport
connects to an authenticated backend. The [interface guide](./INTERFACES.md)
defines the contract. The published SDK contains no relay server implementation.

## Receive Messages

Register a receive hook before starting the relay subscription:

<!-- doc-snippet:skip requires-external-context -->
```ts
signal.registerHook("onMessageDecrypted", async (message) => {
  // Decrypted content belongs in your app database, not in the relay.
  await appMessages.insert({
    messageId: message.messageId,
    conversationId: message.conversationId,
    senderId: message.senderId,
    senderDeviceId: message.senderDeviceId,
    body: message.content,
    receivedAt: message.receivedAt,
  });
});

// Subscribing starts encrypted envelope delivery and local decryption.
signal.startRelaySubscription();
```

The package does not own your product database or UI state. It decrypts messages
and hands the app a `DecryptedEnvelope`.

## Send Messages

Send by recipient user ID for normal one-to-one and multi-device delivery:

<!-- doc-snippet:skip requires-external-context -->
```ts
await signal.send("bob", "hello");
```

For structured app messages, pass an object:

<!-- doc-snippet:skip requires-external-context -->
```ts
await signal.send("bob", {
  body: "hello",
  conversationId: "dm:alice_bob",
  timestamp: Date.now(),
});
```

A new send accepts a `timestamp` at most 5 minutes ahead of the SDK clock and
at most 24 hours behind it. For any other value, `send()` throws
`InvalidSendTimestampError` and stores or posts nothing. Omit `timestamp`, and
the SDK uses its clock.

From the Relay release that follows v2026.10.25, the Relay admits a mailbox
delivery epoch in the same window. It also admits a new group fan-out
operation in that window. Earlier Relay releases admit a new operation only within 5
minutes of its epoch. On an earlier Relay release, a time 5 minutes to 24 hours
old passes the SDK check. The Relay returns `OPERATION_EXPIRED`.

The SDK check uses the
same bounds, so the SDK refuses an application-supplied time before any post.

Each send timestamp is unique per sender device. A new send with a `timestamp`
that a different send of the device used throws `InvalidSendTimestampError`
with the reason `already_used`. It stores or posts nothing.

When a different
send used the value that the SDK reads from its clock, the SDK moves to the
next free millisecond. The SDK's own sends, the profile key offer and the
sender key distribution, reserve from the same index of the device. So a
`timestamp: Date.now()` can get `already_used` when your app did not use the
value again. Omit `timestamp`, or send again with no `timestamp` on
`already_used`. Read the timestamp of the send in `SendResult.clientTimestamp`.

After the SDK stores a send, a retry with the same `clientMessageId` keeps
the original timestamp. A send that failed before the SDK stored it gets a new
timestamp on retry. A manual resend and a retry answer keep the original
timestamp.

A hosted client sends a sealed 1:1 message only when you pass
`hosted.profileKeys`, and only to a contact whose profile key `contacts` holds.
The client identifies each other 1:1 message, so the Relay sees its sender.
Until the client holds a contact's profile key, it identifies messages to that
contact. Those messages carry the profile key of this account.

## Attachments

The hosted factory supplies the Relay object store for encrypted
attachments. Configure the media callbacks below to read local bytes and
save attachment references and downloaded bytes.

<!-- doc-snippet:skip requires-external-context -->
```ts
import { createHostedSignalProtocolClient, media } from "@open-e2ee/signal-protocol-sdk";

const signalRelayUrl = process.env.OPEN_E2EE_SIGNAL_RELAY_URL!;
const signal = await createHostedSignalProtocolClient({
  hosted: { relayUrl: signalRelayUrl, getIdentityAssertion },
  adapters: {
    storage,
  },
  media: {
    preparedUploads: appPreparedUploads,
    maxPreparedUploadBytes: appUploadBudgetBytes,
    loadLocalAttachment: async ({ localMediaId }) =>
      appDraftMedia.readBytes(localMediaId),
    saveUploadedAttachment: async ({ localMediaId, attachment }) =>
      appMediaPointers.save(localMediaId, attachment),
    saveDownloadedAttachment: async ({ attachmentId, downloaded }) =>
      appMediaCache.save(attachmentId, downloaded.data),
    deleteLocalAttachment: async ({ attachmentId }) =>
      appMediaCache.delete(attachmentId),
  },
});
```

For an application-owned relay and object broker, use
`createSignalProtocolClient` with `adapters.remoteObjectStore`. The
[client composition guide](CLIENT_COMPOSITION.md#attachments) shows the
Convex R2 adapter with that factory. The hosted factory supplies its own
Relay object store and does not accept a replacement.

For Amazon S3 or S3-compatible storage, use the framework-neutral adapter with
an authenticated application-backend broker:

<!-- doc-snippet:skip requires-external-context -->
```ts
import { s3ObjectStore } from "@open-e2ee/signal-protocol-sdk/remote/object-store/s3";

const remoteObjectStore = s3ObjectStore({
  broker: {
    createUpload: (input) => storageApi.createS3Upload(input),
    createDownload: (input) => storageApi.createS3Download(input),
    completeUpload: (input) => storageApi.completeS3Upload(input),
    deleteObject: (input) => storageApi.deleteS3Object(input),
  },
});
```

Keep AWS credentials and AWS SDK clients on that backend. The app should
receive only narrowly scoped, short-lived upload, download, and delete
operations.

Send bytes when the attachment travels as its own encrypted message:

<!-- doc-snippet:skip requires-external-context -->
```ts
const controller = new AbortController();

await signal.send("bob", photoBytes, {
  isBinary: true,
  mimeType: "image/jpeg",
  fileName: "photo.jpg",
  width: 1200,
  height: 800,
  thumbnail: thumbnailBase64,
  attachment: {
    transfer: media.createTusMediaAttachmentTransfer({
      chunkSizeBytes: 1024 * 1024,
    }),
    signal: controller.signal,
    policy: media.MEDIA_ATTACHMENT_POLICY_PRESETS.Image,
    onProgress: (event) => {
      console.log(
        event.operation,
        event.phase,
        event.bytesTransferred,
        event.totalBytes,
      );
    },
  },
});
```

Upload first when your app message format embeds the attachment pointer inside a
larger payload:

<!-- doc-snippet:skip requires-external-context -->
```ts
const attachment = await signal.uploadAttachment(photoBytes, {
  mimeType: "image/jpeg",
  fileName: "photo.jpg",
  width: 1200,
  height: 800,
  thumbnail: thumbnailBase64,
  attachment: {
    transfer: media.createTusMediaAttachmentTransfer({
      chunkSizeBytes: 1024 * 1024,
    }),
    policy: media.MEDIA_ATTACHMENT_POLICY_PRESETS.Image,
  },
});

await signal.send("bob", {
  body: "trip photo",
  attachments: [attachment],
  timestamp: Date.now(),
});
```

Progress callbacks include `retry` events with `reason`, `status`, and
`retryInMs` so product code can distinguish an expired upload/download URL from
a generic transient failure.

`attachment.transfer` is where production apps plug in their foreground or
background transfer adapter. The Signal Protocol client still owns encryption, digest
verification, retries, and pointer metadata. The adapter owns how bytes move
over the network.

If your object store returns TUS credentials, including `protocol: 'tus'`, the
client uses the built-in TUS transfer helper
automatically. Passing `media.createTusMediaAttachmentTransfer()` explicitly is
useful when the app needs custom chunk sizing or a platform-specific `fetch`.

For downloads in JavaScript runtimes, `media.createByteRangeMediaAttachmentTransfer()`
provides a reviewed HTTP `Range` adapter. It validates `Content-Range`, forwards
signed download headers from the object store, and emits checkpoints. It resumes
from a non-zero offset only when your app provides the partial ciphertext prefix
through a partial-byte store. Native background download code should implement the same
`MediaAttachmentTransfer` interface.

For background-safe uploads, use the durable client operation. The current API
persists bounded recovery metadata through the existing Signal Protocol storage
adapter. The operation tries the upload when it is due and
returns either a completed pointer or a pending job id for later recovery:

<!-- doc-snippet:skip requires-external-context -->
```ts
const upload = await signal.media.upload(
  {
    localMediaId: draftMedia.id,
    contentType: draftMedia.contentType,
    size: draftMedia.byteLength,
    policy: media.MEDIA_ATTACHMENT_POLICY_PRESETS.Video,
  },
  {
    transfer: media.createTusMediaAttachmentTransfer({
      chunkSizeBytes: 1024 * 1024,
    }),
    onCheckpoint: appMediaTransfers.save,
  },
);

if (upload.status === "completed") {
  await appComposer.attach(upload.attachment);
}
```

Run pending durable media work on app startup, foreground resume, or from a
background task:

<!-- doc-snippet:skip requires-external-context -->
```ts
await signal.media.processPending({
  limit: 10,
  transfer: appMediaTransferAdapter,
  onCheckpoint: appMediaTransfers.save,
});
```

On receive, ask the media planner what work this device should do. Your app
supplies the IDs it has already processed or cached. The Signal Protocol package
returns the safe next step, and it does not take ownership of your app database:

<!-- doc-snippet:skip requires-external-context -->
```ts
const mediaWork = media.planMediaAttachmentProcessing({
  attachment,
  senderUserId,
  timestamp: messageTimestamp,
  processedDeliveryIds: await appMessages.processedMediaDeliveryIds(),
  cachedAttachmentIds: await appMediaCache.attachmentIds(),
  openedViewOnceDeliveryIds: await appMediaCache.openedViewOnceDeliveryIds(),
});

if (mediaWork.shouldPersistMessage) {
  await appMessages.insert(message);
}

if (mediaWork.cleanup?.deleteLocalCache) {
  await appMediaCache.delete(mediaWork.cleanup.storageId);
}

if (mediaWork.downloadJob) {
  await signal.media.download(
    {
      attachment,
      senderUserId,
      timestamp: messageTimestamp,
      processedDeliveryIds: await appMessages.processedMediaDeliveryIds(),
      cachedAttachmentIds: await appMediaCache.attachmentIds(),
      openedViewOnceDeliveryIds:
        await appMediaCache.openedViewOnceDeliveryIds(),
    },
    {
      transfer: media.createByteRangeMediaAttachmentTransfer({
        chunkSizeBytes: 1024 * 1024,
        partialStore: appMediaTransfers.partialStore(),
      }),
    },
  );
}
```

If the planner says this device needs media bytes, pass the decrypted attachment
pointer back to the client. The client downloads encrypted blob bytes, verifies
the digest, authenticates the stream, and returns plaintext bytes:

<!-- doc-snippet:skip requires-external-context -->
```ts
if (mediaWork.shouldDownload) {
  const downloaded = await signal.downloadAttachment(attachment, {
    transfer: media.createByteRangeMediaAttachmentTransfer({
      chunkSizeBytes: 1024 * 1024,
      partialStore: appMediaTransfers.partialStore(),
    }),
    policy: media.MEDIA_ATTACHMENT_POLICY_PRESETS.Image,
    resume: await appMediaTransfers.resumeState(mediaWork.attachmentId),
    onCheckpoint: (checkpoint) => appMediaTransfers.save(checkpoint),
    onProgress: (event) => {
      console.log(
        event.operation,
        event.phase,
        event.bytesTransferred,
        event.totalBytes,
      );
    },
  });

  await appMediaCache.put(mediaWork.attachmentId, downloaded.data);

  console.log(downloaded.contentType);
  console.log(downloaded.data.byteLength);
  console.log(downloaded.width, downloaded.height, downloaded.thumbnail);
}
```

If the attachment is view-once, plan the local cleanup and linked-device sync
after the user opens it:

<!-- doc-snippet:skip requires-external-context -->
```ts
const opened = media.planMediaAttachmentOpen({
  attachment,
  senderUserId,
  timestamp: messageTimestamp,
});

if (opened.viewOnceOpenSync) {
  await signal.syncViewOnceOpenToLinkedDevices(opened.viewOnceOpenSync);
}

if (opened.cleanup?.deleteLocalCache) {
  await appMediaCache.delete(opened.cleanup.storageId);
}

if (opened.cleanup?.deleteRemoteBlob) {
  await signal.deleteRemoteAttachment(attachment);
}
```

A message delete or expiration can remove media on this account's linked
devices. Plan and sync the deletion after your app applies the local cleanup:

<!-- doc-snippet:skip requires-external-context -->
```ts
const deleteSync = media.planMediaAttachmentDeleteSync({
  attachment,
  reason: media.MediaAttachmentCleanupReason.MessageDeleted,
  deletedAt: Date.now(),
});

await appMediaCache.delete(deleteSync.storageId);
await signal.syncMediaAttachmentDeleteToLinkedDevices(deleteSync);
```

When a worker must do the cleanup, use the durable client operation:

<!-- doc-snippet:skip requires-external-context -->
```ts
await signal.media.cleanup(
  {
    cleanup: media.planMediaAttachmentCleanup(
      attachment,
      media.MediaAttachmentCleanupReason.MessageExpired,
    ),
    includeLocal: true,
    includeRemote: true,
    includeSync: true,
  },
  {
    transfer: appMediaTransferAdapter,
  },
);
```

## Security Policy

The default is:

<!-- doc-snippet:skip configuration-only -->
```ts
import type { SignalProtocolConfig } from '@open-e2ee/signal-protocol-sdk';

export const protocol: SignalProtocolConfig = {
  postQuantum: 'required',
  braid: 'required',
};
```

Leave it unset. `'required'` is the only `postQuantum` value. See
[Protocol Policy](./PROTOCOL_POLICY.md) for the rare case where you would set
`braid: 'disabled'`.

## Where To Go Next

- [Client Composition](./CLIENT_COMPOSITION.md): app setup and adapter shape.
- [Protocol Policy](./PROTOCOL_POLICY.md): security policy choices.
- [Adapters](../ADAPTERS.md): device-local storage, client transports, and remote
  object stores.
- [API Reference](./api/README.md): generated TypeScript API docs.
