# Package Surface

> Navigation: [README](../README.md) | [ARCHITECTURE](../ARCHITECTURE.md) |
> [ADAPTERS](../ADAPTERS.md) | [Recipes](./RECIPES.md) |
> [Security Model](./SECURITY.md) | [API Reference](./api/README.md)

This document is the complete public surface of
`@open-e2ee/signal-protocol-sdk`. It lists what the root package exports, every
supported subpath, and the adapter implementations that ship with the package.
It also defines the vocabulary the rest of the documentation assumes.

## Core model

- `createHostedSignalProtocolClient()` connects to the OpenE2EE Signal Protocol Relay.
- `resumeHostedSignalProtocolClient()` requires existing permanent Signal identity keys, device-authentication authority and a hosted session. It never requests a provider assertion or registers a replacement.
- `createSignalProtocolClient()` composes an application-owned client transport.
- `DefaultSignalProtocolClient` is the class the factory returns. `SignalProtocolClient` is its interface.
- Every client requires `storage`, which owns local encryption state for one
  user/device.
- `relay` is optional for local development. Real messaging apps use it for
  key sync, message delivery, device fanout, and linked-device workflows.
- The client enables secure post-quantum defaults without extra configuration.
- The SDK pins identity trust to one versioned X25519 + Ed25519 composite tuple
  per `(userId, identityType)`. First contact remains unverified TOFU.
- The root package is intentionally core-only. Platform and backend adapters
  live on explicit subpaths.

OpenE2EE is the project and package namespace. It is not the name of a single
protocol client. The protocol-specific package and client names leave that
namespace clear for other E2EE protocol implementations, such as a future
[Messaging Layer Security (MLS)](https://www.rfc-editor.org/rfc/rfc9420.html)
package. They do not imply that one client spans multiple protocols.

## Setup sequence

For a production app, the normal startup shape is:

1. Configure a Relay project and identity provider in the OpenE2EE console.
2. Open device-local storage for the signed-in user.
3. Create the client with `createHostedSignalProtocolClient()`.
4. Register receive hooks and start relay subscription delivery.

The hosted factory registers the device and publishes its public prekeys.

## Root package

Use the root package for core portable APIs:

<!-- doc-snippet:skip requires-external-context -->
```ts
import {
  SignalProtocolClient,
  createHostedSignalProtocolClient,
  createSignalProtocolClient,
  ProtocolAddress,
  BraidPolicy,
  PostQuantumPolicy,
  keys,
  safety,
  encoding,
} from "@open-e2ee/signal-protocol-sdk";
```

The root package intentionally does not re-export platform-bound adapters like
Expo storage or the Convex R2 object store.

The published package contains client APIs and transport contracts. Relay
servers, group authorization engines, credential issuers, and server signing
implementations are outside the published SDK.

## Integration subpaths

- `@open-e2ee/signal-protocol-sdk/remote/signal-relay`
- `@open-e2ee/signal-protocol-sdk/remote/signal-relay/types`
- `@open-e2ee/signal-protocol-sdk/remote/object-store`
- `@open-e2ee/signal-protocol-sdk/remote/object-store/convex-r2`
- `@open-e2ee/signal-protocol-sdk/remote/object-store/s3`
- `@open-e2ee/signal-protocol-sdk/client`
- `@open-e2ee/signal-protocol-sdk/client/config`
- `@open-e2ee/signal-protocol-sdk/client/compose`
- `@open-e2ee/signal-protocol-sdk/client/constants`
- `@open-e2ee/signal-protocol-sdk/client/endorsement-manager`
- `@open-e2ee/signal-protocol-sdk/client/headless`
- `@open-e2ee/signal-protocol-sdk/client/types`
- `@open-e2ee/signal-protocol-sdk/device`
- `@open-e2ee/signal-protocol-sdk/device/constants`
- `@open-e2ee/signal-protocol-sdk/device/device-id`
- `@open-e2ee/signal-protocol-sdk/device/expo`
- `@open-e2ee/signal-protocol-sdk/device/lifecycle`
- `@open-e2ee/signal-protocol-sdk/device/react-native`
- `@open-e2ee/signal-protocol-sdk/encoding`
- `@open-e2ee/signal-protocol-sdk/encoding/hex`
- `@open-e2ee/signal-protocol-sdk/files`
- `@open-e2ee/signal-protocol-sdk/groups`
- `@open-e2ee/signal-protocol-sdk/hooks`
- `@open-e2ee/signal-protocol-sdk/keys`
- `@open-e2ee/signal-protocol-sdk/keys/generation`
- `@open-e2ee/signal-protocol-sdk/keys/types`
- `@open-e2ee/signal-protocol-sdk/logger`
- `@open-e2ee/signal-protocol-sdk/media`
- `@open-e2ee/signal-protocol-sdk/blocking`
- `@open-e2ee/signal-protocol-sdk/profile`
- `@open-e2ee/signal-protocol-sdk/safety`
- `@open-e2ee/signal-protocol-sdk/sealed-sender`
- `@open-e2ee/signal-protocol-sdk/server-clock`
- `@open-e2ee/signal-protocol-sdk/local/store`
- `@open-e2ee/signal-protocol-sdk/local/store/expo`
- `@open-e2ee/signal-protocol-sdk/local/store/key-value`
- `@open-e2ee/signal-protocol-sdk/local/store/key-value/realm`
- `@open-e2ee/signal-protocol-sdk/local/store/conformance`
- `@open-e2ee/signal-protocol-sdk/local/store/memory`
- `@open-e2ee/signal-protocol-sdk/local/store/node`
- `@open-e2ee/signal-protocol-sdk/local/store/react-native`
- `@open-e2ee/signal-protocol-sdk/local/store/web`
- `@open-e2ee/signal-protocol-sdk/local/store/web-sqlite`
- `@open-e2ee/signal-protocol-sdk/local/vault`
- `@open-e2ee/signal-protocol-sdk/local/vault/electron-safe-storage`
- `@open-e2ee/signal-protocol-sdk/local/vault/expo-secure-store`
- `@open-e2ee/signal-protocol-sdk/local/vault/react-native-keychain`
- `@open-e2ee/signal-protocol-sdk/types`
- `@open-e2ee/signal-protocol-sdk/types/address`
- `@open-e2ee/signal-protocol-sdk/types/messages`
- `@open-e2ee/signal-protocol-sdk/types/utils`
- `@open-e2ee/signal-protocol-sdk/username`
- `@open-e2ee/signal-protocol-sdk/username/link`
- `@open-e2ee/signal-protocol-sdk/utils/retry`
- `@open-e2ee/signal-protocol-sdk/zk/groups`
- `@open-e2ee/signal-protocol-sdk/zk/credentials`

### Development adapters

- `@open-e2ee/signal-protocol-sdk/local/store/memory`

### Deprecated subpaths

Each deprecated subpath loads the same module as its replacement. SDK 15.0.0
removes the deprecated subpaths.

| Deprecated subpath | Replacement |
| --- | --- |
| `@open-e2ee/signal-protocol-sdk/remote/relay` | `@open-e2ee/signal-protocol-sdk/remote/signal-relay` |
| `@open-e2ee/signal-protocol-sdk/remote/relay/types` | `@open-e2ee/signal-protocol-sdk/remote/signal-relay/types` |

`internal/**` is implementation-only and not part of the supported external API.

## Basic concepts

- **Client**: one running app instance for one account and one device.
- **User ID**: your app's stable account identifier.
- **Device ID**: `1` for the primary device. Linked devices use `2-5`.
- **Storage**: local encrypted state needed to keep conversations working across
  restarts.
- **Relay**: server-side public keys, device lists, encrypted envelope delivery,
  and linked-device coordination.
- **Object store**: optional remote storage for encrypted attachments.
- **Hooks**: callbacks where your app receives decrypted messages and stores them
  in its own database or UI state.

## Supported implementations

### Relay implementations

- `createHostedSignalProtocolClient()` from the package root for the OpenE2EE
  Signal Protocol Relay
- custom implementations via `SignalProtocolRelayServer`

### Storage implementations

- `ExpoSignalProtocolStore` / `await expoStore()` for Expo (the SDK owns the
  SQLCipher database, its key, and its migrations; `resetExpoStore()` deletes
  the database and opens an empty store; `createPreKeyMaintenanceStore(store)`
  runs replaced-prekey maintenance on an open store)
- `ReactNativeSignalProtocolStore` / `await reactNativeStore()` for
  bare React Native (the SDK owns the SQLCipher database on op-sqlite, its key
  in the react-native-keychain vault, and its migrations;
  `resetReactNativeStore()` deletes the database and opens an empty store)
- `WebSqliteSignalProtocolStore` / `await webSqliteStore()` for browsers with
  the origin private file system (the SDK owns the SQLite database in a Wasm
  worker, its key, and its migrations; the page's Content Security Policy
  needs `'wasm-unsafe-eval'`)
- `IndexedDbSignalProtocolStore` / `indexedDbStore()` for browsers without the
  origin private file system, where `webSqliteStore()` fails with
  `OPFS_UNAVAILABLE`
- `KeyValueSignalProtocolStore` / `keyValueStore()` for an application that
  brings its own key-value engine (provide your own key-value backend and
  verify it with the exported
  backend-conformance kit, or use `createRealmKeyValueBackend()` from
  `local/store/key-value/realm`; the value key lives in a secret vault)
- `NodeSignalProtocolStore` / `await nodeStore({ directory, vault })` for Node
  and the Electron main process (the SDK owns the SQLCipher database on the
  `better-sqlite3-multiple-ciphers` peer, its key, and its migrations;
  `resetNodeStore()` deletes the database and opens an empty store;
  `createPreKeyMaintenanceStore(store)` runs replaced-prekey maintenance on an
  open store; `sqliteDatabaseKeySlot(path)` names the vault slot of the key)
- `InMemorySignalProtocolStore` / `inMemoryStore()` for local development
- custom implementations via `SignalProtocolLocalStore`

### Remote object store

- `ConvexR2ObjectStore` via
  `@open-e2ee/signal-protocol-sdk/remote/object-store/convex-r2`
- `convexR2ObjectStore()` for Cloudflare R2 composition
- `S3ObjectStore` via `@open-e2ee/signal-protocol-sdk/remote/object-store/s3`
- `s3ObjectStore()` for brokered Amazon S3 or S3-compatible storage
- custom implementations via `SignalProtocolRemoteObjectStore`

`ConvexR2ObjectStore` is a client adapter for authenticated app-owned Convex
functions that wrap `@convex-dev/r2`. It is not the Convex component itself.
The application continues to own component installation, mounting,
configuration, authentication, authorization, persistence, credentials, and
the R2 bucket and broker implementation.
Both concrete adapters keep provider credentials in the application backend.

The remote object store is a normal integration point for encrypted
attachments and files, not a niche or internal-only adapter. Use
`attachment.transfer` when your app has a foreground, background, resumable, or
platform-native byte transfer implementation. The Signal Protocol package still
owns encryption, digest verification, retry decisions, and pointer metadata.

Object stores can return signed upload headers, and stores that return
`protocol: 'tus'` automatically use the built-in resumable TUS transfer helper.
You can also pass `media.createTusMediaAttachmentTransfer()` explicitly when
your app wants to tune the TUS fetch implementation or chunk size. Download
credentials can also return signed headers.

For JavaScript runtimes that need resumable downloads, use `media.createByteRangeMediaAttachmentTransfer()`. It
makes strict HTTP range requests, validates `Content-Range`, and persists
checkpoints. It resumes only when your app provides a partial-byte store for the
previous ciphertext prefix. Native background download integrations should
implement the same `MediaAttachmentTransfer` seam.

## Design notes

- `DefaultSignalProtocolClient.create()` requires `storage`. There are no hidden
  default adapters.
- `createSignalProtocolClient()` is the preferred composition helper when app
  code owns multiple adapters.
- Linked devices must already contain the account identity before
  `DefaultSignalProtocolClient.create(..., { deviceId: 2 })`. The application
  imports it by device transfer or by a channel that the application owns.
- Username-only apps typically run ACI-only. Phone-capable apps can enable both
  ACI and PNI with `enablePniKeys: true`.
- `protocol.postQuantum` and `protocol.braid` are product-facing policy.
  `'required'` is the only `postQuantum` value, and no classical key agreement
  exists. Advanced protocol strategy knobs remain available for diagnostics,
  telemetry, and protocol-level tuning.
- The package is workspace-friendly in this repo and dist-first for packed
  consumers.

## Module guides

- [Client](../client/README.md)
- [Device lifecycle, linking, and transfer](../device/README.md)
- [Keys and identity](../keys/README.md)
- [Local stores](../local/store/README.md)
- [Local secret vault](../local/vault/README.md)
- [Relay and remote object store](../remote/README.md)
- [Encrypted media](../media/README.md)
- [Encrypted files](../files/README.md)
- [Groups](../groups/README.md)
- [Safety numbers](../safety/README.md)
- [Encrypted profiles](../profile/README.md)
- [Usernames](../username/README.md)
- [Blocking](../blocking/README.md)
- [React hooks](../hooks/README.md)
- [Encoding](../encoding/README.md)
- [Public types](../types/README.md)
- [Zero-knowledge credentials and groups](../zk/README.md)
- [Documentation and comment standards](./DOCUMENTATION_STANDARDS.md)

## Resume an existing hosted device

Use `resumeHostedSignalProtocolClient({ adapters: { storage }, hosted: { relayUrl: signalRelayUrl } })`
when the application must preserve the device already held by its open store.
The SDK refuses missing, unreadable or changed required identity state. It never
falls back to registration, recovery or device linking. The default
`createHostedSignalProtocolClient()` behavior stays the same.

A successful resume renews and persists the authenticated device token. Normal
prekey maintenance and client startup, including automatic subscription when
the application configures receive hooks, still run. This API does not promise an unchanged
store or prove that the store contains every historical message/key.

The application owns the store and must not use it concurrently. A
`HostedSignalProtocolRelayResumeError` with `cleanupPending` retains a client that has not
completed `stop()`. Keep that error and call `retryCleanup()` only when cleanup is
selected. This retries the held stop, never resume or registration, and never
closes the application store. Preserve unresolved application operation state.
Do not display raw error causes or key material in a public error report.
