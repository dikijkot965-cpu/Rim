# React Hooks

The hooks module adapts client lifecycle operations to React components. It
includes key rotation, group membership, session health, relay connection
state, relay lifecycle, and single-flight helpers.

## Why it exists

The core SDK is framework-neutral. React hooks live on a separate package
subpath. Non-React consumers therefore do not load React, and UI code can
subscribe to SDK state without duplicating effect cleanup.

## Setup

Install the peers `react` 19.0.0 or later and `react-native` 0.83.6 or later.
The entry loads both, also in a web app: the relay lifecycle and key rotation
hooks read `AppState` from `react-native`.

```sh
npm install react react-native
```

## Usage

```tsx
import {
  useSignalProtocolRelayConnectionState,
  useSignalProtocolRelayLifecycle,
  useSessionHealth,
  type UseSignalProtocolRelayLifecycleOptions,
  type UseSignalProtocolRelayConnectionStateOptions,
  type UseSessionHealthOptions,
} from "@open-e2ee/signal-protocol-sdk/hooks";

function SignalLifecycle({ signal }: Pick<UseSignalProtocolRelayLifecycleOptions, "signal">) {
  useSignalProtocolRelayLifecycle({ signal });
  return null;
}

function OwnConnectionDot({ signal }: Pick<UseSignalProtocolRelayConnectionStateOptions, "signal">) {
  const { state } = useSignalProtocolRelayConnectionState({ signal });
  return <Dot online={state === "connected"} />;
}

function ConversationStatus({ signal, userId }: Pick<UseSessionHealthOptions, "signal" | "userId">) {
  const { health, isLoading } = useSessionHealth({ signal, userId });
  if (isLoading) return <p>Checking…</p>;
  return <p>{health?.status === "healthy" ? "Ready" : "Check the session"}</p>;
}
```

## Relay connection state

`useSignalProtocolRelayConnectionState({ signal })` returns the `SignalProtocolRelayConnectionState` of
the relay subscription on this device. The component renders again on each
transition, and the hook unsubscribes when the component unmounts. The state
is `stopped`, `connecting`, `connected`, or `reconnecting`. A `reason` tells
which site caused the last transition. The state is local to this device. It
is not presence and does not tell you about other users.

## Relay lifecycle

`useSignalProtocolRelayLifecycle({ signal })` stops the relay subscription when a React
Native app goes to the background and starts it again when the app becomes
active. The stop closes the socket with code 1000, so the Relay records a
client close. The Relay replays retained messages when the app becomes active.
The hook ignores `inactive` and has no grace delay. On web it does nothing:
a hidden desktop tab keeps its socket open by itself.

Set `keepOpenInBackground: true` to keep the socket open in the background,
for example while an Android foreground service runs. Outside React, call
`bindSignalProtocolRelayLifecycle(signal, AppState)` from
`@open-e2ee/signal-protocol-sdk/client`.

Do not call these hooks outside React components or custom hooks. Event callbacks from
`SignalProtocolClient.registerHook()` are a separate, framework-neutral API.

See the [client guide](../client/README.md) and
[API reference](../docs/api/README.md).
