# Troubleshooting Guide

> **Navigation**: [README](./README.md) | [ARCHITECTURE](./ARCHITECTURE.md) | **TROUBLESHOOTING**

Guide for debugging OpenE2EE Signal Protocol SDK encryption issues.

---

## Decision Tree

```
Error occurred?
     │
     ├─► "Identity key not found"
     │        └─► Did you use DefaultSignalProtocolClient.create()? (not constructor)
     │             └─► See: Initialization Errors
     │
     ├─► "Failed to establish session"
     │        └─► Is prekey bundle valid? (identityKey, signedPreKey required)
     │             └─► See: Session Establishment
     │
     ├─► "No session with address"
     │        └─► Is sessionId in "userId:deviceId" format?
     │             └─► Example: 'bob:1' not just 'bob'
     │
     ├─► "Failed to decrypt"
     │        ├─► Message out of order? → MKSKIPPED handles up to 1000 skipped
     │        ├─► Message too old? → Keys expire after 7 days
     │        └─► Wrong session? → Check sender address parsing
     │
     ├─► "MAC verification failed"
     │        └─► Data corrupted in transit? Check network/storage
     │
     ├─► "PreKeyBundle invalid"
     │        ├─► Signature verification failed → Recipient may have rotated keys
     │        └─► Missing fields → Fetch fresh bundle from server
     │
     └─► Performance issues?
              ├─► Initial load slow? → Key generation is one-time
              ├─► Encryption slow? → Kyber ops ~50ms (normal)
              └─► Memory issues? → Check MKSKIPPED cleanup
```

---

## Common Errors

### Installation Errors

**npm stops with `ERESOLVE` on a `react-native`, `expo`, or `expo-*` peer**

The SDK declares React Native and the Expo packages as optional peers. npm
checks an optional peer when your project installs that package. The ranges
start at React Native 0.83.6 and Expo SDK 55, and they have no upper bound.
Upgrade a project that is below those versions. Do not bypass the conflict
with `--force` or `--legacy-peer-deps`.

### Initialization Errors

**"Identity key not found - client not initialized"**

<!-- doc-snippet:skip requires-application-storage -->
```typescript
import { DefaultSignalProtocolClient, type SignalProtocolClientConfig } from '@open-e2ee/signal-protocol-sdk';

// Compile-only negative example. This function is never called.
function compileOnlyRejectsDirectConstruction(): void {
  // @ts-expect-error Initialize the client through its asynchronous factory.
  new DefaultSignalProtocolClient();
}

export function initializeSignal(
  userId: string,
  storage: SignalProtocolClientConfig['storage'],
): Promise<DefaultSignalProtocolClient> {
  return DefaultSignalProtocolClient.create(userId, { storage });
}
```

### Session Establishment

**"Failed to establish session"**

Make sure the prekey bundle is fresh and valid:

<!-- doc-snippet:skip requires-external-context -->
```typescript
import { ProtocolAddress, type DefaultSignalProtocolClient } from '@open-e2ee/signal-protocol-sdk';
import type { SignalProtocolRelayServer } from '@open-e2ee/signal-protocol-sdk/remote/signal-relay';

export async function establishBobSession(
  signal: DefaultSignalProtocolClient,
  relay: SignalProtocolRelayServer,
  bobId: string,
): Promise<void> {
  const address = ProtocolAddress.create(bobId, 1);
  const bundle = await relay.fetchPreKeyBundle(bobId, 1, undefined, 'aci');
  if (!bundle || !bundle.identity || !bundle.ecSignedPreKey) {
    throw new Error('Invalid prekey bundle');
  }
  await signal.establishSession(address, bundle);
}
```

### Device Address Format

**"No session with address"**

The serialized address form is `userId:deviceId`. Direct client methods take a
`ProtocolAddress` object. Create it with `ProtocolAddress.create(userId, deviceId)`.

<!-- doc-snippet:skip requires-external-context -->
```typescript
import { ProtocolAddress, type DefaultSignalProtocolClient } from '@open-e2ee/signal-protocol-sdk';

// Compile-only negative example. This function is never called.
async function compileOnlyRejectsSerializedAddress(signal: DefaultSignalProtocolClient): Promise<void> {
  // @ts-expect-error encryptMessage requires a ProtocolAddress object.
  await signal.encryptMessage('bob', 'Hello');
}

export async function encryptToBobDevices(signal: DefaultSignalProtocolClient): Promise<void> {
  await signal.encryptMessage(ProtocolAddress.create('bob', 1), 'Hello');
  await signal.encryptMessage(ProtocolAddress.create('bob', 2), 'Hello');
}
```

### Out-of-Order Messages

The protocol handles out-of-order messages automatically via MKSKIPPED. For failures:

1. Check that both parties established sessions
2. Verify message counters are not too far apart (default `maxSkip` limit: 25000)
3. Check that no sender or transport duplicates messages
4. Check that skipped keys did not expire (7-day default)

### Decryption Failures

**"Failed to decrypt" or "MAC verification failed"**

| Symptom     | Cause                    | Solution                                         |
| ----------- | ------------------------ | ------------------------------------------------ |
| MAC failed  | Data corrupted           | Check network, verify no modification in transit |
| Wrong key   | Session mismatch         | Verify sessionId matches sender                  |
| Key expired | Message > 7 days old     | Cannot recover; re-send message                  |
| Counter gap | > 25000 messages skipped | Increase `maxSkip` or re-establish session       |

---

## Debugging Tools

### Check Client State

<!-- doc-snippet:skip requires-external-context -->
```typescript
// Get encryption statistics
const stats = await signal.getStats();
console.log('Has identity key:', stats.hasIdentityKey);
console.log('Session count:', stats.sessionCount);
console.log('OneTime prekeys remaining:', stats.oneTimePreKeysCount);
```

### Check Session Status

<!-- doc-snippet:skip requires-external-context -->
```typescript
import { ProtocolAddress, type DefaultSignalProtocolClient } from '@open-e2ee/signal-protocol-sdk';

export async function checkBobSession(signal: DefaultSignalProtocolClient): Promise<void> {
  const address = ProtocolAddress.create('bob', 1);
  const hasSession = await signal.hasSession(address);
  console.log('Has session with bob:1:', hasSession);
}
```

### Enable Debug Logging

<!-- doc-snippet:skip requires-external-context -->
```typescript
import { DefaultSignalProtocolClient } from '@open-e2ee/signal-protocol-sdk';
import { inMemoryStore } from '@open-e2ee/signal-protocol-sdk/local/store/memory';

const signal = await DefaultSignalProtocolClient.create('alice', {
  storage: inMemoryStore(),
  enableDebugLogging: true,
});
// The in-memory adapter is for this local example. Select a protected platform store in an application.
```

### Verify Identity Keys

<!-- doc-snippet:skip requires-external-context -->
```typescript
// Generate the composite safety number from the locally pinned identity.
const safetyNumber = await signal.verify(theirUserId);
console.log('Safety number:', safetyNumber.numeric);
// Compare this with the other party via video call, in person, etc.
await signal.confirmSafetyNumber(safetyNumber.confirmation);
```

---

## Layer-Specific Debugging

| Issue                     | Layer               |
| ------------------------- | ------------------- |
| Key generation            | `internal/crypto/`  |
| Key types, bundles        | `keys/`             |
| Key exchange (PQXDH)      | `internal/protocol/` |
| Ratchet state             | `internal/protocol/` |
| Session state             | `internal/session/` |
| Multi-device              | `internal/sesame/`  |

---

## Related Guides

- **[docs/ERROR_HANDLING.md](./docs/ERROR_HANDLING.md)** - Error classes, codes, and recovery patterns
- **[SECURITY.md](./SECURITY.md)** - Security-related debugging

---

## Performance Issues

### Expected Timings

| Operation                   | Expected Time | Notes                 |
| --------------------------- | ------------- | --------------------- |
| Key generation (first time) | 500-1000ms    | One-time cost         |
| Session establishment       | 100-200ms     | Includes Kyber ops    |
| Message encrypt             | 5-20ms        | Per message           |
| Message decrypt             | 5-20ms        | Per message           |
| Kyber encapsulate           | ~50ms         | Post-quantum overhead |

### Memory Considerations

- **MKSKIPPED keys**: Up to 1000 stored per session (DoS protection)
- **Key expiration**: Automatic cleanup after 7 days
- **Session cleanup**: Call `deleteSession()` for inactive contacts

---

**Last Updated**: 2025-12-01
**Maintainer**: OpenE2EE Engineering Team
