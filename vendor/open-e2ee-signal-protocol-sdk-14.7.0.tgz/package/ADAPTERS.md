# Adapters Reference

> Navigation: [README](./README.md) | [ARCHITECTURE](./ARCHITECTURE.md) | [SECURITY](./docs/SECURITY.md) | **ADAPTERS**

`@open-e2ee/signal-protocol-sdk` uses explicit dependency injection for infrastructure. The package core does not assume a database, backend, or platform.

## Adapter Roles

### Relay: `SignalProtocolRelayServer`

The relay interface handles server-owned Signal Protocol state:

- prekey upload and fetch
- device registration and device listing
- envelope delivery / message fanout

Use:

- the OpenE2EE Signal Protocol Relay through `createHostedSignalProtocolClient()` from the package root
- a custom client transport that implements `SignalProtocolRelayServer`

The published package contains client code and transport contracts. It does not
include a relay server implementation.

### Storage: `SignalProtocolLocalStore`

The storage interface handles client-owned Signal Protocol state:

- account identity keys
- contact identities / TOFU
- prekeys
- sessions
- local message records and related metadata

Use:

- `expoStore` and `ExpoSignalProtocolStore` from `@open-e2ee/signal-protocol-sdk/local/store/expo` (`await expoStore()` opens the SDK-owned SQLCipher database; `resetExpoStore` deletes it and opens an empty one; `createPreKeyMaintenanceStore` takes an open store)
- `reactNativeStore` and `ReactNativeSignalProtocolStore` from `@open-e2ee/signal-protocol-sdk/local/store/react-native` (bare React Native: `await reactNativeStore()` opens the SDK-owned SQLCipher database on op-sqlite with its key in the react-native-keychain vault; `resetReactNativeStore` deletes it and opens an empty one; `createPreKeyMaintenanceStore` takes an open store)
- `webSqliteStore` and `WebSqliteSignalProtocolStore` from `@open-e2ee/signal-protocol-sdk/local/store/web-sqlite` (browsers: `await webSqliteStore()` opens the SDK-owned SQLite database in the origin private file system, encrypted in a Wasm worker; `resetWebSqliteStore` deletes it and opens an empty one; `createPreKeyMaintenanceStore` takes an open store; the page's Content Security Policy must allow `'wasm-unsafe-eval'`)
- `IndexedDbSignalProtocolStore` from `@open-e2ee/signal-protocol-sdk/local/store/web` (browsers without the origin private file system, where `webSqliteStore` fails with `OPFS_UNAVAILABLE`)
- `KeyValueSignalProtocolStore` from `@open-e2ee/signal-protocol-sdk/local/store/key-value` (use `await KeyValueSignalProtocolStore.create({ storage, vault })` with a caller-provided key-value backend, verified with the exported backend-conformance kit, and a secret vault that holds the value key)
- `createRealmKeyValueBackend` from `@open-e2ee/signal-protocol-sdk/local/store/key-value/realm` (a key-value backend over an application-installed Realm)
- `createTransactionalKeyValueBackend` from `@open-e2ee/signal-protocol-sdk/local/store/key-value` (a key-value backend over another engine's transaction, through a synchronous `KeyValueTransaction` handle; the SDK applies each `atomicWrite` batch inside the transaction)
- `nodeStore` and `NodeSignalProtocolStore` from `@open-e2ee/signal-protocol-sdk/local/store/node` (`await nodeStore({ directory, vault })` opens the SDK-owned SQLCipher database on the `better-sqlite3-multiple-ciphers` peer; `resetNodeStore` deletes it and opens an empty one; one process at a time owns the file; `createPreKeyMaintenanceStore` takes an open store)
- `InMemorySignalProtocolStore` from `@open-e2ee/signal-protocol-sdk/local/store/memory`
- or a custom implementation

A custom implementation can be any object that implements `SignalProtocolLocalStore`. The client does not check its class, and no client feature requires a store class. Managed groups work on a custom store, including group message reception on the Relay subscription and on a pull. A custom store must meet the [storage implementation](#storage-implementations) expectations and pass the local store conformance kit.

On React Native and Expo, the SDK reads random bytes only from the global `crypto.getRandomValues`. Install `react-native-get-random-values` 2.x or `react-native-quick-crypto`, and load it before the first SDK call. Without a global source, the SDK throws `SecureRandomUnavailableError`.

### Local secret vault: `SignalProtocolLocalSecretVault`

The device ID, the device-lifecycle state, the own profile key, and the value
key of the key-value store live in the vault that the application passes. The SDK does not choose a vault, and it
never writes these secrets to `localStorage`. A call without a vault throws an
`EncryptionError` with code `SECRET_VAULT_REQUIRED`.

Use:

- `ExpoSecureStoreSignalProtocolSecretVault` from `@open-e2ee/signal-protocol-sdk/local/vault/expo-secure-store`
- or a custom implementation

### Device metadata

The shared `./device` entries take platform metadata as an input and omit each
field that the application does not supply. These entries read it from the
platform:

- `@open-e2ee/signal-protocol-sdk/device/expo` (`react-native`, `expo-constants`, `expo-device`)
- `@open-e2ee/signal-protocol-sdk/device/react-native` (`react-native`, `react-native-device-info`)

### Remote object store: `SignalProtocolRemoteObjectStore`

Optional encrypted file upload/download support for two-layer attachment encryption.

Use:

- `ConvexR2ObjectStore` from `@open-e2ee/signal-protocol-sdk/remote/object-store/convex-r2`
- `S3ObjectStore` from `@open-e2ee/signal-protocol-sdk/remote/object-store/s3`
- or a custom implementation

Both concrete adapters call an authenticated application-backend broker. The
app runtime receives only narrowly scoped, short-lived operations. Provider
credentials remain on the backend.

Upload requests carry a retry/idempotency `requestId`. The backend returns the
canonical `objectId` used in encrypted attachment pointers. Provider keys stay
private to the backend. The application supplies the object-store broker and
owns its authentication, authorization, persistence, and provider integration.

### Local secret vault: `SignalProtocolLocalSecretVault`

Stores small bootstrap secrets, such as a database encryption key, in the
platform secret store, apart from the local store.

Use:

- `ExpoSecureStoreSignalProtocolSecretVault` from `@open-e2ee/signal-protocol-sdk/local/vault/expo-secure-store`
- `ReactNativeKeychainSignalProtocolSecretVault` from `@open-e2ee/signal-protocol-sdk/local/vault/react-native-keychain` (optional peer `react-native-keychain` 10.0.0 or later)
- `ElectronSafeStorageSignalProtocolSecretVault` from `@open-e2ee/signal-protocol-sdk/local/vault/electron-safe-storage`, in the Electron main process, with the app's `safeStorage`
- or a custom implementation

The Expo and React Native adapters keep the secret on this device. The Electron
adapter keeps only ciphertexts in a file that the app names, and the key that
decrypts them stays in the OS secret store. It fails closed on the Linux
`basic_text` backend. The react-native-keychain adapter
sets fixed options that the application cannot change: iOS
`AFTER_FIRST_UNLOCK_THIS_DEVICE_ONLY`, Android `AES_GCM_NO_AUTH` storage at the
`SECURE_SOFTWARE` level, and no `cloudSync` key. react-native-keychain 10.0.0
turns iCloud sync on for any `cloudSync` value, `false` included
([issue #800](https://github.com/oblador/react-native-keychain/issues/800)).
The [secret-vault guide](./local/vault/README.md) gives the reason for each
option.

## Composition

### Minimal local client

<!-- doc-snippet:run adapters-local-client expect="" -->
```ts
// Real protocol and cryptography; simulated in-memory infrastructure.
import { createSignalProtocolClient } from "@open-e2ee/signal-protocol-sdk";
import { inMemoryStore } from "@open-e2ee/signal-protocol-sdk/local/store/memory";

const signal = await createSignalProtocolClient({
  identity: { userId: "alice" },
  adapters: { storage: inMemoryStore() },
});
```

### Production client

<!-- doc-snippet:skip requires-production-adapters -->
```ts
import { createHostedSignalProtocolClient } from "@open-e2ee/signal-protocol-sdk";
import { expoStore } from "@open-e2ee/signal-protocol-sdk/local/store/expo";

const signal = await createHostedSignalProtocolClient({
  adapters: {
    // Expo storage owns this device's private keys and session state.
    storage: await expoStore(),
  },
  hosted: {
    // The environment-scoped connection URL from the OpenE2EE console.
    relayUrl: process.env.EXPO_PUBLIC_OPEN_E2EE_SIGNAL_RELAY_URL ?? process.env.EXPO_PUBLIC_OPEN_E2EE_RELAY_URL!,
    // Returns a short-lived signed assertion for the signed-in user.
    getIdentityAssertion,
  },
});
```

See the [Expo storage guide](./local/store/expo/README.md) for the required
database and SQLCipher bootstrap.

### Sandbox development

`oe new` writes a Sandbox connection URL to `.env.local`. Use it with the
hosted client. The device-local storage contracts are the same in Sandbox. A
Sandbox environment uses device-owned identity:
`hostedSignalProtocolRelaySandboxIdentity(storage)` supplies `hosted.getIdentityAssertion`.
See the [client guide](./client/README.md#with-the-signal-protocol-relay).

## Security Expectations

### Relay implementations

- Prekey bundle fetch must preserve the package’s one-time-prekey semantics.
- Device registration, unlink, and stale cleanup must stay consistent across active identity types.
- Linked-device slot assignment is server-owned, not client-owned.
- Public-key reads and writes must enforce correct account ownership rules.
- An envelope gets one `id`, and that `id` stays the same on every redelivery. A relay that assigns its own ids delivers the SDK id as `clientMessageId`. See [docs/INTERFACES.md](./docs/INTERFACES.md).

### Storage implementations

- Protect local key material at rest.
- Declare `protection`: the encryption at rest and the custody of the key. State what the store does. A declaration adds no encryption. Client creation fails without a valid one, and [Content Recovery](./docs/PROTOCOL_POLICY.md#content-recovery) uses it to decide whether the store may hold resendable content.
- Keep contact identity trust decisions stable and explicit.
- Persist linked-device identity state atomically enough that startup verification cannot enter a half-linked state.
- Preserve session record semantics. Do not treat sessions as opaque blobs without honoring update and archive behavior.
- Run the local store conformance kit from `@open-e2ee/signal-protocol-sdk/local/store/conformance` against a custom `SignalProtocolLocalStore`. Use `assertLocalStoreConformance` in the automated checks, and give it the `armWriteFailure` hook, so that the rollback of each atomic commit runs. The kit reads the `protection` declaration, so declare it truthfully. The kit does not cover `SenderKeyHandoffStore`, `MessageRecordStore`, or `SendLogStore`. See the [storage guide](./local/store/README.md#conformance-kit-for-a-custom-store).

## Choosing a Shape

Prefer these composition patterns:

- use `createSignalProtocolClient()` when app code owns identity, adapters, and protocol policy
- pass `storage` explicitly to every client composition
- pass `relay` only when you need sync, prekeys, or linked-device workflows
- keep `protocol.postQuantum` in product/security terms: `'required'` is the
  only value, and a peer without post-quantum prekeys is refused
- keep backend-specific code at integration boundaries, not in shared app logic
- keep platform storage imports on explicit subpaths, not the root package

## Custom Implementations

Use the public interfaces:

<!-- doc-snippet:skip requires-external-context -->
```ts
import { createSignalProtocolClient } from "@open-e2ee/signal-protocol-sdk";
import type { SignalProtocolRelayServer } from "@open-e2ee/signal-protocol-sdk/remote/signal-relay";
import type { SignalProtocolRemoteObjectStore } from "@open-e2ee/signal-protocol-sdk/remote/object-store";
import type { SignalProtocolLocalStore } from "@open-e2ee/signal-protocol-sdk/local/store";
```

Then compose them through `createSignalProtocolClient()`:

<!-- doc-snippet:skip requires-external-context -->
```ts
const signal = await createSignalProtocolClient({
  identity: { userId },
  adapters: {
    storage: customStorage,
    relay: customSignalRelay,
    remoteObjectStore: customObjectStorage,
  },
});
```

## Verifiable adapter design

The in-memory local store supports temporary device state during development.
Use the Signal Protocol Relay Sandbox for authenticated delivery. Applications
can supply custom adapters through the public client contracts.

## Related Docs

- [README](./README.md)
- [Remote Guide](./remote/README.md)
- [Storage Guide](./local/store/README.md)
- [Client Guide](./client/README.md)
