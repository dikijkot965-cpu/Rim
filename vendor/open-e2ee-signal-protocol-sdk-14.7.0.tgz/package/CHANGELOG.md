# Changelog

## 14.7.0

### Added

- `deleteHostedSignalProtocolRelayAccount({ storage, relayUrl })` requests account deletion.
  `readHostedSignalProtocolRelayAccountDeletion({ storage, relayUrl })` reads its receipt.
  Stop the client first and keep its encrypted local store.
  The store retains the request and status capability across retries and restarts.
  The helper requires a Relay with the versioned deletion receipt route.
  A store without its retained device authentication and session gets a resume error and keeps no intent.

  A deletion intent binds the store to its hosted account from the first attempt,
  also before the request reaches the Relay.
  It prevents silent identity bootstrap, recovery, and re-registration in that store.
  Only `storage.clearAllKeys()` discards it.

  Before the SDK submits the request, `createHostedSignalProtocolClient` runs a strict resume
  of that account and reports the `bootstrap` progress of an ordinary resume.
  A recovery, a re-registration, and a custom protocol manager then refuse with `DELETION_PREFLIGHT_PENDING`.
  After submission, `createHostedSignalProtocolClient` and `resumeHostedSignalProtocolClient` refuse with `DELETION_ALREADY_REQUESTED`.
  A Relay refusal of the deletion request, such as `404 NOT_FOUND`, keeps its `HostedSignalProtocolRelayHttpError`.
  The receipt distinguishes logical deletion, account capacity release, and physical purge.
  Clearing local storage or removing a device does not release an account slot.

  Against a Relay without the versioned deletion receipt route, the call throws
  `DELETION_UNSUPPORTED`. The intent stays. A recovery and a re-registration in that store
  then refuse with `DELETION_PREFLIGHT_PENDING` until `storage.clearAllKeys()`.

#### Store compatibility

- This release changes no stored record format and no store schema. A store
  that SDK 14.4.0, 14.5.0, or 14.6.0 wrote opens with this release.
- A deletion request writes one new metadata key, with the prefix
  `signalRelay.accountDeletion.v1:`. An earlier SDK does not read it.
- A return to SDK 14.6.0 is supported for a store that never requested
  deletion. Do not ship SDK 14.6.0 to a store after it requests deletion:
  SDK 14.6.0 ignores the intent, and it can then recover or re-register that
  store.
- The 14.4.0 rollback rule still applies: do not ship SDK 14.1.0 or earlier
  to a device after it runs SDK 14.4.0 or a later release.

## 14.6.0

### Added

- **`onKeyTransparencyFailure` reports a failed key transparency check.** A
  hosted client checks identities against the identity log of the Relay. It
  checks each contact identity that it fetches, and its own identity once
  each week. The event has the subject `contact` or `self` and a
  `KeyTransparencyVerificationError` whose `code` is a
  `KeyTransparencyFailureCode`. A failure never refuses a send or a decrypt.
  The new types are `KeyTransparencyFailureEvent`,
  `KeyTransparencyVerificationError`, and `KeyTransparencyFailureCode`.
- **The key transparency checks run the hook once for each failure.** The
  rules:
  - A contact failure runs the hook once for each contact identity.
  - A contact key mismatch or a contact that is not in the log gets a second
    check 2 hours later. Only a second key mismatch or not-logged result runs
    the hook.
  - An identity whose log append waits for 24 hours runs the hook with
    `LOG_APPEND_OVERDUE`.
  - A self failure runs the hook on the second consecutive failed check, once
    for each failing streak. An own account that is not in the log is a
    failure with `IDENTITY_NOT_LOGGED`.
  - A check that cannot get a result runs no hook.
  - The client checks only when the build pins the log keys of the Relay
    profile. This release pins no keys, so no check runs.
- **`checkContactKeyTransparency(userId)` checks a contact on request.** The
  method checks the pinned identity of the contact against the identity log
  and returns a `KeyTransparencyCheckOutcome`: `pass`, `not-logged`,
  `unavailable` with a `KeyTransparencyUnavailableReason`, or `failure` with a
  `KeyTransparencyVerificationError`. A key mismatch gives
  `LOGGED_KEY_MISMATCH` on the first call. The method never throws a key
  transparency error and never runs `onKeyTransparencyFailure`. A `pass` does
  not change the trust state of the contact. At most 10 calls in each 60 s
  read the Relay. This release pins no keys, so each call gives `unavailable`
  with `not-pinned`. The new types are `KeyTransparencyCheckOutcome` and
  `KeyTransparencyUnavailableReason`.
- **`onIdentityChanged` reports the identity change of a contact.** The hook
  runs once for each change that the trust gate refuses, on the send path or on
  the receive path. The event has the pinned identity, the refused identity,
  the status `CHANGED` or `ROLLBACK`, and the trust state. The refused
  operation still throws `UntrustedIdentityError`. A device of the own account
  does not run the hook. The new type is `IdentityChangedEvent`.
- **A device applies a verification state sync from another own device.** A
  `verified` sync marks the pinned identity of the contact `VERIFIED`. A
  `default` sync clears that verification. The device applies a sync only when
  its `identityKey` is the pinned identity, and it never pins or rotates an
  identity. It logs `VERIFICATION_STATE_SYNC_NOT_APPLIED` with the reason for a
  sync that it does not apply. The application still gets the sync content.
  `ParsedSyncContent.verificationState` carries the state. A custom content
  adapter must report it, or the client does not apply the sync.
- **`IdentityKeyStore.unverifyContactIdentity` clears a verification.** The
  method is optional. The memory, key-value, IndexedDB, and SQLite stores
  implement it. A custom store without it keeps `VERIFIED` on a `default`
  sync. `unverifyContactIdentityRecord` in `/keys` gives the record change. The
  local store conformance kit has the case `contact verification clearing`,
  which it skips for a store without the method.
- **A device link through the provisioning channel.** A new device calls
  `joinHostedSignalProtocolRelayAccount` with an empty store. The call shows a
  link code through `hosted.onLinkCode`, and shows a new code each time the
  Relay ends the 90 s channel. The primary device approves the code with
  `approveHostedSignalProtocolRelayDeviceLink(client, linkCode, options)`.
  The approval seals the account identity, the groups, and up to 16,384
  bytes of `applicationData` for the new device. The Relay cannot read them. Private keys can move between the
  devices of one user. They move only inside an end-to-end encrypted
  envelope. The envelope uses hybrid X25519 and post-quantum ML-KEM-768 key
  agreement. Show a confirmation screen on the primary device before it
  approves. The SDK calls `hosted.confirmAccount` with the account address
  before the new device registers. The approval resolves only after the new
  device has linked: it reads the link status with a wait of 500 ms that
  doubles to 5 s, and resolves with the `deviceId` that the Relay made. When
  the link token expires before the new device registers, the approval gives
  `LINK_CODE_EXPIRED`. The status stays `linked` after a later removal, so
  list the devices, or use `hosted.onOwnDevicesChanged`, to see the current
  devices. The new device names itself with `hosted.deviceName`, 1 to 50
  UTF-16 code units, which the join encrypts to the account identity key.
  The `deviceName` option of the approval is deprecated and does nothing.
  The new device registers with its own device ID, registration ID, prekeys,
  and device key, and the call resolves with its started client. The store
  keeps the state of the join. After a failure that follows the envelope,
  call again with the same store, and the join continues with the same link
  token and no new code. A redeem refusal (`ENVELOPE_INVALID` or
  `LINK_TOKEN_REJECTED`) deletes the join state, so the next call shows a
  new code. A redeem with no answer, a 5xx answer, or another retryable
  answer other than 429 is sent again with the same body, at most two
  times, before the call throws. A later call that
  repeats the redeem gets the same answer until the token cleanup, 24 hours
  after the link token expires. When the device token of that answer has
  expired, the call gets a new device token with the device proof. After
  the cleanup, the call gives `LINK_TOKEN_REJECTED`, and the device that the
  Relay made has no owner: remove it from the primary device.
  An `AbortSignal` stops either call with `CANCELLED`. The link token expires
  after 10 minutes, and an account has at most 5 devices.
- `listHostedSignalProtocolRelayDevices(client)` lists the own devices, with
  `isPrimary`, `isCurrent`, the decrypted `name`, and `linkedAt`.
- `removeHostedSignalProtocolRelayDevice(client, deviceId)` removes a device.
  The primary device can remove each linked device, and a linked device can
  remove itself. Device 1 cannot be removed: the call gives a `RangeError`.
  A removed client stops with
  `HostedSignalProtocolRelayDeviceRevokedError`. Removal is a Relay
  revocation only: the removed device keeps its keys. For a lost or stolen
  device, run an account recovery.
- `renameHostedSignalProtocolRelayDevice(client, deviceId, name)` sets the
  name of a device. The primary device can rename each device, and a linked
  device can rename only itself. The call encrypts the name to the account
  identity key, so the Relay cannot read it. A slot with no device gives
  `DEVICE_NOT_FOUND`.
- `resetRemovedHostedSignalProtocolRelayDevice(options)` deletes the local
  account state of a removed device. The same store can then join the
  account again with `joinHostedSignalProtocolRelayAccount`. Stop each client
  of the store first. The call renews the device token. It deletes the state
  only when the Relay refuses the renewal with `DEVICE_REVOKED`.

  It deletes the identities, the sessions, the prekeys, the device key, the
  device session, and the join marker. With `groups.store`, it also deletes
  each group of that store. When the Relay still serves the device, the call
  gives `DEVICE_NOT_REMOVED`. On each other failure, the call throws the
  error unchanged. In both cases, the store does not change.
- `hosted.onOwnDevicesChanged` on `createHostedSignalProtocolClient`,
  `resumeHostedSignalProtocolClient`, and
  `joinHostedSignalProtocolRelayAccount`. The client calls it with the added
  and the removed own device IDs when a read of the own device list finds a
  change. The client reads the list at the start and each time its Relay
  connection opens again, so an idle device sees a change without a send.
- `HostedSignalProtocolRelayDeviceProvisioningError`, with the `code` values
  `LINK_CODE_INVALID`, `LINK_CODE_EXPIRED`, `DEVICE_LIMIT_REACHED`,
  `NOT_PRIMARY`, `ENVELOPE_INVALID`, `ENVELOPE_TOO_LARGE`, `STORE_NOT_EMPTY`,
  `LINK_TOKEN_REJECTED`, `SIGNAL_RELAY_UNSUPPORTED`, `CANCELLED`,
  `DEVICE_NOT_REMOVED`, and `DEVICE_NOT_FOUND`. A Relay without the device link routes gives
  `SIGNAL_RELAY_UNSUPPORTED`.
- **Device 1 sends a first sync to a newly linked device.**
  `sendHostedSignalProtocolRelayFirstSync(client, deviceId, bundle, options)`
  sends one snapshot to the own device `deviceId`, and resolves with its
  `bundleId`. The bundle has at least one of `profileKey`, `settings`,
  `contacts`, `blocked`, and `applicationData`. Each part is a full snapshot
  of its kind, and the SDK reads no part from its own stores. The SDK sends
  nothing at the approval, so call it when the new device is listed, for
  example from `hosted.onOwnDevicesChanged`. The call is not idempotent: each
  call is a new bundle. The Relay meters the accepted copy as one message.

  The call gives `NOT_PRIMARY` on a device other than device 1,
  `DEVICE_NOT_FOUND` when the own device list does not hold the device or
  the Relay accepts no copy for it, and `CANCELLED` when `options.signal`
  fires or the client stops before the Relay accepts the copy. A bundle
  value of the wrong type gives a `TypeError`, and a value out of range
  gives a `RangeError`. Content of 140,000 bytes or less always fits, also in the
  first message to the new device. An encrypted copy whose delivery wire is
  above 262,144 bytes gives a `RangeError` before the post. An early check
  refuses serialized content above 196,608 bytes with a `RangeError` before
  the encryption, but content below that size can still fail the wire check.
  Each size refusal names its check and the content size that always fits.

  The new device gets the bundle in `hosted.onFirstSync` on
  `joinHostedSignalProtocolRelayAccount`, `createHostedSignalProtocolClient`,
  and `resumeHostedSignalProtocolClient`. The client binds the callback
  before its first receive. It applies each bundle once: it writes the
  apply-once record after the callback resolves. When the callback throws,
  the durable local receive queue gives the bundle again, also after a
  restart. A first sync never reaches `onMessageDecrypted`.
  The device logs `FIRST_SYNC_NOT_FROM_PRIMARY`, `FIRST_SYNC_MALFORMED`,
  `FIRST_SYNC_STALE`, or `FIRST_SYNC_UNHANDLED` for a first sync that it
  does not apply. A content adapter gets the optional `serializeFirstSync`,
  and `ParsedSyncContent` gets the type `firstSync` with the member
  `firstSync`. A custom adapter without the method cannot send a first sync.

### Changed

- **A second registration on an account gives
  `HostedSignalProtocolRelayDeviceLinkRequiredError`.** The Relay refuses,
  with 409 `DEVICE_LINK_REQUIRED`, a registration on an account that already
  has a device. The error extends `HostedSignalProtocolRelayHttpError`, so a
  `code` check continues to work. Join the second device with
  `joinHostedSignalProtocolRelayAccount`. On a Relay without the device link
  routes, link it with `linkHostedSignalProtocolRelayDevice`, or recover the
  account.
- **`linkHostedSignalProtocolRelayDevice` links only from the primary
  device.** Pass the store of device 1 as `activeDeviceStorage`. Without
  `hosted.adapter`, the call reads the stored Relay session of that store. When
  the session is not device 1, the call throws
  `HostedSignalProtocolRelayDeviceProvisioningError` with the code
  `NOT_PRIMARY`. It throws before it writes to a store or sends the link
  request.

  When the Relay refuses a link with `NOT_PRIMARY`, the call rolls the link
  back as for `KEY_PROOF_INVALID` and throws the same error. A custom
  `hosted.adapter` throws
  `HostedSignalProtocolRelayHttpError` with the code `NOT_PRIMARY` for that
  refusal. The function signature does not change.

  Upgrade: call `linkHostedSignalProtocolRelayDevice` from the primary
  device. A linked device now gets
  `HostedSignalProtocolRelayDeviceProvisioningError` with the code
  `NOT_PRIMARY`.
- **The default message of `HostedSignalProtocolRelayDeviceRevokedError`
  names a device removal.** The new default message is
  `The device was revoked by an account recovery or a device removal.`
  The error uses it when the Relay answer for `DEVICE_REVOKED` has no
  message. The error keeps a message from the Relay. The `code`, `status`,
  `retryable`, and error type do not change.

### Removed

- **Removed: version 1 selection and the version 1 meaning of
  `RETRY_CONFLICT`.** The SDK does not speak Relay protocol version 1. It
  offers version 3, with version 2 as its fallback, as before. An SDK carrier
  that selects a version below 2 throws a `RangeError` before it sends a
  request. `RETRY_CONFLICT` stays an earlier acceptance for its three
  sources. A `DELIVERY_ALREADY_ACCEPTED` answer to a hosted carrier is an
  earlier acceptance, as for `RETRY_CONFLICT`. No public export changes.

  Minimum Relay release: a Relay that serves version 2. Current Relay
  releases serve versions 2 and 3, and refuse version 1 with
  `UPGRADE_REQUIRED`.

  Upgrade: use a Relay that serves version 2.

### Fixed

- **A new session from a removed device returns the device to fan-out.**
  Before, a device that a client marked removed stayed removed when a new
  install of the device linked into the same slot and started a session. The
  client sent the device no sync copy and no note to self until the app
  called `refreshOwnDeviceList()`. Now the receive of the first message of
  the new session clears the mark, and the next send includes the device.
  The identity checks do not change: an own device must hold the account
  identity, and a changed contact identity still needs verification. A late
  message on an archived session of the removed device still leaves it
  removed.
- **A removed device stops its Relay connection with `device-revoked`.**
  Before, a removed device whose device token was unexpired stopped with
  `authority-refused`. The Relay refuses that token with `NOT_FOUND`, the same
  refusal as for a missing device. Now a conclusive `NOT_FOUND` on a pull or
  on the socket token request gets one device token refresh. The refresh gets
  `DEVICE_REVOKED`, so the connection stops with `device-revoked`. A refresh
  that succeeds, or another conclusive refusal, still stops with
  `authority-refused`. A network failure of the refresh does not stop the
  connection, and it retries on its usual schedule.
- **A Relay call of a removed device throws
  `HostedSignalProtocolRelayDeviceRevokedError`.** Before, a call such as
  `listHostedSignalProtocolRelayDevices` or a message send threw
  `HostedSignalProtocolRelayHttpError` with the code `NOT_FOUND` while the
  device token was unexpired. Now a `NOT_FOUND` with `retryable` false gets
  one device token refresh, and a refresh that gets `DEVICE_REVOKED` or
  `NOT_FOUND` throws its typed error. A missing destination still throws its
  `NOT_FOUND`. After a refresh succeeds, a `NOT_FOUND` in the next 60 s gets
  no refresh. After `DEVICE_REVOKED`, each later call that needs the device
  token throws the same error and sends no request.

#### Store compatibility

- This release changes no stored record format and no store schema. A store
  that SDK 14.4.0 or 14.5.0 wrote opens with this release.
- This release writes two new metadata keys. `hosted-join:v1` is the join
  marker, and a `complete` marker stays after a join. `first-sync:v1` keeps
  the IDs of the applied first-sync bundles. An earlier SDK does not read
  them.
- A `default` verification state sync sets the trust state
  `UNVERIFIED_TOFU` and removes `verifiedAt`. The record keeps its revision.
  A new session from a removed device removes `removedAt` from the device
  record. An earlier SDK reads both records.
- This release writes no key transparency record, because it pins no keys.
- A return to SDK 14.5.0 is supported, with two limits:
  - SDK 14.5.0 does not know a first sync. It does not apply the bundle, and
    it has no `hosted.onFirstSync`.
  - SDK 14.5.0 cannot continue a join that did not complete. Ship this
    release again, and call `joinHostedSignalProtocolRelayAccount` with the
    same store.
- The 14.4.0 rollback rule still applies: do not ship SDK 14.1.0 or earlier
  to a device after it runs SDK 14.4.0 or this release.

## 14.5.0

### Fixed

- **A device trusts its own other devices only with the account identity.**
  Each linked device holds the account identity. Before, a device trusted on
  first use any identity that the Relay served for another device of its own
  account. It pinned that identity, and it sent sync copies and group master
  keys to that device. Now the SDK compares the identity of an own device with
  the local identity of the same type, in constant time. A device with another
  identity gets no session, no sync copy, and no group master key, and the
  store pins nothing for it. The send to the recipient still succeeds, and the
  logger reports an `UntrustedIdentityError` for the device. A PreKeyMessage
  that names an own device with another identity fails with
  `UntrustedIdentityError` before it uses a prekey. Contacts keep trust on
  first use.
- The SDK no longer calls `isTrustedIdentity` of a custom store for a device of
  the local user.
- On a Relay that compares device sets, a listed own device with another
  identity stops each own-device sync while the Relay lists it. The sync
  phase of a send stays pending, the logger reports it, and the relay accepts
  no sync copy. The send to the recipient is not affected, and a retry with
  the same `clientMessageId` completes the phase when the Relay no longer
  lists the device. Group key sync, read sync, view-once open sync, media
  attachment delete sync, configuration sync, username state sync, recipient
  username sync, verification state sync, task notification acknowledgment
  sync, and blocked recipients sync fail with `UntrustedIdentityError`, and
  the relay accepts no copy. On a Relay that does not compare device sets,
  these paths skip the device and post to the other own devices.
- **A stale own pin no longer blocks the real own devices.** A store can hold
  a pin of another identity under the own account: an earlier release pinned
  the identity that a Relay served for an own device, or
  `rotateAccountIdentity` replaced the account identity after the pin. The
  store compares each session commit with that pin, so before, every session
  with a real own device failed. Now, before it stores a session with an own
  device that holds the local identity, the SDK replaces that pin with the
  local identity through `acceptContactIdentityRotationAndDeleteSessions`.
  That call also deletes the sessions with the own devices, which used the
  replaced identity, and the next send starts them again.
- **`isRetryableError` returns false for `DEVICE_LINK_REQUIRED`.** The Relay
  sends it when an account with a device registers a new identity. The Relay
  sends the same refusal to each repeat, so `withRetry` now gives the error to
  the caller after one attempt. The check reads the error code, not the
  message. The SDK does not retry its own registration. This change affects
  only an application that calls `withRetry` or `isRetryableError` around
  registration.
- **A replay no longer posts a sealed message with an expired sender
  certificate.** The receiver checks the certificate against the time at
  which the Relay stores the post. Before, a replay posted the stored sealed
  body again, so a body whose certificate had expired arrived, and the
  receiver refused it with no signal to the sender. Now, before each replay
  post, the SDK seals the stored ciphertext again with a current certificate
  when the recorded expiration is at or before the estimated Relay time plus
  5 minutes, or when the record has no expiration. This applies to direct
  sealed posts, sealed resends, and shared group bodies. The new seal keeps
  the message ID, the operation epoch, and the ciphertext, so the receiver
  sees the same message. A `RETRY_CONFLICT` to the new seal follows the
  existing rule: the Relay holds the same ciphertext under the message ID.
  When the Relay answers `PERIOD_CLOSED` and the certificate expires before a
  repeat can arrive, the one repeat is a new seal.
- **The SDK uses a sender certificate that expires in less than 24 hours.**
  Concurrent sends share one certificate fetch. The SDK refreshes a
  certificate 1 hour before its expiration, less a random time below 10
  minutes, so many clients do not refresh at the same time. It uses a shorter
  certificate until 5 minutes before its expiration. When a fetched
  certificate expires within those 5 minutes, the SDK waits for it to expire
  and fetches once more. The SDK validates each certificate against the
  estimated Relay time, not the local clock.
- **A group send renews its endorsements once after the Relay refuses the
  group credential.** The Relay stores nothing on that refusal. The SDK
  clears the cached endorsements of the group, refreshes them once under the
  endorsement lock, and posts the shared body once more. A second refusal
  falls back to identified device posts in `preferred` mode and fails the
  send in `required` mode, as before.
- **A group send near the end of its endorsements no longer fails.** The
  Relay can end new group send endorsements at a UTC day boundary less than
  2 hours away. The SDK refuses endorsements with less than 2 hours left, so
  before, each group send in that window failed with a verification error and
  posted nothing. Now the SDK logs a warning, keeps the endorsements that it
  holds, and seals with them until they expire. A group with no valid
  endorsement uses identified device posts in `preferred` mode and fails the
  send in `required` mode.
- **The Relay protocol offer steps down one version at a time.** Before, a
  refused offer went to version 2 at once. Now each `PROTOCOL_UNSUPPORTED`
  refusal moves the offer one version down, and it never goes below version
  2. The first version that the SDK offers does not change.

#### Store compatibility

- Stored sealed device messages and shared group bodies record the signed
  expiration of their sender certificate in the optional field
  `sealedSenderCertificateExpiresAt`. A record that an earlier SDK wrote has
  no value, and the SDK reads it as before. An earlier SDK reads a record with
  the field.
- A return to SDK 14.4.0 is supported. SDK 14.4.0 posts a stored sealed body
  again without a new seal, so a replay of a body whose sender certificate
  expired can arrive and be refused by the receiver. The 14.4.0 rollback rule
  still applies: do not ship SDK 14.1.0 or earlier to a device after it runs
  SDK 14.4.0 or this release.

## 14.4.0

### Changed

- **The SDK speaks protocol version 3 of the OpenE2EE Signal Protocol Relay.**
  Version 3 keeps the behavior of version 2 and uses the Signal Relay names.
  It sends the header `x-signal-relay-protocol: 3`, and the mailbox socket
  offers `signal-relay.v3` with `signal-relay.auth.<token>`. Each device proof
  signs a version 3 label, for example
  `signal-relay-device-authentication-v2\0`. The Relay issues a device token
  with the issuer `signal-relay`, the audience `signal-relay-device`, and the
  claim `signal_relay_scope_id`. A version 3 response names the scope
  `signalRelayScopeId` and the receipts capability `signalRelayReceipts`. The
  SDK reads the earlier names too, and it refuses a response that gives two
  different values.
- **The SDK falls back to version 2.** When the Relay refuses version 3 with
  `PROTOCOL_UNSUPPORTED`, the client sends the refused request again with
  version 2, and it offers version 2 until it stops. The Relay refuses the
  version before it reads the request, so the refused request had no effect.
  A socket that the Relay closes with 4400 reconnects with version 2 after its
  usual backoff. A client with an explicit protocol version never falls back.
  A Relay that predates version 3 does not refuse version 3 with
  `PROTOCOL_UNSUPPORTED`, so the client does not fall back to version 2.
  Use this release with a Relay that serves version 3.
- **`HostedSignalProtocolRelayDeviceAuthentication` signs the label of a
  protocol version.** `signChallenge` and `signCertificateRequest` take an
  optional last argument, `protocolVersion`. A call without it signs the
  version 1 label, which the Relay verifies on versions 1 and 2 and on a
  request without a version. An adapter that sends the proof with
  `x-signal-relay-protocol: 3` must pass `3`. An adapter that sends no version
  needs no change.
- **This release writes the Signal Relay values to the local store.** A new
  receive record holds the origin `'signal-relay'` and the receipt decision
  `signalProtocolRelayOwnsReceipt`. A new Relay delivery status holds the
  source `'signal-relay'`. A hosted record goes to its `signalRelay.<record>.v2:`
  key only. When only the earlier `.v1:` key holds a record, a read copies the
  record to the current key and keeps the earlier key. The SDK still reports
  `'relay'` to the application for `DeliverySource`, `PendingReceive.origin`,
  and `ReceiveExpiredEvent.origin`, as in SDK 14.3.0.

#### Store compatibility

- A store that SDK 14.0.0 through 14.3.0 wrote opens with this release. This
  release reads the origin `'relay'`, the receipt decision
  `relayOwnsReceipt`, the source `'relay'`, and each `.v1:` key. SDK 15.0.0
  still reads them. A record that an earlier release wrote keeps the origin
  `'relay'` when this release changes it.
- A return to SDK 14.2.0 or 14.3.0 is supported. Those releases read each
  value that this release writes, and they read the current key of a hosted
  record first.
- A return to SDK 14.1.0 or earlier is not supported for a store that this
  release wrote. Those releases refuse the origin `'signal-relay'`. They read
  only the `.v1:` key of a hosted record, so they do not find a record that
  this release created, and they read an earlier value of a record that this
  release changed.
- Do not ship SDK 14.1.0 or earlier to a device after it runs this release.
  To roll back, ship SDK 14.2.0 or 14.3.0. A device that goes back to SDK
  14.1.0 or earlier can have these failures:
  - Messages that the device received but did not complete can stay
    unprocessed. The receive queue fails each time it reads a stored receive
    with the origin `'signal-relay'`.
  - A device that registered with this release cannot resume its Relay
    connection. The earlier release does not find the device authentication
    key, and the resume fails with `RETAINED_DEVICE_AUTHENTICATION_UNAVAILABLE`.
  - A device-owned identity that this release created is lost. The earlier
    release does not find the key, so it creates a new key. The Relay binds
    an account to that key, so the device gets a new account.
  - A hosted record that this release changed goes back to its earlier
    value. An example is the stored Relay session.

## 14.3.0

### Changed

- The Expo example moves to the Expo SDK 58 line. It uses React Native
  0.88.1, React 19.3.0, and TypeScript 6.0 as Expo recommends. Its dependency
  tree no longer contains `deepmerge`. Its `app.json` no longer sets
  `jsEngine`, because Hermes is the default.
- Internal CI also adds the packed package to an Expo SDK 58 project. It
  builds the Expo example's Hermes bundle on Expo SDK 55 and 58.

### Changed: role names are the member and option names to use

- **The role names are not deprecated.** Each of the 24 members and options
  in the 14.2.0 table "Deprecated: members and options without the Signal
  Protocol prefix" keeps its role name, such as `relay`, `relayUrl`, and
  `startRelaySubscription`. SDK 15.0.0 keeps these names.
- **The `signalProtocolRelay*` names are deprecated.** SDK 14.2.0 added these
  names, such as `signalProtocolRelay` and
  `startSignalProtocolRelaySubscription`. SDK 15.0.0 removes them. See step 1.

This change applies only to the names of members, methods, and option keys of
objects that the SDK owns. It does not change export names, type names, file
names, subpaths, URLs, wire values, or stored keys. Those names keep the
`SignalProtocolRelay` form, for example `SignalProtocolRelayServer` and
`createHostedSignalProtocolClient`.

Both names of each member and option work in this release, as in SDK 14.2.0.
An option accepts either name. When a call sets both names to different
values, it fails with `SignalProtocolRelayNameConflictError`. This release
does not change the behavior of the SDK, the wire, signed bytes, or stored
bytes.

`SignalProtocolRelayNameConflictError` keeps its public shape. `newName` holds
the deprecated `signalProtocolRelay*` name, because SDK 14.2.0 added it after
the role name. `earlierName` holds the role name. The error message now tells
you to set only the role name, for example `relay and signalProtocolRelay name
the same option and hold different values. Set only relay.` Code that reads
`newName` to find the name to keep must read `earlierName`. See step 3.

Each interface that your code implements keeps the role-name member required
and the `signalProtocolRelay*` member optional. This applies to
`SignalProtocolRelayServer`, `SignalProtocolContentAdapter`, and
`HostedSignalProtocolRelayBootstrapResult`. An implementation with only the
role-name members compiles and works in SDK 14 and in SDK 15.0.0. See step 2.

| Type | Name to use | Deprecated name |
| --- | --- | --- |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `relayConnectionState` | `signalProtocolRelayConnectionState` |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `subscribeRelayConnectionState` | `subscribeSignalProtocolRelayConnectionState` |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `startRelaySubscription` | `startSignalProtocolRelaySubscription` |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `stopRelaySubscription` | `stopSignalProtocolRelaySubscription` |
| `SignalProtocolRelayServer`, `InMemorySignalProtocolRelayServer`, `ConvexSignalProtocolRelayServer` | `relayConnectionState` | `signalProtocolRelayConnectionState` |
| `SignalProtocolRelayServer`, `InMemorySignalProtocolRelayServer`, `ConvexSignalProtocolRelayServer` | `subscribeRelayConnectionState` | `subscribeSignalProtocolRelayConnectionState` |
| `SignalProtocolClientConfig` | `relay` | `signalProtocolRelay` |
| `SignalProtocolClientAdapterConfig` | `relay` | `signalProtocolRelay` |
| `SignalProtocolClientContext` | `relay` | `signalProtocolRelay` |
| `SealedSenderConfig` | `relayScopeId` | `signalProtocolRelayScopeId` |
| `GroupAuthorityFields` | `relayScopeId` | `signalProtocolRelayScopeId` |
| `SignalProtocolClientHooks` | `onRelayProtocolError` | `onSignalProtocolRelayProtocolError` |
| `SignalProtocolContentAdapter` | `setRelayBatching` | `setSignalProtocolRelayBatching` |
| `OutgoingMessageError` | `relayRetryable` | `signalProtocolRelayRetryable` |
| `HostedSignalProtocolRelayBootstrapResult` | `relay` | `signalProtocolRelay` |
| `HostedSignalProtocolRelayBootstrapResult` | `relayScopeId` | `signalProtocolRelayScopeId` |
| `HostedSignalProtocolClientOptions` | `hosted.relayUrl` | `hosted.signalProtocolRelayUrl` |
| `HostedSignalProtocolResumeOptions` | `hosted.relayUrl` | `hosted.signalProtocolRelayUrl` |
| `HostedSignalProtocolRelayManagedDeviceLinkOptions` | `hosted.relayUrl` | `hosted.signalProtocolRelayUrl` |
| `HostedSignalProtocolRelayIdentityMigrationOptions` | `relayUrl` | `signalProtocolRelayUrl` |
| `CreateTestClientOptions` | `sharedRelay` | `sharedSignalProtocolRelay` |
| `TestClientResult` | `relay` | `signalProtocolRelay` |
| `SignalProtocolClientInternals` | `relay` | `signalProtocolRelay` |
| `SignalProtocolServiceCipher` | `setRelayProtocolErrorReporter` | `setSignalProtocolRelayProtocolErrorReporter` |

#### Upgrade steps

Code that did not change for SDK 14.2.0 needs no change. Code that keeps the
role names compiles and runs in this release and in SDK 15.0.0.

1. If you changed your code to a `signalProtocolRelay*` name in the table for
   SDK 14.2.0, change it back to the role name. Code that keeps a
   `signalProtocolRelay*` name compiles and runs unchanged in this release.
   The TypeScript tools mark it as deprecated. Complete this step before
   SDK 15.0.0, which removes these names.
2. If you added a `signalProtocolRelay*` member to a class or object that
   implements `SignalProtocolRelayServer`, `SignalProtocolContentAdapter`, or
   `HostedSignalProtocolRelayBootstrapResult`, remove it. Keep the role-name
   member, which this release requires.
3. If your code reads `newName` from a `SignalProtocolRelayNameConflictError`
   to tell the user which name to keep, read `earlierName`.

## 14.2.0

### Deprecated

- **Names without the Signal Protocol prefix.** Each of the 81 names in the
  table has a new name. A new name has the form `SignalProtocolRelay`, or
  `HostedSignalProtocolRelay` for a name that starts with `Hosted`. SDK 15.0.0
  removes the earlier names. See step 1.
- **`RelayPreKeyBundle`, from the package root.** Use `PreKeyBundle`. The two
  names identify the same type. SDK 15.0.0 removes `RelayPreKeyBundle`. See
  step 2.

Each earlier name is a deprecated alias of the same class, function, or type,
from the same entry points. A class alias is the same value. Thus `instanceof`
with the earlier class name is true for an error that the SDK throws.

The new names do not change the `name` property of an error or a property
of an object. The package subpaths are in
[Deprecated package subpaths](#deprecated-package-subpaths).

| Earlier name | New name |
| --- | --- |
| `advanceHostedRelayIdentityMigration` | `advanceHostedSignalProtocolRelayIdentityMigration` |
| `bindRelayLifecycle` | `bindSignalProtocolRelayLifecycle` |
| `convexRelay` | `convexSignalProtocolRelay` |
| `createRelayConnection` | `createSignalProtocolRelayConnection` |
| `HostedRelayBootstrapAdapter` | `HostedSignalProtocolRelayBootstrapAdapter` |
| `HostedRelayBootstrapRequest` | `HostedSignalProtocolRelayBootstrapRequest` |
| `HostedRelayBootstrapResult` | `HostedSignalProtocolRelayBootstrapResult` |
| `HostedRelayDeviceAuthentication` | `HostedSignalProtocolRelayDeviceAuthentication` |
| `HostedRelayDeviceLinkError` | `HostedSignalProtocolRelayDeviceLinkError` |
| `hostedRelayDeviceOwnedIdentity` | `hostedSignalProtocolRelayDeviceOwnedIdentity` |
| `HostedRelayDeviceRevokedError` | `HostedSignalProtocolRelayDeviceRevokedError` |
| `HostedRelayDeviceUnknownError` | `HostedSignalProtocolRelayDeviceUnknownError` |
| `HostedRelayHttpError` | `HostedSignalProtocolRelayHttpError` |
| `HostedRelayIdentityMigrationAction` | `HostedSignalProtocolRelayIdentityMigrationAction` |
| `HostedRelayIdentityMigrationAdapter` | `HostedSignalProtocolRelayIdentityMigrationAdapter` |
| `HostedRelayIdentityMigrationOptions` | `HostedSignalProtocolRelayIdentityMigrationOptions` |
| `HostedRelayIdentityMigrationRequest` | `HostedSignalProtocolRelayIdentityMigrationRequest` |
| `HostedRelayIdentityMigrationSnapshot` | `HostedSignalProtocolRelayIdentityMigrationSnapshot` |
| `HostedRelayIdentityMigrationState` | `HostedSignalProtocolRelayIdentityMigrationState` |
| `HostedRelayIdentityProgress` | `HostedSignalProtocolRelayIdentityProgress` |
| `HostedRelayIdentityProgressCallback` | `HostedSignalProtocolRelayIdentityProgressCallback` |
| `HostedRelayManagedDeviceLinkAdapter` | `HostedSignalProtocolRelayManagedDeviceLinkAdapter` |
| `HostedRelayManagedDeviceLinkOptions` | `HostedSignalProtocolRelayManagedDeviceLinkOptions` |
| `HostedRelayManagedDeviceLinkRequest` | `HostedSignalProtocolRelayManagedDeviceLinkRequest` |
| `HostedRelayManagedDeviceLinkResult` | `HostedSignalProtocolRelayManagedDeviceLinkResult` |
| `hostedRelayPresence` | `hostedSignalProtocolRelayPresence` |
| `HostedRelayPresence` | `HostedSignalProtocolRelayPresence` |
| `HostedRelayPresenceAccount` | `HostedSignalProtocolRelayPresenceAccount` |
| `HostedRelayPresenceApproximateLastSeen` | `HostedSignalProtocolRelayPresenceApproximateLastSeen` |
| `HostedRelayPresenceAudience` | `HostedSignalProtocolRelayPresenceAudience` |
| `HostedRelayPresenceError` | `HostedSignalProtocolRelayPresenceError` |
| `HostedRelayPresenceErrorCode` | `HostedSignalProtocolRelayPresenceErrorCode` |
| `HostedRelayPresenceLastSeenPolicy` | `HostedSignalProtocolRelayPresenceLastSeenPolicy` |
| `HostedRelayPresenceMode` | `HostedSignalProtocolRelayPresenceMode` |
| `HostedRelayPresencePolicy` | `HostedSignalProtocolRelayPresencePolicy` |
| `HostedRelayPresenceSetting` | `HostedSignalProtocolRelayPresenceSetting` |
| `HostedRelayPresenceStatus` | `HostedSignalProtocolRelayPresenceStatus` |
| `HostedRelayPresenceVisibility` | `HostedSignalProtocolRelayPresenceVisibility` |
| `HostedRelayProfileKeys` | `HostedSignalProtocolRelayProfileKeys` |
| `HostedRelayPushPlatform` | `HostedSignalProtocolRelayPushPlatform` |
| `HostedRelayPushProfile` | `HostedSignalProtocolRelayPushProfile` |
| `HostedRelayPushRegistration` | `HostedSignalProtocolRelayPushRegistration` |
| `HostedRelayRegistrationPreKey` | `HostedSignalProtocolRelayRegistrationPreKey` |
| `HostedRelayRegistrationPreKeys` | `HostedSignalProtocolRelayRegistrationPreKeys` |
| `HostedRelayResumeError` | `HostedSignalProtocolRelayResumeError` |
| `HostedRelayResumeErrorCode` | `HostedSignalProtocolRelayResumeErrorCode` |
| `HostedRelayResumePhase` | `HostedSignalProtocolRelayResumePhase` |
| `HostedRelayResumeProgress` | `HostedSignalProtocolRelayResumeProgress` |
| `HostedRelayResumeProgressCallback` | `HostedSignalProtocolRelayResumeProgressCallback` |
| `hostedRelaySandboxIdentity` | `hostedSignalProtocolRelaySandboxIdentity` |
| `HostedRelayTokenPushRegistration` | `HostedSignalProtocolRelayTokenPushRegistration` |
| `HostedRelayUpgradeRequiredError` | `HostedSignalProtocolRelayUpgradeRequiredError` |
| `HostedRelayWakeClient` | `HostedSignalProtocolRelayWakeClient` |
| `HostedRelayWakeOptions` | `HostedSignalProtocolRelayWakeOptions` |
| `hostedRelayWakePresence` | `hostedSignalProtocolRelayWakePresence` |
| `HostedRelayWakePresence` | `HostedSignalProtocolRelayWakePresence` |
| `HostedRelayWakeResult` | `HostedSignalProtocolRelayWakeResult` |
| `HostedRelayWebPushRegistration` | `HostedSignalProtocolRelayWebPushRegistration` |
| `inMemoryRelay` | `inMemorySignalProtocolRelay` |
| `isSendNeverAcceptedByRelayError` | `isSendNeverAcceptedBySignalProtocolRelayError` |
| `linkHostedRelayDevice` | `linkHostedSignalProtocolRelayDevice` |
| `pullHostedRelayAfterWake` | `pullHostedSignalProtocolRelayAfterWake` |
| `registerHostedRelayPush` | `registerHostedSignalProtocolRelayPush` |
| `RelayConfig` | `SignalProtocolRelayConfig` |
| `RelayConnection` | `SignalProtocolRelayConnection` |
| `RelayConnectionReason` | `SignalProtocolRelayConnectionReason` |
| `RelayConnectionState` | `SignalProtocolRelayConnectionState` |
| `RelayFailureController` | `SignalProtocolRelayFailureController` |
| `RelayFailureOptions` | `SignalProtocolRelayFailureOptions` |
| `RelayGroupServer` | `SignalProtocolRelayGroupServer` |
| `RelayLifecycleAppState` | `SignalProtocolRelayLifecycleAppState` |
| `RelayLifecycleOptions` | `SignalProtocolRelayLifecycleOptions` |
| `RelayProtocolError` | `SignalProtocolRelayProtocolError` |
| `RelayProtocolErrorCode` | `SignalProtocolRelayProtocolErrorCode` |
| `RelayProtocolRoute` | `SignalProtocolRelayProtocolRoute` |
| `removeHostedRelayPush` | `removeHostedSignalProtocolRelayPush` |
| `SendNeverAcceptedByRelayError` | `SendNeverAcceptedBySignalProtocolRelayError` |
| `useRelayConnectionState` | `useSignalProtocolRelayConnectionState` |
| `UseRelayConnectionStateOptions` | `UseSignalProtocolRelayConnectionStateOptions` |
| `useRelayLifecycle` | `useSignalProtocolRelayLifecycle` |
| `UseRelayLifecycleOptions` | `UseSignalProtocolRelayLifecycleOptions` |

### Changed

- **The docs read the new URL variable first.** The examples read
  `OPEN_E2EE_SIGNAL_RELAY_URL` or `EXPO_PUBLIC_OPEN_E2EE_SIGNAL_RELAY_URL`
  first. They read the earlier name without `SIGNAL_` second. `oe` 5.0.0 added
  `SIGNAL_` to these names. The SDK reads no environment variable. See step 3.
- **The SDK verifies the protocol version 3 names of the OpenE2EE Signal
  Protocol Relay.** A device link accepts a device token with the issuer
  `signal-relay` and the audience `signal-relay-device`. A group authority
  certificate with the domain `signal-relay-group-authority-v2` verifies. The
  earlier issuer, audience, and domain still verify. A token that mixes an
  earlier name with a new name fails. A device token can carry the scope claim
  `signal_relay_scope_id`, the earlier claim `relay_scope_id`, or both. A token
  with two different scope values fails. The SDK still sends protocol version 2.
  The sender certificate schema names field 7 `signalRelayScopeId`. The field
  number and the bytes on the wire do not change. No step is necessary.

#### Upgrade steps

1. Replace each earlier name in the table with its new name. Code that keeps
   an earlier name compiles and runs unchanged in this release. The
   TypeScript tools mark the earlier name as deprecated. Complete this step before
   SDK 15.0.0, which removes the earlier names.
2. Replace `RelayPreKeyBundle` with `PreKeyBundle`.
3. Set the Relay URL in `OPEN_E2EE_SIGNAL_RELAY_URL`. In a Next.js, Vite, or
   Expo application, use the public prefix of the framework:
   `NEXT_PUBLIC_OPEN_E2EE_SIGNAL_RELAY_URL`, `VITE_OPEN_E2EE_SIGNAL_RELAY_URL`,
   or `EXPO_PUBLIC_OPEN_E2EE_SIGNAL_RELAY_URL`. An `oe` release before 5.0.0
   wrote the earlier name. Until each environment has the new name, read the
   new name first and the earlier name second.

### Relay values that SDK 15.0.0 changes

- **The Relay union values accept `'signal-relay'`.** `DeliverySource`, the
  `origin` of `ReceiveExpiredEvent`, and the `origin` of `PendingReceive`
  accept `'signal-relay'` and `'relay'`. This release reports `'relay'`. SDK
  15.0.0 reports `'signal-relay'`.
- **SDK 15.0.0 changes two error names.** This release does not change the
  `name` property of an error.
- **SDK 15.0.0 changes four log operations.** A device transfer log entry
  holds its operation in the `data.operation` field. This release does not
  change the operations.

| Kind | Value in this release | Value in SDK 15.0.0 |
| --- | --- | --- |
| `DeliverySource` value | `'relay'` | `'signal-relay'` |
| `ReceiveExpiredEvent.origin` value | `'relay'` | `'signal-relay'` |
| `PendingReceive.origin` value | `'relay'` | `'signal-relay'` |
| Error `name` | `RelayWorkStopped` | `SignalProtocolRelayWorkStopped` |
| Error `name` | `InMemoryRelayRefusal` | `InMemorySignalProtocolRelayRefusal` |
| Log operation | `relay-connect` | `signal-relay-connect` |
| Log operation | `relay-disconnect` | `signal-relay-disconnect` |
| Log operation | `relay-upload` | `signal-relay-upload` |
| Log operation | `relay-download` | `signal-relay-download` |

#### Upgrade steps for the Relay values

1. Find each comparison with `'relay'` of a value in the first three rows of
   the table. Make it also accept `'signal-relay'`. Before you upgrade to SDK
   15.0.0, complete this step. In that release, code that accepts only
   `'relay'` does not match a Relay delivery or a Relay message. A `switch`
   that ends with an exhaustive check needs a `case` for each value now,
   because it does not compile with this release. For example, this `switch`
   compiles with SDK 14.1.0 only:

   <!-- doc-snippet:skip requires-external-context -->
   ```ts
   import type { DeliverySource } from '@open-e2ee/signal-protocol-sdk';

   function deliveryLabel(source: DeliverySource): string {
     switch (source) {
       case 'relay':
         return 'Delivered to the device';
       case 'e2ee':
         return 'Decrypted on the device';
       default: {
         const unhandled: never = source;
         return unhandled;
       }
     }
   }
   ```

   Add a `case` for `'signal-relay'` next to the `case` for `'relay'`. This
   `switch` compiles with this release and with SDK 15.0.0:

   <!-- doc-snippet:skip requires-external-context -->
   ```ts
   import type { DeliverySource } from '@open-e2ee/signal-protocol-sdk';

   function deliveryLabel(source: DeliverySource): string {
     switch (source) {
       case 'relay':
       case 'signal-relay':
         return 'Delivered to the device';
       case 'e2ee':
         return 'Decrypted on the device';
       default: {
         const unhandled: never = source;
         return unhandled;
       }
     }
   }
   ```

2. Find each match of an error `name` in the table, in code or in a log
   query. Make it also match the SDK 15.0.0 name.
3. Find each log query that matches a log operation in the table. Make it
   also match the SDK 15.0.0 value.

### Store keys

- **The SDK reads a hosted record under a new key prefix first.** Seven
  records in the application store have a new metadata key prefix,
  `signalRelay.<record>.v2:`. The records are `session`,
  `deviceAuthentication`, `registrationSnapshot`, `reregistrationSnapshot`,
  `sandboxIdentity`, `presenceGrant`, and `profileKeyDelivered`. The SDK reads
  the new key first and the earlier `hostedRelay.<record>.v1:` key second.
- **The SDK writes the earlier key.** This release writes each record under
  the earlier key, so SDK 14.1.0 still finds every record. When the store
  already holds the new key, a write also replaces it. A later release writes
  the new key. SDK 15 still reads the earlier key.
- **A store that SDK 14.1.0 wrote opens with its sessions and device
  authentication.** You do not need to change the store. The documentation of
  `hostedSignalProtocolRelaySandboxIdentity` and
  `hostedSignalProtocolRelayDeviceOwnedIdentity` names the two key prefixes of
  the sandbox identity key.

### Stored Relay values

- **A receive record accepts the Relay values of a later release.** The
  `origin` of `ReceiveWorkRecord` accepts `'signal-relay'`, the same origin as
  `'relay'`. The new optional field `signalProtocolRelayOwnsReceipt` holds the
  Relay receipt decision, the same decision as `relayOwnsReceipt`. A stored
  delivery status accepts the source `'signal-relay'`, the same source as
  `'relay'`. The SDK reads both values and both field names. When a record
  holds both field names, the new name wins.
- **The SDK writes the values of SDK 14.1.0.** This release writes the origin
  `'relay'`, the field `relayOwnsReceipt`, and the source `'relay'`, so SDK
  14.1.0 reads each record that it writes. The SDK does not rewrite or delete
  a stored record to change a value. It reports `'relay'` for a stored
  `'signal-relay'`.
- **A store refuses a record whose two field names hold different values.**
  `putReceiveWork` and a read of the record throw
  `SignalProtocolRelayNameConflictError`. A store that SDK 14.1.0 wrote opens
  with each record intact. You do not need to change the store.
- **A custom store keeps each value that it gets.** A
  `SignalProtocolLocalStore` that you write must store and return
  `'signal-relay'` and `signalProtocolRelayOwnsReceipt` without a change, as
  it does each other field.

### Deprecated package subpaths

- **Package subpaths without `signal-`.** Each subpath in the table has a new
  subpath. SDK 15.0.0 removes the earlier subpaths.

Each earlier subpath is a deprecated entry to the same files as its new
subpath. Thus the two subpaths load one module, and `instanceof` with a class
from either subpath is true for an object from the other. An exports map cannot
mark a subpath as deprecated, so the TypeScript tools do not mark an import of
an earlier subpath.

| Earlier subpath | New subpath |
| --- | --- |
| `@open-e2ee/signal-protocol-sdk/remote/relay` | `@open-e2ee/signal-protocol-sdk/remote/signal-relay` |
| `@open-e2ee/signal-protocol-sdk/remote/relay/types` | `@open-e2ee/signal-protocol-sdk/remote/signal-relay/types` |

The package files move to the same names. The directory `remote/relay/` is
now `remote/signal-relay/`. Each `client/relay-<name>.ts` file is now
`client/signal-relay-<name>.ts`. The hook files `use-relay-connection-state`
and `use-relay-lifecycle` are now `use-signal-relay-connection-state` and
`use-signal-relay-lifecycle`. The page `docs/RELAY_CONNECTION.md` is now
`docs/SIGNAL_RELAY_CONNECTION.md`. Import only the subpaths in the exports
map.

The Convex component, which the public package does not include, also changes.
Its `./convex.config` entry points to `remote/signal-relay/convex/component`,
and its cron `delete expired relay messages` is now
`delete expired signal-relay messages`. The component name stays
`signalProtocol`. On a local Convex backend, a deploy of this release kept the
component and its tables, deleted the earlier cron and its run history, and
added the new cron. The new cron ran once at the deploy, and its next run was
one hour later.

#### Upgrade steps

1. Replace each earlier subpath in the table with its new subpath. Code that
   keeps an earlier subpath runs unchanged in this release. Complete this step
   before SDK 15.0.0, which removes the earlier subpaths.
2. For a Convex deployment that mounts the component, keep the mount name
   `signalProtocol` and deploy. Before the deploy, copy the run history of
   `delete expired relay messages` if you need it, because the deploy deletes
   it. Change each monitor or alert that names the earlier cron to the new name.

### Deprecated: members and options without the Signal Protocol prefix

- **Members and options named `relay`.** Each member and option in the table
  has a new name in the `signalProtocolRelay` form. SDK 15.0.0 removes the
  earlier names. See steps 1 and 3.

An option accepts the new name or the earlier name. When a call sets both
names to different values, it fails with `SignalProtocolRelayNameConflictError`,
from `@open-e2ee/signal-protocol-sdk/types`. The error holds `newName` and
`earlierName`, and its code is `SIGNAL_PROTOCOL_RELAY_NAME_CONFLICT`. Two equal
values, or two byte arrays with the same bytes, do not fail. See step 2.

In this release, each interface that your code implements keeps the earlier
member required, with its earlier type, and adds the new member as optional.
This applies to `SignalProtocolRelayServer`, `SignalProtocolContentAdapter`, and
`HostedSignalProtocolRelayBootstrapResult`. An implementation with only the
earlier members compiles and works unchanged, and code that reads an earlier
member needs no change. When an implementation has both members, the SDK uses
the new member. SDK 15.0.0 requires the new members.

The SDK uses the name that the nearest level of an object defines, so a
subclass or a spread object that overrides only one name keeps its override.
For example, a subclass of `InMemorySignalProtocolRelayServer` that overrides
only `subscribeRelayConnectionState` gets the client subscriptions. Each SDK
class and each object that the SDK returns has both members, and one member
forwards to the other. `registerHook('onRelayProtocolError', hook)` registers
the hook under `onSignalProtocolRelayProtocolError`.
`bindSignalProtocolRelayLifecycle` and `useSignalProtocolRelayLifecycle` accept
an object with only the earlier members.

This release does not change bytes on the wire, signed bytes, or stored bytes.
The sealed sender field `relayScopeId` keeps protobuf field 7, and the group
authority certificate encodes the same bytes for both names.

Three options had a required earlier name: `SealedSenderConfig.relayScopeId`,
`HostedSignalProtocolRelayIdentityMigrationOptions.relayUrl`, and the
`relayScopeId` field of `encodeGroupAuthority`. Each now accepts either name,
so both names are optional, and the SDK requires one of the two. A call that
sets the earlier name compiles unchanged. Code that reads one of these fields
back from its own options object must handle `undefined`. See step 4.

| Type | Earlier name | New name |
| --- | --- | --- |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `relayConnectionState` | `signalProtocolRelayConnectionState` |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `subscribeRelayConnectionState` | `subscribeSignalProtocolRelayConnectionState` |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `startRelaySubscription` | `startSignalProtocolRelaySubscription` |
| `SignalProtocolClient`, `DefaultSignalProtocolClient` | `stopRelaySubscription` | `stopSignalProtocolRelaySubscription` |
| `SignalProtocolRelayServer`, `InMemorySignalProtocolRelayServer`, `ConvexSignalProtocolRelayServer` | `relayConnectionState` | `signalProtocolRelayConnectionState` |
| `SignalProtocolRelayServer`, `InMemorySignalProtocolRelayServer`, `ConvexSignalProtocolRelayServer` | `subscribeRelayConnectionState` | `subscribeSignalProtocolRelayConnectionState` |
| `SignalProtocolClientConfig` | `relay` | `signalProtocolRelay` |
| `SignalProtocolClientAdapterConfig` | `relay` | `signalProtocolRelay` |
| `SignalProtocolClientContext` | `relay` | `signalProtocolRelay` |
| `SealedSenderConfig` | `relayScopeId` | `signalProtocolRelayScopeId` |
| `GroupAuthorityFields` | `relayScopeId` | `signalProtocolRelayScopeId` |
| `SignalProtocolClientHooks` | `onRelayProtocolError` | `onSignalProtocolRelayProtocolError` |
| `SignalProtocolContentAdapter` | `setRelayBatching` | `setSignalProtocolRelayBatching` |
| `OutgoingMessageError` | `relayRetryable` | `signalProtocolRelayRetryable` |
| `HostedSignalProtocolRelayBootstrapResult` | `relay` | `signalProtocolRelay` |
| `HostedSignalProtocolRelayBootstrapResult` | `relayScopeId` | `signalProtocolRelayScopeId` |
| `HostedSignalProtocolClientOptions` | `hosted.relayUrl` | `hosted.signalProtocolRelayUrl` |
| `HostedSignalProtocolResumeOptions` | `hosted.relayUrl` | `hosted.signalProtocolRelayUrl` |
| `HostedSignalProtocolRelayManagedDeviceLinkOptions` | `hosted.relayUrl` | `hosted.signalProtocolRelayUrl` |
| `HostedSignalProtocolRelayIdentityMigrationOptions` | `relayUrl` | `signalProtocolRelayUrl` |
| `CreateTestClientOptions` | `sharedRelay` | `sharedSignalProtocolRelay` |
| `TestClientResult` | `relay` | `signalProtocolRelay` |
| `SignalProtocolClientInternals` | `relay` | `signalProtocolRelay` |
| `SignalProtocolServiceCipher` | `setRelayProtocolErrorReporter` | `setSignalProtocolRelayProtocolErrorReporter` |

#### Upgrade steps

1. Replace each earlier name in the table with its new name where your code
   reads a member or sets an option. Code that keeps an earlier name compiles
   and runs unchanged in this release. The TypeScript tools mark the earlier
   name as deprecated.
2. Set each option by one name only. If your code sets both names, for example
   during a migration, give them the same value or remove the earlier name.
3. In a class or object that implements `SignalProtocolRelayServer`,
   `SignalProtocolContentAdapter`, or `HostedSignalProtocolRelayBootstrapResult`,
   add the new member and keep the earlier member. This release requires the
   earlier member. Let one member forward to the other, or give both the same
   value. SDK 15.0.0 requires the new member and removes the earlier member.
4. Find each read of `relayScopeId` or `relayUrl` from your own
   `SealedSenderConfig`, `GroupAuthorityFields`, or
   `HostedSignalProtocolRelayIdentityMigrationOptions` object. This release
   makes the field optional, so the type of the read includes `undefined`.
   With the TypeScript `strict` option, this function compiles with SDK 14.1.0
   only:

   <!-- doc-snippet:skip requires-external-context -->
   ```ts
   import type { SealedSenderConfig } from '@open-e2ee/signal-protocol-sdk';

   function scopeOf(config: SealedSenderConfig): Uint8Array {
     return config.relayScopeId;
   }
   ```

   Read the new name first and the earlier name second, and handle
   `undefined`. This function compiles with this release:

   <!-- doc-snippet:skip requires-external-context -->
   ```ts
   import type { SealedSenderConfig } from '@open-e2ee/signal-protocol-sdk';

   function scopeOf(config: SealedSenderConfig): Uint8Array {
     const scope = config.signalProtocolRelayScopeId ?? config.relayScopeId;
     if (scope === undefined) {
       throw new Error('The sealed sender configuration has no Relay scope.');
     }
     return scope;
   }
   ```

   When your code sets only `signalProtocolRelayScopeId`, remove
   `?? config.relayScopeId`. SDK 15.0.0 removes the earlier name. Do the same
   for `relayUrl` with `signalProtocolRelayUrl`.

## 14.1.0

### Added

- `hostedRelayDeviceOwnedIdentity(storage)`, from the package root and
  `@open-e2ee/signal-protocol-sdk/client`. It returns a `getIdentityAssertion`
  callback for a device-owned account in a Sandbox environment or in a
  Production environment in device-owned identity mode. It signs a
  normal-assurance registration assertion with an Ed25519 key in `storage`.
  It refuses recovery, refresh, provider migration, and recent or step-up
  assurance, and creates no key for a refused request. Its TSDoc documents
  the header and claims of the assertion. It uses the key slot of
  `hostedRelaySandboxIdentity`, so for the same store and publishable key both
  helpers return the same account. `hostedRelaySandboxIdentity` keeps its
  Sandbox-only behavior. A Production project in application-bound mode
  refuses the assertion with `ASSERTION_INVALID`.

### Changed

- **The OpenE2EE Signal Protocol Relay mailbox socket stays open across a device
  token renewal.** The Relay authorizes the device token once, at the socket
  handshake, and closes the socket with 4401 `AUTHORITY_REVALIDATE` when the
  authority changes. Before, the hosted transport closed and reopened the socket
  shortly before each token expired, about every 14 minutes. Now it renews the
  token only for an HTTP request or a reconnect, and reconnects only on a Relay
  close or a transport error. The presence watches and the Relay receipt intake
  stay on the one socket. `onConnectionState` and `relayConnectionState` no
  longer emit `reconnecting` for a failed renewal socket, because no renewal
  socket exists. No API changes. See `docs/RELAY_CONNECTION.md`.

### Fixed

- **A `PERIOD_CLOSED` refusal gets one repeat.** When the Relay refuses
  a device post with `PERIOD_CLOSED`, the SDK posts the same request once more,
  with the same message ID, epoch and bytes. When the Relay refuses the repeat
  too, the device stays pending: the send throws a retryable error with its
  deadline, and a replay posts the same operation. On the sealed route the
  error code stays `DELIVERY_FAILED`.
- **A send reaches a recovered device.** When the Relay refuses a
  device post with `NOT_FOUND` because the mailbox generation of the device is
  retired, and the device list names the device at a new generation, the SDK
  archives the session, starts a new session and posts to the new generation
  under the same message ID and epoch. The other devices keep their
  acceptance, and the Relay charges each device once. Before, the device ended
  with a `NOT_FOUND` refusal.

## 14.0.0

### Breaking

- **`decryptGroupMessage` is removed from the client.**
  `DefaultSignalProtocolClient` and the `SignalProtocolClient` interface no
  longer have the method, which 12.0.0 deprecated. Use
  `processIncomingEnvelope`. It returns a receive outcome and keeps the
  content until `completeReceive`. Give it the framed message as a
  `sender_key` envelope. The client resolves the group from the frame. See
  step 20.
- **Managed group content with no group context is denied.** A client with
  a `groups` config denies all such content. The reason is
  `legacy-no-context`, also when the client has state of the group. An
  earlier check can deny the content first, such as `blocked` for a blocked
  group. Before, the client decided such content against its local group
  state. Content from an SDK 11 sender is not delivered. A client with no
  `groups` config refuses such content with a `GroupReceiveRefusedError` of
  reason `configuration`. See step 21.
- **A send to a managed group with no stored master key throws.** When the
  client has a `groups` config and its group store has no master key for
  the managed group, a new send or a manual resend of content with no
  logged group context throws `EncryptionError` with the new code
  `GROUP_MASTER_KEY_MISSING`, and stores and posts nothing. An attachment
  send also uploads nothing. A manual resend of logged content that
  carries a group context keeps that context and needs no master key. A
  replay that must build a sent transcript for an own device skips that
  transcript, keeps its posts, and logs one warning with the code.
  Before, the client posted content with no group context, which every
  receiver now denies. A send to an ad hoc group does not change.
  See step 21.
- **The output of `encryptGroupMessage` is denied for a managed group.**
  The primitive adds no group context and checks no master key. Unless the
  plaintext already carries a group context, a `processIncomingEnvelope`
  receiver denies the output for a managed group. A receiver with a `groups`
  config gives the reason `legacy-no-context`, or `blocked` when the group
  is blocked. A receiver with no `groups` config refuses the output with a
  `GroupReceiveRefusedError` of reason `configuration`. The primitive
  remains for a caller that delivers the bytes itself and decrypts them
  with `decryptEnvelope`. See step 21.
- **`ReceivedContent` is removed.** The type of an SDK 11 received-content
  row, which 13.5.0 deprecated, is no longer exported. Use
  `ReceiveWorkRecord`. See step 22.
- **`ReceiveWorkRecord.awaitingEnvelope` is removed, and the sender fields
  are required.** Each `ReceiveWorkRecord` now has the required fields
  `messageId`, `senderUserId` and `senderDeviceId`. See step 22.
- **The legacy received-content conversion is removed, and the SQLite open
  wrapper is renamed.** `LegacyConversionMarker`,
  `LegacyReceivedContentSource`, `convertLegacyReceivedContent`,
  `legacyReceiveWork`, `LEGACY_RECEIVED_CONTENT_UNREADABLE`,
  `receivedContentKey`, `parseReceivedContent`,
  `legacyReceivedContentSource` and `KeyValueReceiveWork.legacySource` are
  no longer exported. No store converts an SDK 11 received-content row.
  `convertSqliteLegacyReceivedContent` is now
  `sweepSqliteLegacyReceivedContent`. It keeps its contract: when the sweep
  fails, it closes the database and throws the error again. See step 22.
- **Each durable store deletes the legacy received content at open.** At
  each open, the IndexedDB, SQLite and key-value stores delete every SDK 11
  received-content row and every converted record that waits for its
  envelope. The sweep reads each row only to count the readable rows, then
  deletes it. It logs one warning with the code
  `LEGACY_RECEIVED_CONTENT_DELETED` and two fields: `count` holds the
  deleted rows and records, and `readable` holds the deleted rows that
  parse. A readable row is in a store that SDK 12.0.0 or later never opened.
  The sweep relies on the Relay retention constraint. The Relay keeps an
  undelivered envelope for at most its retention period, 30 days in
  production. The constraint does not cover a device that received the
  content on SDK 11 inside the last 30 days. For that device, 13.x would
  convert the row and complete it when the Relay delivers the envelope
  again. This release deletes the row at first open, and the sweep does not
  restore it. An open that finds nothing logs nothing. The memory store
  keeps no data across a restart and has no sweep. See step 22.
- **`SignalProtocolContentAdapter` has the required method
  `serializeGroupKeySync`.** `ParsedSyncContent.type` has the new member
  `'groupKeySync'`, and `ParsedSyncContent` has the new optional field
  `groupKey`. A custom adapter must implement the method, and its
  `inspectContent` must report the result as a sync of type `'groupKeySync'`
  with its `groupKey`. An adapter that spreads the result of
  `createDefaultSignalProtocolContentAdapter()` into itself gets the default
  method. Code that switches on the sync `type` must handle
  `'groupKeySync'`. See step 23.
- **The retry terminal class `expired-content` is now `request-expired`.**
  `RetryTerminalClass` no longer holds `expired-content`. A retry request
  whose latest attempt the Relay answered or holds ends as `request-expired`
  when its content did not come before its deadline. The session does not
  reset. A retry request whose latest attempt the Relay did not accept ends
  as `posting-deadline` at its posting deadline or its deadline. The session
  resets. Only a `posting-deadline` end resets the session. The class
  `request-expired` is not the delivery error cause `request-ended`. At
  client start, the SDK moves each stored retry request record to a new key
  prefix, and rewrites a stored `expired-content` end to `request-expired`.
  It keeps the time, the emitted flag and the session reset of the end, so
  a moved end can carry `event.recovery` from an SDK 13.x reset. The reader
  also reads a stored `expired-content` end as `request-expired`. That
  reader is removed only when both conditions are true: the next major SDK
  version ships, and at least 60 days have passed since the publish day of
  14.0.0. See step 24.
- **Each send timestamp is unique per sender device.** A new send reserves
  its timestamp in the store before it writes its intent and before it posts
  anything. A new send with a timestamp that a different send of the device
  used throws `InvalidSendTimestampError` with the new reason
  `already_used`, and stores and posts nothing. The SDK's own sends, the
  profile key offer and the sender key distribution, reserve from the same
  index of the device. So an application that passes
  `timestamp: Date.now()` can get `already_used` when it did not use the
  value again itself. Omit `timestamp`, or send again with no `timestamp`
  on `already_used`. When a different send used the timestamp that the SDK
  reads from its clock, the SDK moves to the next free millisecond. A moved
  timestamp more than 5 minutes ahead of the SDK clock throws the error with
  the reason `too_far_ahead`. A reservation with no stored send holds its
  timestamp for 5 minutes, and a new send can then take it. A send that
  spends longer than 5 minutes between its reservation and its stored
  intent, and whose timestamp another send took in the meantime, fails with
  `already_used` instead of posting a duplicate timestamp.
  `InvalidSendTimestampError.earliest` and `latest` are now optional, and
  are absent for `already_used`. `SendResult.clientTimestamp` is now
  required, and every send returns it. After the SDK has stored a send, a
  retry with the same `clientMessageId` keeps the original timestamp and
  reserves nothing. A send that failed before the SDK stored it gets a new
  timestamp on retry. A manual resend, a retry answer and a group resend
  keep the original timestamp and reserve nothing. A sync to linked devices
  and the null message of a session reset reserve no timestamp. See step 25.
- **A received message is keyed by its sender and timestamp only.** The
  receive queue drops a copy by the key `[senderUserId, timestamp]`. A later
  message of the same sender with the same timestamp drops with no notice
  and runs no `onMessageDecrypted`. This applies to any body and to any
  device of the sender. `ReceivedMessageKey` no longer has the fields
  `contentDigest` and `senderDeviceId`. At the first start on this release,
  the SDK moves the stored received-timestamp records to a new prefix. Two
  old records of one sender and timestamp become one record with the
  earliest receive time. A custom store that checks
  `ReceiveWorkRecord.received` gets a key with the two fields `senderUserId`
  and `timestamp`. A receive record that SDK 13.x stored can still carry
  `senderDeviceId` and `contentDigest` in `received`, and a custom store must
  accept that shape until the next major. A send to the own account posts
  only a sent transcript to each other own device, and posts nothing when
  the account has no other device. See step 26.
- **The stores refuse SDK 13.x after the first open of this release.** The
  IndexedDB store opens its database at version 12, and the SQLite store
  applies step 7. Neither changes a table. A 13.x tab then fails to open
  the database with `VersionError`, and a 13.x SQLite store refuses the file
  with `INVALID_STATE`. An open IndexedDB connection of this release closes
  when another connection opens a newer version. When an open connection of
  an older tab blocks the open, the store logs one warning with the code
  `INDEXEDDB_OPEN_BLOCKED` and the field `version`, and the open completes
  when that connection closes. The key-value store has no guard.
  See step 27.

#### Upgrade steps

20. Replace `decryptGroupMessage` with `processIncomingEnvelope`. A cipher
    primitive that returns plaintext has a `decrypt*` name, such as
    `decryptMessage`, `decryptEnvelope` and `decryptFile`. A receive
    workflow that returns an outcome and keeps the content until
    `completeReceive` has a `process*` name, such as
    `processIncomingEnvelope`. Pass the delivered envelope with its Relay
    `id`. An envelope with no `id` takes no receive lock, and a repeat call
    gives the retained content again until `completeReceive`. A refusal now
    gives a `denied` outcome and runs `onDecryptionError` instead of
    throwing. A retryable decrypt failure sends a retry request and throws.
    Receives that 13.x `decryptGroupMessage` left pending complete through
    `completeReceive` once `listPendingReceives` lists them at
    `awaiting-completion`. A `completeReceive` call before that stage
    deletes nothing. A repeated `processIncomingEnvelope` call with the
    same frame does not find them. It fails with `DECRYPTION_FAILED` and
    sends a retry request. So stop any 13.x re-call loop and use
    `listPendingReceives`.
21. Expect a denial for all managed group content with no group context. A
    client with a `groups` config gives the reason `legacy-no-context`. An
    earlier check can deny the content first, such as `blocked` for a
    blocked group. A client with no `groups` config refuses such content
    with a `GroupReceiveRefusedError` of reason `configuration`. Before, the
    client decided such content against local group state. Every sender must
    run SDK 12.0.0 or later. A client with a `groups` config whose group
    store has no master key for a managed group now refuses a new send to
    that group, and a manual resend of content with no logged group
    context. It throws `EncryptionError` with the
    code `GROUP_MASTER_KEY_MISSING`, and stores and posts nothing. An
    attachment send also uploads nothing. Store the group master key through
    the link or sync path, then send again. A manual resend of logged content
    that carries a group context keeps that context. A replay that must build
    a sent transcript for an own device skips that transcript, keeps its
    posts, and logs one warning with the code. The output of
    `encryptGroupMessage` carries no group context unless its plaintext holds
    one. A `processIncomingEnvelope` receiver with a `groups` config denies it
    for a managed group as `legacy-no-context`, or as `blocked` when the group
    is blocked. A receiver with no `groups` config refuses it with a
    `GroupReceiveRefusedError` of reason `configuration`. Send managed group
    content with `send`. A caller that delivers the bytes of
    `encryptGroupMessage` itself decrypts them with `decryptEnvelope`.
22. Expect each durable store to delete every SDK 11 received-content row
    at the first open on this release. It also deletes every converted
    record that waits for an envelope, and it logs the count once with the
    code `LEGACY_RECEIVED_CONTENT_DELETED`. It also deletes each readable
    SDK 11 row in a store that SDK 12.0.0 or later never opened, and the
    count line carries that number in the separate field `readable`. The
    sweep relies on the Relay retention constraint. The Relay keeps an
    undelivered envelope for at most its retention period, 30 days in
    production. Where the constraint holds, no SDK version shows the content
    of such a row. The constraint does not cover a device that received the
    content on SDK 11 inside the last 30 days. For that device, 13.x would
    convert the row and complete it when the Relay delivers the envelope
    again. This release deletes the row at first open, and the sweep does not
    restore it. Remove all use of `ReceivedContent`,
    `ReceiveWorkRecord.awaitingEnvelope`, `receivedContentKey` and
    `parseReceivedContent`. A custom store must now set `messageId`,
    `senderUserId` and `senderDeviceId` on each `ReceiveWorkRecord`.
23. Upgrade every own device of one account in one release. An own device
    on an older SDK version gives the raw group key sync to
    `onMessageDecrypted`. That sync holds the group master key. A custom
    content adapter must implement `serializeGroupKeySync`, or spread the
    result of `createDefaultSignalProtocolContentAdapter()` into itself.
    Handle `'groupKeySync'` when you switch on `ParsedSyncContent.type`. A
    custom local store must keep each metadata value across a close and a
    reopen. The first start on this release sends one `GroupKeySync` for
    each managed group with a verified record and with stored state that
    lists the account as a member, to each other own device.
24. Replace `case 'expired-content':` with `case 'request-expired':` in
    `onRetryTerminal`. A retry request whose latest attempt the Relay
    answered or holds ends as `request-expired` at its deadline and resets no
    session. A retry request whose latest attempt the Relay did not accept
    ends as `posting-deadline` at its posting deadline or its deadline. It
    resets the session. Only `posting-deadline` resets. A record that the
    migration moved can carry `event.recovery` with `request-expired` during
    the reader window. Do not confuse `request-expired` with the delivery
    error cause `request-ended`. The reader window lasts until the next major
    SDK version ships, and for at least 60 days after the publish day of
    14.0.0. In that window, the SDK reads a stored `expired-content` end as
    `request-expired`.
25. Expect a unique send timestamp per device. A new send with a timestamp
    that a different send of the device used throws
    `InvalidSendTimestampError` with the reason `already_used`. The field
    `SendResult.clientTimestamp` is now required. Read the timestamp there
    when the SDK picks it. A retry with the same `clientMessageId`, a manual
    resend and a retry answer keep the original timestamp. The fields
    `InvalidSendTimestampError.earliest` and `latest` are absent for
    `already_used`.
26. Expect the SDK to drop a later message of the same sender with the same
    timestamp. This applies to any device of the sender. The rule also
    covers sent transcripts from two own devices in two conversations. A
    custom store that checks `ReceiveWorkRecord.received` gets a key with
    `senderUserId` and `timestamp` only. A note to self arrives at each
    other own device as a sent transcript only.
27. Do not go back to SDK 13.x after the first open on this release. A 13.x
    reader throws on a record of this release and does not degrade. A 13.x
    web tab fails to open with `VersionError`. A 14.x open waits for each
    open 13.x tab to close. A 13.x SQLite store refuses the file with
    `INVALID_STATE`. The key-value store has no guard, so stop each 13.x
    process on it before the first 14.x open.

### Added

- **Own devices get the key of each managed group.** When a client creates a
  managed group, joins one through an invite link, or accepts a member
  invitation, it sends one `GroupKeySync` with the group master key and the
  revision to each other own device. When the client sees an own device for
  the first time, it sends the key of each group to that device only. Each
  start sends the key of each group to each own device that the key sync
  ledger does not mark for the group. So the first start on this release
  sends one `GroupKeySync` for each group and own device, and a start after
  a complete run sends none. The ledger marks the own devices whose copy
  the Relay accepted and the own device that sent this device the key, so
  a refused or failed send is sent again at the next start. A group sends
  no key while its record is unverified, while it has no stored state, or
  while its stored state does not list the account as a member. The
  receiver accepts a `GroupKeySync` only from its own account. For a group
  with no record, it writes the group record with the source `'sync'`
  before the master key, and schedules a fetch of the group. So an own
  device knows the group with no group traffic. A record that exists keeps
  its source. A `GroupKeySync` from an own device clears the unverified
  origin that a group context set, so the group leaves the per-sender
  `unverified-cap`. A record that already has its master key gets no new
  fetch, and a repeated `GroupKeySync` applies once.
  `processIncomingEnvelope`, the Relay subscription and the receive queue
  consume the content, so the application never gets it from them, and
  `processIncomingEnvelope` gives the outcome `null-message`.
  `decryptEnvelope` and the raw decrypt methods `receive`, `decryptMessage`
  and `decryptMessages` return the sync unapplied, master key included. The
  ledger is one metadata value for each group, under the key prefix
  `open-e2ee:group-key-sync:v1:`. The client deletes the value when it
  removes the group record. See step 23.

### Fixed

- **A dying page no longer leaves a rotated pin with sessions.** The
  IndexedDB store now writes the new pin last. If a page stops inside an
  identity rotation transaction, a browser can commit only part of it. The
  store then keeps the old pin. Before, the store could keep the new pin
  together with sessions of the old identity. An encrypt on such a session
  then failed the identity trust check, and the send reported
  `EncryptionError` with code `ENCRYPTION_FAILED` for that device.
- **A dying page no longer leaves a session with unused prekeys.** The
  IndexedDB store now deletes the one-time prekeys, records the Kyber
  prekey use, and deletes the sender-key handoff rows of the device first.
  It writes the pin, then the receive record, and then the session. If a page
  stops inside a session commit, a browser can commit only part of it.
  Before, the store could keep the receive record of a PreKey message
  without its session while the one-time prekeys of that message stayed.
  It could also keep the session while the one-time prekeys stayed or the
  Kyber prekey use was not recorded. It could also keep the session with
  handoff rows of the device, so a group send could skip the sender key
  for that device. Now a commit that stops before the receive record keeps
  no session. If it already deleted a one-time prekey of the message, a
  redelivery of that PreKey message fails with `EncryptionError` with
  code `PREKEY_NOT_FOUND`, and the client sends a retry request to the
  sender. If it recorded only the Kyber prekey use, the next entry
  applies. A commit that stops between the receive
  record and the session keeps the content, and the client gives it to
  the application.
- **A PreKey message whose Kyber prekey use the store recorded without its
  session now gets a resend.** A session commit that stops after the Kyber
  prekey use and before the session leaves that state. No released write
  order could leave it, and the order above can. Without this change,
  each redelivery of that PreKey message fails at the session commit
  with `ReusedBaseKeyError`, the client does not acknowledge the envelope
  and sends no retry request, and the message never arrives. Now, when no
  session of the sender device holds the base key of the message, the
  failure is a retryable decryption error. The client sends a retry
  request to the sender and acknowledges the envelope. The sender makes a
  new session from a fresh prekey bundle, with a new base key, and resends.
  `processIncomingEnvelope` sends the request and throws `EncryptionError`
  with code `DECRYPTION_FAILED`.

## 13.5.2

### Fixed

- Point the npm provenance badge at its section on npmjs.com.

## 13.5.1

### Fixed

- Correct code examples and local links in ten SDK 13.5 guides.

## 13.5.0

### Added

- `SendAcceptanceUnknownError`, code `SEND_ACCEPTANCE_UNKNOWN`, from
  `@open-e2ee/signal-protocol-sdk/types`. A direct or group send throws it
  when its posting deadline ends and the Relay acceptance of a device is not
  known. The message might have arrived. It gives `deadlineAt`,
  `acceptedDevices`, `unknownDevices` and `refusedDevices`, and its
  `retryable` is false.
- `SendNeverAcceptedByRelayError`, code `SEND_NEVER_ACCEPTED`, from the same
  subpath. A direct or group send throws it when the deadline ends and the
  Relay accepted no request for an open device. The call and each replay throw
  it only when the call raised no refusal (a thrown refusal or a refusal in the
  receipt of a shared body) and no refused device has a stored refusal code.
- `deadlineAt`, `relayRetryable`, `acceptedDevices` and `refusedDevices` on
  send errors.
- With a store that lists its metadata keys, the SDK now replays each open
  send at start and when the Relay connection returns. It ends each send at
  its posting deadline, or at the next start or connect after it. It posts
  nothing for a send past its deadline.
- `onSendOutcome` on the client hooks, with `SendOutcomeEvent`. The SDK calls
  it once for each end of a send, from its own replay or from your call. It
  reports `content-required` when the plaintext of an open send is gone. An
  internal send of the SDK, such as a sender key distribution, never reaches
  it. The SDK keeps no content of a sender key distribution, so it does not
  replay one. It ends an open distribution at its deadline, and a retry
  request of the receiver recovers a lost distribution. One exception: an
  open sender key distribution that an earlier SDK version stored carries no
  marker, so the hook gets `content-required` for it once for each client
  run before its deadline, and its end once at its deadline. Ignore an ID
  that your application never sent.
- The optional method `listMetadataKeys` on `SignalProtocolLocalStore`, with
  `MetadataKeyQuery`. Every built-in store implements it.
- `resendMessage(clientMessageId)` on the client. After a send ends with
  `SendAcceptanceUnknownError` or `SendNeverAcceptedByRelayError`, it posts
  the message again to each recipient device that the Relay did not accept.
  The resend is a new operation with a fresh operation time and the message
  ID `<clientMessageId>:manual:N`. Its content keeps the original timestamp.
  A resend of a group send posts the content of its send log entry, so each
  copy carries the group context of the original send, not the current one.
  It has its own posting deadline 24 hours after the call, and the SDK replays
  it until then. The Relay can charge the resend as a new message, and the
  message might already have arrived. `onSendOutcome` reports the end of each
  resend once, with `manualResend`. Only a send younger than 30 days takes a
  new resend.
- `outcome` on `DeviceSetReconciliationError`: `failed` or
  `acceptance-unknown`. With `acceptance-unknown`, the message might have
  arrived. Treat it like `SendAcceptanceUnknownError`.
- Relay protocol version 2, and its Relay code `DELIVERY_ALREADY_ACCEPTED`.
  The Relay gives the code to a version 2 request, with HTTP status 409,
  `retryable` false and the `details` reason `message-id-held`, when it
  already holds an accepted post under the message ID. It stored nothing
  for the post. A version 1 request gets `RETRY_CONFLICT` for the same case.
  The SDK reads the code as it reads `RETRY_CONFLICT`: on a direct post, a
  sealed direct post, a pre-message and a group shared body, it is an earlier
  acceptance with no receipt, under the same rules. The sealed path keeps the
  code on its error. In the answer to a version 1 request, the code is an
  unknown Relay code.

### Changed

- A direct send now has a posting deadline: the earlier of 24 hours after the
  SDK first stores it and 24 hours after its timestamp. A replay or a restart
  never moves it. SDK 13.4 had no posting deadline.
- At or after the deadline, the SDK starts no request for the send. This
  includes a transport repeat and the identified fallback. A request that
  started before the deadline still counts when its answer arrives later.
- SDK 13.4 posted a direct send whose timestamp was exactly 24 hours old. The
  SDK now stores it, posts nothing and throws `SendNeverAcceptedByRelayError`.
- SDK 13.4 posted an attachment send whose upload finished after its
  timestamp plus 24 hours. The SDK now posts nothing and throws.
- SDK 13.4 replayed a stored direct send after 24 hours and posted it again.
  The SDK now posts nothing at or after the deadline, and the replay ends
  with `SendAcceptanceUnknownError` or the failed-end error of the next entry.
- When a send ends failed and the call that ends it raised a refusal, the
  first such refusal is the error. A thrown refusal keeps its SDK 13.4 class,
  and a refusal in the receipt of a shared body is an `Error` with its `code`.
  Otherwise, the end throws an `Error` with the `code` of the first refused
  device that has a stored code, in the order of the destinations. With no
  such device, it throws `SendNeverAcceptedByRelayError`. A replay of the
  ended send raises no refusal. Each of these errors has `acceptedDevices`,
  `refusedDevices` and `deadlineAt`.
- Before the deadline, a send error that leaves a device open now has
  `retryable` set to true. In SDK 13.4 that field held only the Relay's hint.
  `relayRetryable` now keeps that hint.
- SDK 13.4 threw `RETRY_CONFLICT` from a direct send or a sealed direct send
  when the Relay already held bytes under its ID. The SDK now counts that
  answer as an earlier acceptance, and the send goes on. This applies when the
  SDK stored the send from its first post, and no repair replaced the session
  of that device.
- In other cases, the acceptance of that device is unknown. Before the
  deadline, the send still throws `RETRY_CONFLICT`, now with `retryable` true
  and `deadlineAt`. At the deadline, it throws `SendAcceptanceUnknownError`.
- Such an answer has no Relay receipt. The send result takes its `messageId`
  from a Relay receipt of another device when one exists. When every accepted
  device gave that answer, `messageId` is the `clientMessageId`.
- Such an answer raises no `DEVICE_SET_UNCHECKED` report through
  `onRelayProtocolError`, because it has no receipt to check.
- SDK 13.4 threw `RETRY_CONFLICT` from a group send when a pre-message got it.
  The group send now goes on. A pre-message that counts it as an acceptance
  records the sender-key handoff, as for any acceptance.
- A pre-message whose session the SDK replaced records no handoff when it
  gets that answer, and the acceptance of its device is unknown. The next
  group send gives the key again. This also holds on a replay.
- SDK 13.4 threw from an undeclared send when a sync copy failed. When the
  deadline stops a sync copy, the send now returns `syncPending`. A replay of
  that send returns the same result and posts nothing. Other sync failures
  still throw.
- A replay of a send with `syncPending` posts the pending sync copies only
  before `deadlineAt`. At or after it, the replay posts nothing and returns
  the stored result with `syncPending`.
- One case differs. When the send has no sync copies yet, the replay reads
  the own device list again. If it finds no other own device, the send
  completes without `syncPending`.
- A replay of an ended send with the same content throws the stored result
  again and posts nothing. A DataMessage replay takes the stored timestamp.
- A replay of a direct send now posts only the devices that the Relay did not
  accept. SDK 13.4 posted every device again. A replay also skips the sync
  copies that the Relay accepted.
- A replay of a DataMessage send now keeps its stored timestamp. SDK 13.4 read
  a new timestamp and refused the replay as a different message.
- A `RETRY_CONFLICT` answer counts as an earlier acceptance unless the SDK
  replaced the session of that device. A repair that adds a missing device
  after `DEVICE_SET_MISMATCH` replaces nothing, so the added device counts as
  accepted. A device whose session the SDK replaced after `STALE_DEVICE`
  stays unknown, because the Relay can hold a message sealed to the old
  session. This now also holds on a replay of a send that this SDK version
  stored. On a replay of a send that SDK 13.4 stored, a `RETRY_CONFLICT`
  answer stays uncertain.
- A send or its replay now ends at once, before the deadline, and posts
  nothing, when every open device got `OPERATION_EXPIRED` as the last answer
  in the call or has a refusal that the SDK cannot recover, and throws an `Error` with the stored
  code of the first refused device that has one, in the order of the
  destinations.
  A `STALE_DEVICE` refusal counts only after the SDK repaired the session and
  the Relay refused the repaired post too. A request with no answer, an
  uncertain answer, or a send stored by SDK 13.4 still gives
  `SendAcceptanceUnknownError`.
- A send that an earlier SDK stored gets its deadline from its stored times.
  The SDK stores that deadline at its next change of the send.
- A group send now has the same posting deadline as a direct send. SDK 13.4
  posted a group send whose timestamp was exactly 24 hours old, and it
  replayed a stored group send after 24 hours. Both now post nothing at the
  deadline, and the send ends with `SendAcceptanceUnknownError` or the
  failed-end error of the direct send rule. The deadline also stops a pre-message, its
  identified fallback, the shared body and a sync copy.
- A group send now records the Relay answer of each device: of each
  pre-message, of each device post, and of the shared body for each of its
  destinations. A replay posts only the devices that the Relay did not
  accept. A device that the receipt of the shared body refuses counts as
  refused, as a thrown refusal does, and the end error follows the rule of a
  direct send. A replay of the ended send gives the stored code of the first
  refused device that has one, in the order of the destinations. That code
  can differ from the code of the call.
- A `RETRY_CONFLICT` answer to the shared body of a group send counts as an
  earlier acceptance of each of its destinations. It raises no
  `DEVICE_SET_UNCHECKED` report through `onRelayProtocolError`. The answer
  has no receipt that can ask for a sync phase, so the send reads the own
  device list once to find the devices that need a sync copy.
- A `RETRY_CONFLICT` answer to a group device post or pre-message whose
  session the SDK replaced after `STALE_DEVICE` gives acceptance-unknown for
  that device. On a device that a repair only added, or that no repair
  changed, it counts as an earlier acceptance. The call and a replay after a
  restart give the device the same class.
- SDK 13.4 started a send that ended with `DeviceSetReconciliationError`
  again at 0 restarts when the application called `send()` with the same
  `clientMessageId`. After an end in the recipient phase, the SDK now stores
  the send outcome. That call throws `SendAcceptanceUnknownError` or
  `SendNeverAcceptedByRelayError` and posts nothing. After an end in the sync
  phase, the send keeps its result, and that call posts the sync phase again.
- An `UPGRADE_REQUIRED` or `DEVICE_REVOKED` answer now ends a send at once as
  failed, or as acceptance-unknown when the acceptance of a device is not
  known. SDK 13.4 threw the answer and left the send open.
- A recipient now drops a message that carries the same sender device, the
  same content timestamp and the same content as a message it already
  received. The drop also covers a copy under a new message ID, such as a
  manual resend. Two different messages of one sender device in one
  millisecond both deliver. The drop needs the timestamp that the content
  adapter reads from the message. Content with no timestamp, such as raw
  string or byte content, takes no drop key, and a recipient that holds it
  receives the copy again. The recipient records the message with the
  completion of its receive record. When a delivery receipt is due, it
  records the message right after the receipt-due write and again with the
  completion of the receipt. When no receipt is owed, a stop before the
  completion of the receive record runs `onMessageDecrypted` again. When a
  receipt is owed, only a stop before the receipt-due write runs it again.
  The record expires after 60 days.
- A retry resend no longer encrypts again under the same ID after the Relay
  answers `OPERATION_EXPIRED` to its stored bytes. SDK 13.4 encrypted the
  content again with a fresh operation epoch and posted the new bytes. The SDK
  now posts nothing more under that ID. It records that the acceptance of the
  attempt is unknown.
- The same applies to a stored null-message answer and to the current
  sender-key distribution that answers a group retry request. SDK 13.4
  encrypted both again under the same ID. For the distribution, the SDK still
  deletes the sender-key handoff of the requester, as SDK 13.4 does, so the
  next group send gives the key again.
- When the plaintext of that message is gone, the SDK still posts the
  null-message session reset under its own ID, as SDK 13.4 does.
- The SDK still counts such an answer toward the response limit, and it still
  completes a group resend job as posted, as SDK 13.4 does after its post.
- A later retry request from the same device has a new attempt and a new ID,
  so it gets a new encryption, as in SDK 13.4.
- A hosted group fan-out post now repeats once when the Relay answers 503
  `DELIVERY_UNCERTAIN`. The repeat sends the identical request with the same
  `logicalSendId`, as a direct post does. SDK 13.4 threw that error after the
  first answer. A second uncertain answer reaches the caller. No other error
  code starts a repeat.
- After such a repeat, the group send result has no `duplicate` field,
  because the first request can have stored the fan-out.
- A send can be stored without its timestamp lookup when a write fails
  between the two. Without the lookup, an E2EE delivery receipt for the
  message gives no delivery event, and a retry request for a group message
  does not find its group. When the SDK stores the same send again, it now
  also stores a missing lookup and changes nothing else in the stored send.
  SDK 13.4 did not. A replay of a stored send does not store it again in this
  release, so a replay does not restore the lookup.
- Each hosted client now holds its Relay protocol version internally, and
  every Relay request and the mailbox socket of that client send it. SDK 13.4
  read one fixed version for the whole SDK. No option changes it.
- The default Relay protocol version is now version 2. Each Relay request
  sends `x-open-e2ee-relay-protocol: 2`, and the mailbox socket offers
  `open-e2ee-relay.v2`. SDK 13.4 sent version 1. A Relay that does not serve
  version 2 answers `PROTOCOL_UNSUPPORTED`, and a send keeps the device open
  and retryable until its posting deadline. The SDK does not fall back to
  version 1. The Relay serves version 1 for at least 180 days after the
  publish of this release, and the earliest end date is 2027-04-30.
  See step 19.
- `HostedRelayUpgradeRequiredError` names the protocol version that the
  client sent, and its constructor takes an optional `version`. Without it,
  the message names version 1, as in SDK 13.4.
- A retry request now has a posting deadline 24 hours after the first
  failure of its message, and no post of it starts at or after that time. A
  request whose post is due then ends with the new terminal class
  `posting-deadline`. SDK 13.4 posted a replacement request after
  `OPERATION_EXPIRED`. The SDK now ends that request as `posting-deadline`
  with acceptance unknown, because the request might have arrived, and posts
  no replacement. Each `posting-deadline` end resets the session and reports
  one `onRetryTerminal` event. After its posting deadline, a request whose
  post the Relay accepted posts nothing more and waits for its content until
  its 14-day deadline. A request that SDK 13.4 stored gets a posting deadline
  from its first failure, and at most its deadline. SDK 13.4 reads a stored
  `posting-deadline` record as corrupt, so do not downgrade after one exists.
- A retry request that gets `DELIVERY_ALREADY_ACCEPTED` from a version 2
  Relay reads it as the acceptance of its stored attempt, as it reads
  `RETRY_CONFLICT`. No replacement attempt posts.
- SDK 13.4 never replayed a send by itself. The application had to call
  `send()` again with the same `clientMessageId`. That call is still safe, and
  the SDK runs it after its own replay of the same send.

### Deprecated

Each entry names a change in the next major SDK version. Nothing in this
release changes for these items. The upgrade steps below say what to do now.

- Group content with no group context. The next major no longer decides it,
  so content from an SDK 11 sender is not delivered. The denial reason
  `legacy-no-context` then applies to all such content. See step 13.
- `ReceivedContent`. The next major removes the type and the first-open
  conversion of SDK 11 received-content rows. See step 14.
- `SignalProtocolContentAdapter`. The next major adds the required method
  `serializeGroupKeySync`, and `ParsedSyncContent.type` gets `groupKeySync`.
  See step 15.
- The retry terminal class `expired-content`. The next major renames it to
  `request-expired`. See step 16.
- A repeated send timestamp of one device. The next major makes each send
  timestamp unique per sender device, and refuses a new send that repeats the
  timestamp of a different send of the device with `InvalidSendTimestampError`.
  A retry with the same `clientMessageId` keeps its timestamp. See step 17.
- `ReceiveWorkRecord.received.contentDigest` and
  `ReceiveWorkRecord.received.senderDeviceId`, the fields of the received
  message key, and the rule that two different messages of one sender device
  with one timestamp both deliver. The next major keys a received message by its
  sender and timestamp only, and drops a later message with the same key.
  See step 18.

### Fixed

- The SDK reports a Signal Protocol Relay environment mismatch only for HTTP403
  with the `SCOPE_MISMATCH` error code. Other403 responses use the generic
  connection error.
- When a request envelope comes again, the SDK now gives `storeResendJob`
  the first `createdAt` of the group resend job. SDK 13.4 gave it the time
  of the new delivery. The built-in stores keep the first value, as the
  store contract states, so their one-day end of the job did not move. A
  custom store that stored the given value restarted that day on each
  repeated request, so the job could stay alive past one day.
- A binary send now has one upload and one serialized attachment message for
  each `clientMessageId`, across lost Relay replies and restarts. This
  applies to direct and group sends. The stored intent keeps the message and
  the digest of the file. A repeat sends the stored message under the stored
  timestamp and uploads nothing. A repeat of a completed send returns the
  stored result, with `storageId`, `aesKey`, `segmentSize`, `digest` and
  `contentType`. SDK 13.4 uploaded the file again on each repeat, and the
  repeat then failed with `A clientMessageId cannot identify two different
  logical sends`.
- A binary repeat with another file, other pointer metadata, another
  recipient or another explicit `timestamp` now throws that error before any
  upload. The pointer metadata comes from the send options: `mimeType`,
  `caption`, `fileName`, `isViewOnce`, `flags`, `blurHash`, `thumbnail`,
  `width`, `height`, `durationMs`, `waveform`, `clientUuid` and `cdnNumber`.
  A repeat that omits `clientUuid` keeps the stored one. A group recipient in
  place of a direct recipient, or the reverse, is another recipient. A repeat
  of an intent that has no stored attachment message also throws it before
  any upload. This includes a text send and a binary send that SDK 13.4
  stored.
- A binary send without a caller `timestamp` now reads the SDK clock once,
  before the upload. The attachment message and the stored intent get the
  same timestamp. SDK 13.4 read the clock after the upload, once for the
  message and again for the intent, so the two timestamps could differ.

### Limits

- A replay or a resend after `SendAcceptanceUnknownError` can add one charged
  unit within 24 hours, when the Relay no longer holds its record of the first
  acceptance.

#### Upgrade steps

1. Catch `SendAcceptanceUnknownError`. Tell the user that the message might
   already have arrived, and do not replay the send.
2. Catch `SendNeverAcceptedByRelayError`, and also any send error with
   `refusedDevices`. Tell the user which devices did not get the message.
3. For another send error, read `deadlineAt`. With a store that implements
   `listMetadataKeys`, the SDK replays the send until then and reports its end
   once through `onSendOutcome`. Do not build your own replay loop. Without
   that method, replay with the same `clientMessageId` before `deadlineAt`, as
   step 11 says. A call of `send()` with the same `clientMessageId` is safe.
4. Code written for SDK 13.4 compiles unchanged. Check any code that reads
   `retryable` on a send error, and any code that sends with a timestamp
   close to 24 hours old.
5. A custom metadata store needs no change to keep working. The new record and
   intent fields travel inside the stored JSON value. A store that also
   implements the optional `listMetadataKeys` gets the automatic send driver.
   See step 11.
6. A direct send that first stores a message now resolves on `RETRY_CONFLICT`
   when no repair changed it. Other `RETRY_CONFLICT` errors now carry
   `retryable` and `deadlineAt`, so follow step 3 for them.
7. Code that reads `messageId` from a send result must accept the
   `clientMessageId` in that field. That occurs only when every accepted
   device answered `RETRY_CONFLICT`.
8. A device that downgrades to SDK 13.4 ignores the new record fields. It
   can then encrypt one expired retry-resend attempt again, as SDK 13.4 does.
9. Handle the new `posting-deadline` class in `onRetryTerminal`. The session
   resets, and the request might have arrived. Do not downgrade below this
   release after it ends a retry request as `posting-deadline`: an older SDK
   reads that record as corrupt. A 13.4 record that is due, already past
   its derived posting deadline, and not yet past its deadline ends right
   after the upgrade as `posting-deadline`, with a session reset.
10. Handle `SendAcceptanceUnknownError` and `SendNeverAcceptedByRelayError` on
    group sends too.
11. A custom metadata store can implement the optional `listMetadataKeys` to
    get the automatic send driver. Run the store conformance suite to check it.
    The suite skips its listing cases on a store without the method. Without
    the method, the SDK does not replay open sends by itself, and it logs one
    line at each client start. Replay with the same `clientMessageId` before
    `deadlineAt`. `onSendOutcome` still reports each end of a send that your
    application posts.
12. Read `outcome` on `DeviceSetReconciliationError`. When it is set, a call
    of `send()` with the same `clientMessageId` posts nothing and throws the
    error of the stored end. To post a message again after a send end, call
    `resendMessage`. The Relay can charge the resend as a new message. Only a
    send younger than 30 days takes a new resend. At or after 30 days,
    `resendMessage` throws `Only a send younger than 30 days takes a manual
    resend` and posts nothing. The receive queue drops the copy when the
    content adapter reads a timestamp from the content. The
    recipient records the message with the completion of its receive record,
    or, when a receipt is due, right after the receipt-due write and again
    with the completion of the receipt. The caller-origin receive path gives
    every decrypted message to the caller, and a caller that keeps its own
    records removes a copy itself. A recipient on an SDK version before this
    release does not drop the resend copy, so it can show the message twice.
13. Move every client that sends to a managed group to SDK 12.0.0 or later
    before the next major. SDK 12.0.0 and later put the group context in group
    content. The next major no longer decides group content that has no group
    context, so content from an SDK 11 sender is not delivered.
14. Open each durable store once on SDK 13.x before the next major. The open
    converts the SDK 11 received-content rows to receive records. The next
    major does not read or convert them. Stop using the `ReceivedContent` type,
    and use `ReceiveWorkRecord`.
15. If you implement `SignalProtocolContentAdapter` yourself, plan to add the
    method `serializeGroupKeySync` in the next major. If you switch on
    `ParsedSyncContent.type`, plan to handle `'groupKeySync'`. An adapter that
    spreads the result of `createDefaultSignalProtocolContentAdapter()` into
    itself gets the default method. Upgrade every own device of one account in
    one release. An own device on an older SDK version gives the raw group key
    sync to `onMessageDecrypted`.
16. Prepare `onRetryTerminal` for the rename of `expired-content` to
    `request-expired` in the next major. On 13.x, `RetryTerminalClass` does not
    hold `request-expired`, so a `case 'request-expired':` does not compile.
    Keep the `expired-content` branch, and give every exhaustive switch on the
    class a default branch that does not throw. Add the `request-expired` case
    when you upgrade to the major. Do not confuse it with the delivery error
    cause `request-ended`.
17. Give each send of one device its own timestamp. The next major makes the
    timestamp unique per sender device. A new send with a timestamp that a
    different send of the device used throws `InvalidSendTimestampError`. A
    retry with the same `clientMessageId` keeps its timestamp. For a
    `DataMessage` send, match delivery receipts with the returned
    `SendResult.clientTimestamp`. For other content, keep the
    `SendOptions.timestamp` that you supply.
18. Do not rely on two messages of one sender with one timestamp both
    delivering. Two different messages of one sender device with one timestamp
    both deliver in 13.x. In the next major, a recipient keeps the first such
    message and drops a later one with no notice, also when another device of
    the sender sent it. A custom store that checks or stores
    `ReceiveWorkRecord.received` must accept a key with no `contentDigest` and
    no `senderDeviceId`.
19. This release sends Relay protocol version 2. The Relay serves version 1
    for at least 180 days after the publish of this release, and the earliest
    end date is 2027-04-30. After that date, the Relay can stop
    serving version 1, and SDK 13.4 and earlier stop. From SDK 10.1.0, an
    HTTP call then throws `HostedRelayUpgradeRequiredError`, and the mailbox
    subscription stops with the connection reason `upgrade-required`. Move
    every client to this release or later before that date.

## 13.4.0

### Added

- `resumeHostedSignalProtocolClient()` from the root and `client` exports.
  It requires the permanent identity keys, device key and scoped session already
  held by the open store. It renews the device token and runs normal prekey
  maintenance and client startup. It never requests an assertion or falls back
  to registration, recovery or linking.
- `HostedRelayResumeError` reports a strict resume refusal with a code and phase.
  When startup cleanup has not completed, `cleanupPending` keeps the actual
  client stop handle. `retryCleanup()` retries that stop, without retrying resume
  or closing the caller's store. The original failure remains the cause.

### Documentation

- The hosted identity recipe now links to the supported account suspension
  procedure.

## 13.3.0

### Added

- `InvalidSendTimestampError`, with the code `INVALID_SEND_TIMESTAMP`, from
  `@open-e2ee/signal-protocol-sdk/types`. A new send now checks a `timestamp`
  that the application supplies, in `SendOptions` or in `DataMessageInput`,
  against the SDK clock. The value must be a safe positive integer, at most
  5 minutes ahead of the clock and at most 24 hours behind it. From the Relay
  release that follows v2026.10.25, the Relay admits a mailbox delivery epoch
  and a new group fan-out operation in the same window. Earlier Relay
  releases admit a new operation only within 5 minutes of its epoch. On an
  earlier Relay release, a time 5 minutes to 24 hours old passes the SDK check
  but gets `OPERATION_EXPIRED`. The SDK check uses the same bounds, so the SDK
  refuses an application-supplied time before any post. Before, a value
  outside the window made every post of the send fail at the Relay. Now the
  send throws the error
  before the profile key work of a hosted client, before the daily send-log
  sweep, and before it stores the send intent or posts anything. An
  attachment send checks its timestamp once, so a slow upload does not make
  a later check refuse it. `syncMediaAttachmentDeleteToLinkedDevices`,
  `syncRecipientUsernameToLinkedDevices`,
  `syncVerificationStateToLinkedDevices`,
  `syncTaskNotificationAckToLinkedDevices`, and
  `syncBlockedRecipientsToLinkedDevices` use their `deletedAt`, `learnedAt`,
  `changedAt`, `acknowledgedAt`, and `syncedAt` time as the epoch of the
  sync, and now check it in the same window before they post. The error
  gives the refused `timestamp`, the `reason`, and the `earliest` and `latest`
  accepted values. A send that repeats a stored `clientMessageId` with its
  stored timestamp keeps that timestamp, and the SDK does not check it again.
  With another timestamp, the check applies. A send without a `timestamp`
  uses the SDK clock, as before. The SDK test model of the Relay now admits
  an epoch at most 5 minutes ahead and at most 24 hours behind its clock, and
  replays an accepted operation for 24 hours, as the Relay does from the
  release that follows v2026.10.25.

### Fixed

- Web SQLite database names now permit up to 224 UTF-8 bytes with the same
  ASCII syntax. The budget reserves the directory prefix and conversion
  ending within a 255-byte directory component and fits the engine's path
  header. Before, the worker imposed a 64-character limit and plaintext
  conversion needed at most 51 characters. Open and reset now reject invalid
  names before any lock, vault, worker, or OPFS access. Oversized inputs fail
  before encoding, and other inputs use a fixed-size encoding buffer.

  Existing accepted names keep the same storage and key locations.
- A resend or a null message now answers a retry request only when it comes
  from the account and the device that the request asked. The retry ID of the
  request does not prove the sender, because the Relay sees it. So a message
  from another device of the sender, or from another account, that carries
  the retry ID is now an ordinary message. It does not mark the request
  answered, and it does not end the request. Before, such a message could end
  the request with `onDeliveryRecovered`, so the lost content was not
  reported. Now the request stays open until its real answer arrives, or
  until its deadline ends it with `onRetryTerminal`. For a sealed message, the sender inside the
  seal is the sender that counts.
- A message that arrives under the ID of a message that failed to decrypt now
  ends the retry request of that ID only when it is the same envelope from the
  same sender: the bytes that the request recorded, and the device that sent
  the failed message. The Relay names the envelope ID, so it can give that ID
  to another message. Before, any message under that ID that decrypted ended
  the request, also with the retry ID of a resend on it, and
  `onDeliveryRecovered` named the failed message. Now such a message is an
  ordinary message, and the request stays open until its real answer arrives,
  or until its deadline ends it with `onRetryTerminal`.
- `IndexedDbSignalProtocolSecretVault` now opens an IndexedDB connection for
  each request and closes it when the request settles. Before, each vault
  kept its connection open for the life of the page, and `webSqliteStore()`
  makes a new default vault for each open. So a page that opened the store
  again, such as after a sign-out or an `OPFS_FILE_BUSY` retry, kept one more
  connection alive for each open. The vault API does not change.

## 13.2.0

### Added

- `HostedRelayWakeResult` has an optional `retainedWork` field. It copies the
  Relay report of the wake pull. True means that the Relay keeps a message
  after the page, or a Relay receipt that the page did not carry, so run
  another `pullHostedRelayAfterWake()` pass. False means that the page carried
  all retained work. A Relay that does not report it gives no field. Then the
  retained work is unknown, so do not read an absent field as false.

### Fixed

- A hosted mailbox subscription now acknowledges each recovery pull page in
  one HTTP request, also while the socket is live, and waits for the response.
  When the page was full, with 100 messages or 32 Relay receipts, and the
  Relay removed work or issued a cursor, the next page follows at once. It
  does not wait for a timer. So a backlog of Relay receipts drains on the same
  socket, with no reconnect. A socket frame never starts a pull.
- A lost acknowledgment request or a lost acknowledgment response now starts
  one pull from the mailbox head after a wait. The wait starts at 2 seconds
  and doubles after each further loss, up to 64 seconds. An acknowledgment
  whose requests all succeed starts it at 2 seconds again. A pull that is
  requested while the acknowledgment fails waits for that head pull. So a
  lasting acknowledgment failure backs off. A replayed Relay receipt is not
  handed off again.
- A subscription now keeps at most 132 Relay receipts in memory while a
  receipt listener is slow. One batch takes at most 32 receipts. When the
  queue of 100 items is full, the rest stay in the Relay, and the subscription
  pulls them when the queue is empty, with no wait.
- A pull page now decodes the optional `failedEntries` list of the Relay. It
  holds each retained message that the Relay read and could not serve. The
  subscription never acknowledges such a message. It pulls again from the
  mailbox head after the failed-work wait, which starts at 2 seconds and
  doubles up to 64 seconds. A page pulled with a cursor does not start that
  wait again, so a long backlog does not cut the wait short. A page with a
  `failedEntries` value that is not a list of entries is refused. A page that
  holds only failed entries keeps its `nextCursor`, so the subscription and
  `pullHostedRelayAfterWake()` continue past it with the cursor. The
  subscription pulls such cursor pages to their end before the pull from the
  head. It does not continue on a `nextCursor` that equals the cursor of the
  pull.
- A recovery pull page whose `retainedWork` is true now continues at once
  when the Relay removed work or issued a cursor, also when the page is not
  full. A page without `retainedWork` uses the full-page rule.
- A subscription now keeps at most one HTTP acknowledgment in flight, and a
  pull waits for its response. When a socket burst ends and a pull follows,
  the Relay receipts of the burst are acknowledged over HTTP before the pull.
  So the pull page does not offer those receipts again, and the next pages
  follow.
- A pull that a subscription requests while a pull fails now waits for the
  retry schedule of the failed pull. It does not run at once after the
  failure.

## 13.1.0

### Added

- `linkHostedRelayDevice` now supplies the authenticated Signal Protocol Relay
  transport when `hosted.adapter` is absent. Custom adapters keep their path.
  Exact retries preserve registration material and linked prekey state. Token
  renewal rebuilds both device proofs without another provider assertion.

## 13.0.0

### Breaking

- **A linked store that holds group state is refused.**
  `linkHostedRelayDevice` lists the linked device's group store before any
  write. When the store lists a group that the link did not write, the call
  throws `HostedRelayDeviceLinkError` with code `DEVICE_LINK_STORE_NOT_EMPTY`.
  The linked device's group store is `groups.store`, or the SDK group store on
  the linked store. Link the device again with a new, empty store.
- **A custom identity store must accept an overwrite of its own identity
  record.** `linkHostedRelayDevice` gives the linked device its own
  registration ID with the same identity keys. It calls `storeIdentityKey` and
  then `setLocalRegistrationId` for an identity type that the linked store
  already holds. After both calls, both reads of that type must give the new
  ID, and the other identity type must stay unchanged. Every store that the SDK
  ships does this. A custom `SignalProtocolLocalStore` must pass this check:

  <!-- doc-snippet:skip requires-external-context -->
  ```ts
  const identity = await store.getIdentityKey('aci');
  await store.storeIdentityKey({ ...identity!, registrationId: 4321 }, 'aci');
  await store.setLocalRegistrationId(4321, 'aci');
  (await store.getIdentityKey('aci'))!.registrationId; // 4321
  await store.getLocalRegistrationId('aci'); // 4321
  ```

- **A SQLite store name that ends in `.oe2e-convert` is refused.** The
  conversion uses that name for its temporary file. `nodeStore`, `expoStore`,
  `reactNativeStore`, `webSqliteStore`, and their resets fail with
  `INVALID_STATE` for such a name.

### Added

- **`getGroupInitStatus` and the `onGroupInitStatus` hook.**
  `DefaultSignalProtocolClient.getGroupInitStatus(groupId)` gives the
  `GroupInitStatus` of a group on this device: `'ready'`, `'stale'`,
  `'pending'`, `'no-key'`, or `'denied'`. It gives null when the device has no
  record of the group. `'no-key'` means that the device knows the group but
  holds no group key. `onGroupInitStatus(groupId, status)` runs when a client
  write to the record of a group changes its status. It does not run when the
  status stays the same.
- **`activeGroupStore` in `HostedRelayManagedDeviceLinkOptions`.** It is the
  group store that the link copies from. The default is the SDK group store on
  `activeDeviceStorage`. If a client runs on the active device during the
  link, pass that client's group store, or stop that client first.
- **Progress phase `'copying'` for `'device-link'`.** `linkHostedRelayDevice`
  reports it before it copies the group master keys.

- **SQLite stores accept `convertPlaintext: true`.** An encrypted open then
  converts a database that `encryptionAtRest: false` created, and keeps every
  row and its schema version. The removal of the plaintext file is the commit
  point. A crash before it keeps the plaintext file, and a crash after it
  leaves a store that the next encrypted open finishes. Each store guide has a
  "Convert a plaintext store" section.

- **`HostedRelayHttpError` is exported from the root entry and the `client`
  entry.** A custom `HostedRelayManagedDeviceLinkAdapter` can throw it when
  the Relay refuses the link. Give it the Relay's status, `code`, message,
  and `retryable`. A refusal with `retryable` false and the code
  `KEY_PROOF_INVALID` or `CONFLICT` then rolls the link back. The
  `linkHostedRelayDevice` call keeps the link state for an error of any other
  class, also when the error has the same `code`.

- **Added: the local/store/conformance subpath exports runLocalStoreConformance and assertLocalStoreConformance.** A custom local store can check identity overwrite, atomic commits, compare-and-set, receive work, durability, and its protection declaration.

### Changed

- **The link copies each group master key.** `linkHostedRelayDevice` copies
  the master key of each group that the active device's group store lists into
  the linked device's group store, in the calling process. No master key
  crosses the Relay. A client with `groups` on the linked device then fetches
  each copied group, so the application no longer brings each master key and
  calls `syncGroup()`. A group record that a release before 12.0.0 wrote, and
  that the active device has not read since, is not copied. Read each group
  once on the active device before the link to copy it. A link that stops
  during the copy copies again on the next call. A link that the Relay refuses
  removes its copied groups.

- **The SQLite key mismatch error names `convertPlaintext`.** An encrypted open
  of a plaintext file fails with `SqliteKeyMismatchError`, and its message
  gives the option as a way to keep the data.
- **An open or a reset with `encryptionAtRest: false` refuses an incomplete
  conversion.** While the temporary file of a conversion exists, it fails with
  `INVALID_STATE` and changes nothing.
- **Each linked device gets its own registration ID.** `linkHostedRelayDevice`
  writes a fresh registration ID into the linked store before it registers.
  The ID differs from the ID of the active device. A held PNI record gets a
  separate fresh ID. A device that a 12.0.x release linked keeps the ID that it
  has. A link that a 12.0.x release began and that stopped before it completed
  keeps its stored ID, so it registers the same device.
- **A linked store with a device-authentication key and no registration of the
  link is refused.** `linkHostedRelayDevice` throws
  `HostedRelayDeviceLinkError` with code `DEVICE_LINK_STORE_NOT_EMPTY` before
  any write. Link the device again with a new, empty store.
- **A refused link rolls back.** When the Relay refuses a link with
  `KEY_PROOF_INVALID` or `CONFLICT` and the refusal is not retryable, the call
  removes the link state and rethrows. It keeps the identity records and the
  registration, so the next call sends the same registration ID. Every other
  error keeps the link state, and the next call resumes the link.

### Fixed

- **Hosted identity docs.** The quickstart and API reference describe both
  Production modes: application-bound and device-owned.
  `hostedRelaySandboxIdentity` remains limited to Sandbox. The key-label note
  states the session interoperability limit.

- **A link whose first sync fails rejects and can resume.**
  `linkHostedRelayDevice` stops the client and rejects with
  `OpenE2EE Signal Protocol Relay initial synchronization failed` when the
  client's first sync fails. In 12.0.1 and earlier, it returned the client with
  `syncStatus` `'failed'`. The next call with the same stores resumes the link
  and gets the same device.

- **Fixed: removing a web SQLite file also removes its OPFS pool directory.**

- **A received message gets one delivery receipt.** When the Relay accepted
  or refused a delivery receipt, the receive queue completed its record
  outside the queue's passes. A pass that read the record before that
  completion could put the receipt in the batch again after it. In 12.0.1
  and earlier, the sender could then get a second delivery receipt for the
  same message. The completion now runs between passes.

- **Fixed: the web SQLite store retries a transient OPFS failure of its
  open.** WebKit can reject an access handle with `UnknownError` under load,
  and the store then rejected the open with `OPFS_FILE_BUSY`. Now the store
  attaches the pool of the file again, up to four attempts, 100 ms apart. It
  retries only before the first statement of the request, so the file stays
  unchanged. It does not retry a full quota or any other error. After the
  fourth attempt the store rejects with `OPFS_FILE_BUSY` as before.

## 12.0.1

- **Fixed: a web SQLite store restores the last commit after a tab died inside a
  commit.** The `opfs-sahpool` VFS of the vendored engine reported a reserved
  lock on every check. SQLite then took the hot journal that a tab killed
  inside a commit left for the journal of a live transaction and never played
  it back, so the next open read the half-written commit. In 12.0.0 and
  earlier, such a store could report `database disk image is malformed`. The
  patched engine reports no reserved lock, and the next open of such a store
  plays the journal back.

- **Fixed: a web SQLite open with the wrong key state leaves the file as it was.**
  The open reads the first page of the file through an immutable read-only
  connection with no key before it opens the file. An open with no key of an
  encrypted file, or an open with a key of a plaintext file, rejects with
  `file is not a database` and plays no hot journal back. In 12.0.0 and
  earlier, such an open of a file with a hot journal played the journal back
  through the wrong key state and left the file corrupt.

- **Fixed: `ratchetConfig.maxSkip` sets the skip limit.** The client passes
  `SignalProtocolClientConfig.ratchetConfig.maxSkip` to the session cipher of
  the protocol manager that it creates. In 12.0.0 and earlier, the client did
  not read the option. A gap above the limit fails with
  `TOO_MANY_SKIPPED_MESSAGES`. The default is 25000, which is the value that
  the cipher used before. The API reference said 1000 and now says 25000. A
  value that is not a positive integer fails at client creation with
  `ratchetConfig.maxSkip must be a positive integer.` A `protocolManager` that
  the caller supplies keeps its own limit. The client does not read
  `maxMessageKeysStored` or `keyExpirationMs`. Their reference now states the
  fixed values: 2000 skipped message keys per receiver chain, deleted after 7
  days.


## 12.0.0

- **Breaking: every new session uses PQXDH, and the SDK has no classical key
  agreement.** A peer bundle without an ML-KEM prekey fails with
  `PQXDH_REQUIRED`, and no setting allows a classical X3DH session.
  `'required'` is the only `postQuantum` value. `PostQuantumPolicy.Compatible`
  and the `'compatible'` value are removed, and `postQuantum: 'compatible'`
  throws `Unsupported postQuantum policy` at client creation.
  `ProtocolStrategyConfig.allowClassicalFallback` is removed, and the SDK
  ignores the key from an untyped caller. `ClassicalFallbackReason` is removed
  from `./client/config` and `./types`. `ProtocolSelectionEvent` no longer
  carries `usedClassicalFallback` or `classicalFallbackReason`.
  `X3DH_INFO_DEFAULT` is removed from `./client/config` and `./types`, and
  `ResolvedKeyExchangeInfoStrings` carries only `pqxdh`. `PQXDHFallbackType`,
  `PQXDHRequiredErrorOptions.fallbackType`, and `PQXDHRequiredError.fallbackType`
  are removed; read `PQXDHRequiredError.reason` (`no_kyber_prekey` or
  `pqxdh_failed`) instead. The X3DH module and its `performX3DH`,
  `performX3DHResponder`, `calculateX3DHSharedSecret`, `EphemeralKeyPair`,
  `X3DHResult`, `X3DHResponderInput`, and `X3DHResponderResult` exports are
  removed. `validateProtocolStrategy` no
  longer warns about a classical fallback. A stored 11.x classical session
  continues as a Double Ratchet session.
- **Breaking: the managed device link is the one link path.** The SDK no
  longer ships the device provisioning protocol. `linkHostedRelayDevice()` is
  the one way to link a device. A linked device gets the account identity by
  device transfer or by an application-owned channel. The managed device link
  runs in one process that holds the active device's store and the new
  device's store. It sends no private key to the Relay. These public names
  are removed: the `./device/provisioning` subpath and its exports
  `DEFAULT_PROVISIONING_LINK_PREFIX`, `LocalDeviceMetadata`,
  `ProvisioningGroupStateStore`, `ProvisioningIdentityStore`,
  `ProvisioningKeyPair`, `ProvisioningLocalStateStore`, `ProvisioningMessage`,
  `ProvisioningQRData`, `ProvisioningReceiveOptions`, `ProvisioningSendOptions`,
  `ProvisioningUsernameStateStore`, `UserProfile`, `cancelProvisioning`,
  `connectToProvisioningSession`, `generateProvisioningQR`,
  `parseProvisioningQR`, `provisionDevice` and `receiveProvisioningMessage`,
  with their `./device` re-exports; `PROVISIONING_SESSION_TTL_MS` from
  `./device/constants`; `getDeviceMetadata` from `./device/expo` and
  `./device/react-native`; `ProvisioningService` from `./remote/relay/types`;
  the `SignalProtocolRelayServer` methods `createProvisioningSession`,
  `connectNewDevice`, `sendProvisioningMessage`, `getProvisioningMessage`,
  `completeProvisioning`, `acknowledgeProvisioning`, `rollbackProvisioning` and
  `deleteProvisioningSession`, with their `HostedRelayHttpTransport` members;
  and `DeviceChoice.requiresQR`. A relay adapter drops these methods.
- **Fixed: a blocked head of the mailbox no longer stalls the HTTP pull.**
  A mailbox pull, and so `pullHostedRelayAfterWake`, now sends the Relay
  cursor of the page before it, so the pull moves past a full page of
  unacknowledged envelopes and gives the messages and Relay receipts behind
  it. Three kinds of envelope stay unacknowledged: an envelope that the
  receive bounds refuse, a decrypt failure that no retry request owns, and
  a retry request that waits for the next group fetch. The cursor lives in
  memory only. An empty page, a page without a Relay cursor, a failed pull,
  and a restart clear it, so the next pull starts at the head and offers
  those envelopes again. The recovery pull after failed work also starts at
  the head. Advancing
  the cursor acknowledges nothing, so the Relay keeps each envelope. Before,
  a full page of such envelopes came back on each pull, and the messages
  behind it waited.
- **Changed: hosted registration and recovery accept a native assertion with
  no `jti`.** The transport binds the challenge to the exact assertion,
  purpose, and operation ID. The Relay verifies the configured provider and
  rejects an invalid token. An assertion with a valid `jti` keeps that
  identifier.
- **Breaking: a send declares its device sets, and the Relay compares
  them.** Each post to an account declares the device IDs that the sender
  holds records for. `Envelope.declaredDeviceIds` carries the declaration of
  a direct post, and the hosted transport sends it as `deviceSets`.
  `SignalProtocolRelayServer.sendMultiRecipientUnidentified` takes a 9th
  argument, `deviceSets`, for a sealed post. The relay `send()` returns the
  optional `deviceSetChecked` and `needsSync`.
  `sendMultiRecipientUnidentified` returns the optional `deviceSetChecked`
  and `refusals`. The Relay refuses a declaration that does not match with
  409 `DEVICE_SET_MISMATCH`, which names the missing and the extra devices,
  or with 410 `STALE_DEVICE`, which names the devices whose registration
  changed. The SDK then removes each extra device record, starts a new
  session with each missing or stale device, encrypts the message again only
  for those devices, and posts again. The hosted transport finds each device
  in the device directory before it posts, on the identified and on the
  sealed route. A declared post to a device that the directory does not list
  fails before the post with the 409 `DEVICE_SET_MISMATCH` refusal of the
  Relay, which names the device as extra, so the SDK removes the device
  record and posts again. A device that the Relay accepted keeps
  its stored post. A send has a recipient phase and then a sync phase, and
  each phase can restart 10 times. When the recipient phase does not match
  after the 10th restart, or the Relay refuses a restart post with
  `OPERATION_EXPIRED`, the send throws the new
  `DeviceSetReconciliationError`. The outbox keeps the send as terminal, and
  a call of `send()` with the same `clientMessageId` starts a new run at 0
  restarts. A group restart keeps the group ciphertext, seals the shared body
  again, and replaces it in one write. A device-specific resend, a receipt,
  and a retry request declare nothing. A custom relay and a wrapper of a
  relay do not compare, get no declaration, and keep the device list reads. `docs/DEVIATIONS.md` sections 5.5 and 5.6 compare this
  loop with Signal's.
- **Breaking: a send to a recipient with a session reads no device list on a
  comparing relay.** The Relay refuses a declared post that misses a device
  or names a removed one, so the 60 s freshness window applies only to a
  relay that does not compare. A recipient with no session gets one list
  read to start the sessions. A group send declares the devices of its
  records, and reads the list of a member only when it holds no record for
  that member. A replay reads no device list. One exception holds in a live
  send and in a replay. A repair that leaves an account with no device
  record reads the list of that account once.
- **Breaking: the own device list is read only on `needsSync`.** On a
  comparing relay, the recipient phase posts first. Its receipt sets
  `needsSync` when the sender account has other devices. The sync phase then
  declares the own devices that the sender holds records for. When the
  sender holds no record of another own device, the send reads the own list
  once. A failed read no longer fails the send. The recipient result is
  stored first, and the result carries `syncPending: true` when the sync
  phase does not complete or the own list cannot be read. Call `send()`
  again with the same `clientMessageId` to post the pending copies. A replay
  reads the own list again when the send could not read it. The SDK makes no
  sync post without a destination.
- **Breaking: a custom store keeps the device-set fields of an outgoing
  intent.** An outgoing intent adds `deviceSetRestarts`,
  `deviceSetUnresolved`, `deviceSetBundleMissing`, and `syncPending`. A
  custom metadata store must keep each field of the stored intent value,
  also a field that it does not know.
  The fields need no schema step, because they live in the existing JSON
  value of the intent.
- **Breaking: a refused group-token destination is no longer inferred as
  stale.** The group-token receipt names each refused destination with its
  code in `refusals`. A `STALE_DEVICE` destination leaves the shared group
  message and gets the device repair once. A `NOT_FOUND` destination of a
  declared post settles a removed account: the SDK adds nothing for it, and
  `uuids404` names the account only when the receipt is not a duplicate.
  `SendResult.refusedDestinationCount` stays a count, and the SDK infers no
  code from it.
- **Breaking: a repair fails the send on a session error other than a
  missing bundle.** When the start of a new session for a refused device
  fails for another reason, such as an untrusted identity, the send fails
  with that error. A listed device with no prekey bundle makes the send wait
  and restart, and counts each restart. The repair write stores each such
  device in the outbox. A replay after a process restart, a stop, or a
  terminal end starts a session with each stored device before its first
  post, so the device gets the message when it has a bundle again. When the
  send holds no message for an account, a bundle fetch that the Relay
  answers with `NOT_FOUND` removes the record of the device. The Relay gives
  that answer for an unregistered device, and for a registered device with
  no uploaded prekeys. Each other device that the account record holds gets
  the message in the same repair when it has a session or a bundle. An
  account left with no device record gets one list read, and a listed device
  with no bundle waits again within the restart bound. Thus a replay reaches a device that the account linked
  after an unlink. Before, a replay of a send whose recipient had no other
  device failed with `SESSION_NOT_FOUND`, and a group replay completed
  without the member.
- **Added: `SendResult.syncPending`.** It is true when the Relay accepted
  the send for every recipient device and the copies for the other devices
  of the own account are not posted yet.
- **Added: the `onRelayProtocolError` hook and `RelayProtocolError`.** The
  Relay marks each accepted declared post with `deviceSetChecked`. When an
  accepted declared post has no mark, the send is delivered and its result
  does not change. The client reports a `RelayProtocolError` with the code
  `DEVICE_SET_UNCHECKED` and the route of the post once for the send through
  `onRelayProtocolError`. A sync copy to another own device is a declared
  post too, on the `identified-direct` route. A sync payload of a method such
  as `syncReadToLinkedDevices` reports its error once with no
  `clientMessageId`. The new exported types are
  `DeviceSetReconciliationError`, `RelayProtocolError`, `DeviceSetDevice`,
  `DeviceSetLastRefusal`, `DeviceSetPhase`, `DeviceSetRefusalAccount`,
  `DeviceSetUnresolved`, `DeviceSetUnresolvedReason`,
  `RelayProtocolErrorCode`, and `RelayProtocolRoute`.
- **Added: `HostedAnonymousDeliveryError.data`.** The error keeps the
  `details` object of the Relay answer. For a refused declared post, it
  names the missing, the extra, or the stale devices.
- **Breaking: the skipped-key cap applies to each receiver chain.** A
  receiver chain keeps at most `maxMessageKeysStored` skipped message keys,
  2000 by default, as libsignal keeps `MAX_MESSAGE_KEYS` for each chain. When
  a chain is at the cap, its key with the lowest index leaves. A store to one
  chain never evicts a key of another chain. Before this change, the cap
  applied to all five chains together, and the oldest key of any chain left.
  A session now keeps up to 2000 keys in each of its five chains. The 7-day
  `maxMessageKeyAge` limit does not change. `countTotalMessageKeys` and
  `evictOldestMessageKey` are removed from the double-ratchet exports.
- **Breaking: a receive pass waits for each hook for at most 2 minutes.**
  The new `protocol.receiveQueue.receiveHookTimeoutMs` option sets the
  bound. The default is 120000 ms. The value must be a positive integer of
  at most 2147483647 ms, so `create()` refuses zero, a negative value, a
  fraction, and `Infinity`. The bound applies to each hook that a receive
  pass awaits. At the bound, the SDK logs a warning with the
  `RECEIVE_HOOK_TIMEOUT` behavior and no longer waits for the hook. A
  timeout of `onMessageDecrypted` or `onDelivered` counts as one failed hook
  attempt, with the normal backoff and attempt cap, and it logs no
  `RECEIVE_HOOK_FAILED` warning. A timeout of another hook ends that call,
  and the pass continues. A hook that settles after its bound writes
  nothing. An application whose hook can run longer than 2 minutes sets a
  larger bound.
- **Breaking: a delivery receipt stops its retries 1 day after it becomes
  due.** One Signal client gives its delivery receipt job the same 1-day
  lifespan.
  When a receive record waits for its delivery receipt for 1 day,
  the SDK completes the record. It sends no receipt, it does not call
  `onMessageDecrypted` again, and it gives no `onReceiveExpired` report,
  because the application already has the content. A resend record still
  reports `onDeliveryRecovered`. The 30-day receive age still applies, so a
  record whose age ends first completes at its age. Before this change, a
  receipt retried until the receive age of 30 days.
- **Breaking: SPQR skipped keys leave by index distance in each epoch, not
  by age.** The SPQR receive path now keeps held skipped keys as the
  SparsePostQuantumRatchet chain keeps its key history. Each epoch keeps at
  most `maxOutOfOrderKeys` keys after a trim, 2000 by default. A key whose
  index plus `maxOutOfOrderKeys` is below the receive counter of its epoch
  is refused with `DECRYPTION_FAILED` and the reason `key-trimmed`. A
  receive holds only the skipped keys at or above its own horizon. A jump
  above `maxOutOfOrderKeys` clears the held keys of that epoch. When an epoch
  holds 2201 keys, the keys behind the horizon leave. No eviction reads the
  clock, and the `timestamp` field stays in the persisted shape. When the
  send epoch prunes an old epoch, the held keys of that epoch leave with its
  chains, so a key of a pruned epoch no longer decrypts. Before this change,
  the trim ran only when all epochs together held 2000 keys, and one receive
  then added every key of its gap, up to 24999 keys. The internal
  `deserializeSPQRState` loader refused a state above 2000 keys. It now
  keeps the highest 2200 indexes of each epoch, drops the keys of an epoch
  with no chain, and logs one warning with the dropped count. The
  `cleanupSPQRState` export and `SPQR_CONFIG.MAX_SKIPPED_KEY_AGE` are
  removed from the SPQR module for the 12.0.0 cut, because no receive path
  called them. `trimSkippedKeys` is replaced by
  `trimEpochSkippedKeys(state, epoch)`.
- **Breaking: safety numbers order the two parties as libsignal does.**
  Each party gets its own 30-digit display string. The string that is lower
  by byte comparison comes first, in the 60 digits, the emoji, and the hex.
  The SDK no longer compares the two user identifiers, so no locale and no
  identifier character can change the order. For some identifier pairs, the
  displayed safety number of 12.0.0 differs from the one of 11.x. The 30
  digits of each party do not change, and only their order changes. This
  applies to `client.verify()` and `generateCompositeSafetyNumber`, and also
  to `generateSingleKeyReferenceSafetyNumber`, `Fingerprint`, and
  `createFingerprintData`. The composite QR profile version steps from 3 to
  4 for the 12.0.0 cut. A QR code from an 11.x client then reports
  `version_mismatch`, not `no_match`. The single-key QR profile stays at
  version 2, because the new order makes its output equal to libsignal
  version 2.
- **Breaking: a safety-number confirmation from an earlier version is
  refused.** `SafetyNumberConfirmation.version` steps from 1 to 2 with the
  composite QR profile step. `confirmSafetyNumber` refuses a version 1
  confirmation with the unsupported-version error, not with
  `IDENTITY_MISMATCH`. The app calls `verify()` again and shows the new safety
  number.
- **Fixed: a cached safety number keeps the QR orientation of its caller.**
  Before, the cache gave the swapped call for the other party the same cached
  result. Its QR code then carried the first caller's orientation, so a scan
  against the other party's QR code reported `no_match`. The cache now keeps
  one entry for each orientation.
- **Fixed: an archived session no longer sends a PreKeyMessage.** When a
  session moves to the archive, the SDK now clears its unacknowledged prekey
  state: the pending flag, the prekey IDs, and the Kyber and KEM one-time
  ciphertexts, as libsignal does. Before, a session that was archived before
  the peer replied kept that state, and a later promotion made its next send
  a PreKeyMessage for prekeys that the peer could already have deleted. The
  in-memory store archive now follows the same record rule, so it also keeps
  at most 40 archived sessions.
- **Changed: archived sessions are evicted by insertion order, not by last
  use.** Over 40 archived sessions, the session that went into the archive
  first leaves, as libsignal does. Before, the session with the oldest
  `lastUsedAt` left. A session archived again under the same base key moves
  to the newest end.
- **Breaking: a removed device keeps its record and its archived sessions.**
  `SesameManager.removeDevice` now archives the current session of the
  device, keeps the record, and marks it removed with the new
  `DeviceRecord.removedAt` field. Before, the removal deleted the record and
  its sessions, so a message that the device sent before its removal did not
  decrypt. Now that message decrypts on the archived session. A removed
  device gets no fan-out: a send, a sync copy, a receipt, and a sender-key
  distribution skip it. A send to a user whose devices are all removed fails
  with `NO_DEVICES`. A second removal of the same device writes nothing and
  emits no second `onDeviceRemoved` event.
- **Changed: a device list that names a removed device again relists it.**
  The removed marker clears, and the device returns to fan-out with no
  current session. The archived sessions stay. The relist emits
  `onDeviceAdded` once. A group send to a removed member device reads its
  device list again before it gives the sender key. A device that is still
  removed after that read gets no key. The new
  `SesameManager.relistDevice` call relists one device.
- **Changed: a declared send counts a removed device record as absent.**
  On a comparing relay, a send declares only the devices whose records are
  not marked removed. A repair that removes an extra device, or a device
  whose bundle fetch the Relay answers with `NOT_FOUND`, marks its record.
  A member or an own account whose every record is marked removed gets the
  list read of an account with no record. A repair that starts a session
  with a missing device relists its record, so the next post declares it.
- **Changed: an identity change keeps the archived sessions.** When a device
  list gives a new identity key for a device, the SDK archives the current
  session, takes the new key, and marks the device pending verification.
  Before, it deleted the record and its sessions and added the device again,
  with an `onDeviceRemoved` and an `onDeviceAdded` event. Now a message under
  the old session still decrypts, and the change emits no device event. A
  removed device whose identity changes is relisted, with one
  `onDeviceAdded` event.
- **Changed: the client deletes stale device records at each start.** The
  receive queue runs `cleanupStaleRecords` once in each run, after its
  resume. A removed record goes when its removal is older than `maxLatency`,
  30 days by default. The cleanup also deletes a record that has no session
  and is older than `maxLatency`. Before, no SDK path ran the cleanup.
- **Breaking: a custom store keeps and deletes removed device records.** A
  `SesameStore` must keep the `removedAt` field of a device record.
  `deleteStaleRecords` must also delete a record for which
  `isExpiredRemovedDevice` is true. `getSesameDeviceIds` still returns the
  removed devices, and a caller that sends to the devices skips them with
  `isRemovedDevice`.
- **Breaking: the SQLite schema moves to version 6 and the IndexedDB database
  to version 11.** Neither step changes a table or an object store. The steps
  keep an earlier SDK, which sends to a removed device, from opening the
  store. An earlier SDK refuses the SQLite file with
  `SqliteSchemaTooNewError`, and the browser refuses the IndexedDB open with
  a `VersionError`. A downgrade is not supported.
- **Added: `isRemovedDevice` and `isExpiredRemovedDevice`.** The two
  predicates are exported from the `types` entry point. `isRemovedDevice`
  tells whether a device record is marked removed. `isExpiredRemovedDevice`
  tells whether the stale-record cleanup deletes a removed record.
- **Changed: a waiting receive record holds back only its conversation.** A
  record that waits for its group state, or for a hook retry below the
  attempt cap, holds back the later records of its conversation, as one
  Signal client queues its message jobs. Group content keys by its group,
  a sent transcript of this account keys by its destination, and other
  content keys by its sender account. Before this change, a waiting record
  held back every later record of its sender device, in every group and in
  direct chats. Now direct chats and other groups make progress, and a
  blocked group holds back its later content from every sender. A record
  that waits behind an earlier record of its group counts toward the share
  of that group in the receive queue, so a stalled group reaches its share
  sooner, and its new sender-key messages wait at the Relay. The order in
  which the device commits its records stays per sender device.
- **Added: `discardPendingReceive` removes a receive that the application
  cannot process.** The call takes the `messageId` that
  `listPendingReceives` gives. It removes a receive that has not reached its
  delivery receipt, and returns the removed receive, or `null` when no
  listed receive matches. It sends no receipt, it does not call
  `onMessageDecrypted`, and it gives no `onReceiveExpired` report. A
  redelivery of the envelope then gives `duplicate` and decrypts nothing.
  A hook call that already started still runs. Each
  `PendingReceive` now gives `hookAttempts`, the count of failed
  `onMessageDecrypted` attempts. Its `messageId` is now always set: a
  receive stored before the client kept message IDs gives its record ID, as
  the `processed` outcome does.
- **Changed: group sends and session locks order the tabs of one origin.**
  When `navigator.locks.request` exists and the store has a
  `storeIdentity`, a group Sender Key operation runs under the Web Lock
  `open-e2ee:group-send:<store identity>:<lock key>`. The session lock, the
  user lock, and the device-list sync lock run under
  `open-e2ee:session:<store identity>:<lock key>`. Two tabs or workers of
  one origin on one store then encrypt in turn, so two group messages never
  carry one iteration and two direct messages never carry one counter.
  Before this change, each tab had only its own in-process lock. A page or
  engine with no Web Locks, and a store with no identity, keeps the
  in-process locks. Two tabs on one store are then not ordered, and the
  application must give one tab exclusive access to the store. The session
  lock and the device-list sync lock still end a wait after 5 seconds. On
  the Web Lock path the wait rejects with `ORIGIN_LOCK_TIMEOUT_MESSAGE`, and
  on the in-process path with the message of the in-process lock. A stop of
  the relay work still ends the wait of a group operation. A Web Lock has no limit on its waiting requests. The
  in-process session lock still refuses a request when 1,000 requests wait.
- **Added: `storeIdentity` on the local store contract.** The optional
  member names the data of a store, so that each tab and worker of an
  origin gives the same name for the same data. The IndexedDB store and the
  web SQLite store give their database names. A
  custom web store that shares its data across tabs sets it, so that its
  sends take the Web Locks.
- **Fixed: a sender-key rotation keeps the states that another client
  wrote.** Each `SenderKeyManager` kept its own copy of the previous
  states, and a rotation or a new distribution built the archive from that
  copy. When two clients on one store rotated in turn, for example in two
  tabs, the archive lost the states that the other client wrote, so the
  earlier messages of those states no longer decrypted. The manager now
  reads the archive from the stored record each time, and the record keeps
  at most 5 states.
- **Breaking: a group send gives its sender key to each device that has no
  handoff row.** The SDK keeps a sender-key handoff row for each device of
  another member when the Relay accepts a distribution of the own sender key
  for that device. The row names the group, the sender key ID, the
  generation, the recipient device, and the registration ID of the session.
  A group send reads the device list of each member. It gives the current key
  to each listed device that has no row for the current sender key ID,
  generation, and registration. A row records a handoff. It is not proof
  that the device installed the key. The SDK writes the row after the Relay
  accepts the distribution and before the send marks the distribution sent.
  A dropped distribution writes no row. A new own key, a rotation, and a
  delete of the own key delete the rows of the group. A PreKey session from
  the device, a bundle session that replaces a current session, a session
  archive, a session delete, and a device-record delete delete the rows of
  the device in every group. An identity rotation of a contact deletes the
  rows of each device of that account. A retry request deletes the rows of
  the requester in the group of the failed message only. A session reset
  after an expired retry request deletes the rows of each device of the
  sender account in every group. Client start
  deletes each row that no current own key covers. `docs/DEVIATIONS.md`
  section 7.5 compares this record with the record of the Signal apps and
  gives the reason for each difference.
  `SenderKeyState.distributionPending`,
  `SenderKeyManager.getPendingSenderKeyDistribution`, and
  `SenderKeyManager.confirmSenderKeyDistributionSent` are removed.
  `SenderKeyManager.rotateSenderKey` and `rotateGroupSenderKey` do not take
  `options.distributionPending`. The manager ignores a `distributionPending`
  field in a stored state, and the next write of the state omits it.
- **Breaking: a custom store keeps the sender-key handoff rows.**
  `SignalProtocolLocalStore` extends the new `SenderKeyHandoffStore`. A
  custom store must implement its six methods: `recordSenderKeyHandoff`,
  `listSenderKeyHandoffs`, `invalidateSenderKeyHandoff`,
  `invalidateAccountSenderKeyHandoffs`, `listSenderKeyHandoffGroupIds`, and
  `retainSenderKeyHandoffs`. Each row delete must be in the same write as
  the change that causes it.
  `storeSenderKeyRecord` and `deleteSenderKey` take the new
  `SenderKeyRecordWriteOptions`. With `deleteSenderKeyHandoffs`, the write
  deletes the rows of the group. `setDeviceRecord` takes the new
  `SetDeviceRecordOptions`, and `SessionTrustCommit` has the field
  `senderKeyHandoffInvalidation`. With the device, the write deletes the
  rows of that device in every group. `archiveCurrentSession`,
  `deleteSessionRecord`, `deleteDeviceRecord`,
  `deleteAllSenderKeysForGroup`, and
  `acceptContactIdentityRotationAndDeleteSessions` always delete the rows
  of their device, group, or account. The memory store keeps the rows in its
  state. The IndexedDB, key-value, and SQLite stores keep the rows durably,
  so a restart does not give the key to a listed device again. The SQLite
  stores add the `sender_key_handoff` table in schema version 5, and the
  IndexedDB store adds the `senderKeyHandoff` object store in database
  version 10. The IndexedDB and key-value stores encrypt each row and find it
  by keyed hashes, so they hold no group ID, account ID, or device in the
  clear.
- **Breaking: a custom key-value backend must apply
  `removeSenderKeyHandoffs` inside `atomicWrite`.** `KeyValueOperation` has
  the new variant. The part of a key after `keyPrefix` has five
  colon-separated segments: the group hash, the generation, the account
  hash, the recipient hash, and the entry hash. The backend removes each key
  whose group, account, and recipient segments equal every given hash, and
  keeps a key of another shape. It applies the operation in the same
  transaction as the other operations of the batch, and the operation
  observes the earlier writes of the batch. A backend built with
  `createTransactionalKeyValueBackend` applies it already.
  `assertBackendConformance` checks it.
- **Breaking: the group outbox context and the sync send change.**
  `GroupOutboxContext` does not have `confirmSenderKeyDistributionSent`.
  It has the required members `recordSenderKeyHandoff`,
  `prepareSenderKeyHandoffs`, `resolveOwnDevices`,
  `isConclusiveDeviceRejection`, `repairStaleDevice`, and
  `postSyncMessage`. `postSyncMessage` takes, as its third argument, a
  function that encrypts the transcript again for one own device.
  `prepareSyncMessages` takes the own devices of the send as its fifth
  argument. `postPreMessage` resolves to the new
  `PreMessagePostResult`. `appendOutgoingGroupDeviceMessages` is removed.
  `reconcileOutgoingGroupDeviceSet` removes the messages of devices from an
  intent and adds new messages in one write.
  `DefaultSesameManager.sendToLocalOtherDevices` requires
  `listedDeviceIds`, and it sends only to those own devices.
- **Changed: each send gives a sync copy to exactly the listed own
  devices.** On a relay that does not compare device sets, each direct or
  group send, and each replay, reads the device list of the own account,
  with no freshness window. A failed
  read stops the recipient post and fails the send, also for an account
  with no linked device, and the outbox retries a stored send. The first
  attempt of a send that fails on this read throws before the SDK stores
  it. The error carries the `clientMessageId`, but the outbox holds no
  transmission for it. The application calls `send()` again, and the SDK
  encrypts the content again. The send gives
  a sync copy to each listed own device other than the sending device. Each
  sync copy is keyed by its device. An own device gets the transcript and
  never a sender-key handoff row. When the Relay refuses an own device as
  stale, the SDK refreshes the session of that device once and encrypts the
  copy again for it. For the transcript of a stored send, the SDK replaces
  the copy in the intent and posts the new copy under a repair ID. The
  device then gets the transcript of that send. When the Relay refuses the
  new copy too, the SDK archives the session, removes the copy from the
  intent, and completes the send. When the refresh fails, or the encryption
  for the new session gives no copy, the send fails. The copy and the new
  session stay, and the outbox retries the stored send. A sync copy of
  account state, such as a read sync, gets the same refresh. The SDK posts
  the new copy again with no operation ID and changes no intent.
- **Changed: a group replay reads the device lists again.** On a relay that
  does not compare device sets, before the replay of a stored group send, the
  SDK reads the device lists of the members and of the own account. One intent write removes each message of
  a device that the lists do not show. A listed device that the stored send
  does not reach gets the current key of the send and the stored group
  ciphertext. When the sender rotated the key after the send, the added
  device gets only the stored group ciphertext, and the replay completes.
  The device recovers the content through its retry request, and the next
  send gives it the current key. The stored ciphertext does not change, because the Relay
  refuses another operation under the same message ID. Thus a device that
  the replay adds gets the content only through its retry request and the
  resend of a `Resendable` send.

- **Breaking: a group state store keeps a receive record for each group.**
  `GroupStateStore` adds `getGroupReceiveRecord`,
  `updateGroupReceiveRecord`, and `listGroupReceiveRecords`. A receive
  record holds the group's required revision, which is the highest revision
  that an authenticated group context has claimed, and the fetch backoff and
  the last verified denial. A custom store must implement the three methods.
  An update that returns null deletes the group's whole record. The SDK
  store writes version 2 group records with an index. It migrates a version
  1 record forward when it first reads or writes that group, and a crash at
  any migration step reruns safely. A migrated group starts at required
  revision 0 as a locally known group. A record that a context created
  before the group's state was verified also names the sender device that
  claimed it. `storeGroupState` and
  `storeGroupStateWithSenderKeyRotationBarrier` must remove that origin in
  the same write that stores the state. A custom store must do the same.
- **Breaking: managed group content carries its group context.** Each
  send to a managed group, its sync transcript, and its send log entry now
  carry the group's master key and the revision of the sender's verified
  state inside the encrypted content, as Signal's `GroupContextV2` does. A
  resend therefore carries the context of the original send. The receiving
  client removes the context before it gives the content to the
  application, so the application gets the bytes that the sender sent. An
  ad hoc group send carries no context. `SignalProtocolContentAdapter` adds
  two required methods, `serializeContentWithGroupContext` and
  `withoutGroupContext`, and `inspectContent` reports `groupContext`, or
  `'malformed'` for a context that does not decode. A custom adapter must
  implement both methods and report the context. The default adapter puts
  the context in a `groupContext` member of a JSON object and wraps any
  other content in a `groupContent` member.
- **Breaking: a managed group receive follows Signal's order.** The
  client decrypts, runs the replay check, and then installs a sender key
  distribution with no group decision, as Signal does. Membership,
  permission, and blocking no longer stop the install. After the install,
  the client derives the group ID from the context's master key and
  compares it with the group of the envelope and of the distribution. A
  context that does not decode is refused as `malformed-context`, and a
  context of another group as `context-mismatch`. Content that a sender
  key decrypts, or that comes beside a distribution, is content of that
  group in every shape. Sync content is content of this account. On the
  Relay subscription, in `receiveIncomingEnvelopes`, and in
  `processIncomingEnvelope` and `decryptGroupMessage`, content from
  another account that carries a sync message is refused as
  `sync-from-other-account` before the distribution install and before
  any group decision, and the application gets no content. The raw
  decrypt methods `receive`, `decryptMessage`, and `decryptMessages`
  return the plaintext with no group classification and do not refuse
  it. Sender-key content from another account is delivered under its
  group, never under a conversation that its content names. When the
  local state is
  below the revision that the context claims, one fetcher brings the group
  up to date before the client decides. The client decides each message
  at the revision that its own context claims, so a false claim uses up
  only its own fetch. The fetcher runs at most one fetch for each claimed
  revision and at most 16 claims in a backoff window. A fetch that ends
  below the claim is complete: the client decides that message at the
  fetched state, the group's required revision becomes the server head,
  or a higher claim that came while the fetch ran, and the backoff does
  not grow. Only a fetch that fails or that the
  server refuses backs off. A claim above the fetched state that the
  window cannot fetch waits for the next window, so false claims hold an
  honest claim for 30 s at most. When the trust
  root has a server signing key, a context that carries the signed change
  to the claimed revision applies that change with no fetch, also when
  the window has fetched its 16 claims. Under
  `allowUnauthenticatedGroupHistory`, the client never applies a carried
  change. Content with no context is decided at the local state, and is
  refused as `legacy-no-context` when the client has no state. While the
  group cannot update, the content waits on the device in the receive
  record that the decrypt committed with the ratchet state, and the receive
  queue decides it when a fetch of its group completes. The client sends
  no retry request and does not call `onDecryptionError`. The fetcher
  tries again in the background and at start. `decryptGroupMessage` throws
  `GroupReceiveUnavailableError` for such content, and the error carries
  the `messageId` of the record. A second call with the same message
  decides the stored content with no second decrypt, also after a restart.
  Two concurrent calls with the same message give the content once. A sender
  device can make at most 100 groups wait for verification. Past the cap,
  a context for a new group is refused as `unverified-cap`. The new
  `groups.isGroupBlocked` config drops the content of a blocked group with
  no report and no fetch. The background fetcher also skips a blocked
  group, at start and on its timer. A block hook that throws any value
  skips only its own group. `decryptGroupMessage` now decrypts before it
  decides, so a refused message uses its message key. `syncGroup` now runs
  through the fetcher, so it joins a fetch in flight and records its
  result. It returns that result only when the fetch called the group
  server. After a fetch that only tried a carried change, it waits for the
  next fetch, its own when no other caller starts one first. An ad hoc
  distribution installs with no `groups` config. The
  package root and the `client` entry export `GroupReceiveUnavailableError`,
  `GroupReceiveRefusedError`, and `GroupResendDeferredError`.
  `processIncomingEnvelope` returns `pending` for content that waits for
  its group and `denied` for refused content, and the caller acknowledges
  the envelope in both cases. A deferred resend leaves the retry request
  with the Relay. See `docs/ERROR_HANDLING.md`.
- **Breaking: `processIncomingEnvelope` returns a receive outcome.** The
  method now returns a `ReceiveOutcome` in place of the plaintext. Its
  `kind` is `processed`, `pending`, `duplicate`, `null-message`, `denied`,
  or `refused`. Acknowledge the envelope for each kind except `refused`,
  which means that the receive queue has no room: nothing is decrypted or
  stored, so give the envelope again later. A `processed` receive keeps
  its content on the device until the application calls the new
  `completeReceive` with its `messageId`, or until the new `onPersist`
  option resolves. A redelivery before then returns the same outcome with
  no second decrypt. A Relay delivery of an envelope that
  `processIncomingEnvelope` committed reuses that record and installs no
  sender key distribution from it. The new `listPendingReceives` lists the stored
  receives one page at a time, and `{ ready: true }` lists only the
  receives that wait for `completeReceive`. The new
  `processPendingReceives` runs one pass of the receive queue now, and its
  `deadlineMs` option bounds the pass. `processIncomingEnvelopes` returns
  `{ envelope, outcome }` or `{ envelope, error }` for each envelope.
  Before, the method returned the plaintext and deleted the stored content
  before the application saved it, so a crash between the two lost the
  message.
- **Breaking: a custom store commits a receive record with the ratchet
  state.** `SessionTrustCommit.receiveWork` and
  `SenderKeyReceiveCommit.work` replace `receivedContent` and `content`.
  The store must write the `ReceiveWorkRecord` in the same transaction as
  the session or sender key state, so the ratchet step and the record roll
  back together. The store adds `getReceiveWork`,
  `putReceiveWork`, `listReceiveWork`, `receiveWorkUsage`, and
  `completeReceiveWork`, and removes `getReceivedContent`,
  `deleteReceivedContent`, and `deleteExpiredReceivedContent`.
  `listReceiveWork` returns records in arrival order, by `arrivalSeq` and
  then `workId`, and its `after` query takes the last record of the page
  before, so records with an equal `arrivalSeq` are never skipped.
  `putReceiveWork` and `completeReceiveWork` compare the record revision
  and write nothing on a mismatch. `completeReceiveWork` deletes the record
  and writes its metadata in one transaction.
  `SignalProtocolManager.decrypt` takes a `receiveWork` seed in place of
  `receiveId`. The SQLite schema version 4 and the IndexedDB schema version
  9 add only the `receive_work` table and object store. After the first
  open, an SDK earlier than 12 cannot open the store. There is no
  downgrade path. At open, each SDK
  store converts the received content rows of SDK 11 to receive records
  that wait for the redelivery of their envelope, and writes its completion
  marker last, so a stop during the conversion is safe. A row that does not
  parse stays in place, and the store reports it with no content: the
  SQLite store through its logger, the other stores through
  `console.error`. When the Relay subscription, `receiveIncomingEnvelopes`,
  or `pullHostedRelayAfterWake` gets the redelivered envelope of a converted
  record, and the client already processed that envelope, the client
  completes the record with no hook call.
- **Fixed: a receiver installs a sender key that the sender creates again.**
  `processSenderKeyDistribution` matches a key by its sender key ID, as
  Signal's published implementation matches a state by its chain ID and
  signing key. The generation rules apply only to a distribution of the
  current key, and a later generation of that key replaces it in place. A
  distribution of a kept previous key changes nothing. A distribution of
  another key becomes the current state, and the earlier current state
  becomes a previous state, so a message in flight under it still decrypts.
  Before, a receiver dropped each distribution whose generation was not
  above the generation of its current state. `createGroupSenderKey` over an
  existing key, and a delete followed by a create, start again at
  generation 1, so each receiver that held the earlier key failed every
  later group message of that sender device with `SENDER_KEY_MISMATCH`,
  until a rotation took the sender's generation above the one the receiver
  held.
- **Fixed: every send error carries the logical-send identifier.**
  `send()` chooses the `clientMessageId` before any other step, so
  `isOutgoingMessageError` is true also for an error before the encryption,
  such as a failed content serialization or a failed read of the own device
  list. The application calls `send()` again with the same
  `clientMessageId`. Before, only an error of the encryption carried the
  identifier.
- **Fixed: a group resend checks membership at the required revision.**
  Before a sender gives group content again, it brings a managed group
  up to the highest revision that an authenticated context claimed. The
  check uses the same receive record, fetch window, and backoff as a
  receive. A requester who is not a member at that revision gets no
  content, and the answer ends as `membership-refused`. When the update
  is fresh, the sender answers from the local state, also when a false
  claim keeps the required revision above the server head, so a removed
  member who claims a false revision is refused and not deferred. When
  the update fails or waits for its backoff, the sender defers the resend
  and does not refuse it. The resend job stays pending for the resend job
  driver, and the retry request envelope stays unacknowledged for the next
  Relay delivery. Before, the sender checked a stale local state, so it could
  resend to a removed member or refuse an added member.
- **Fixed: unacknowledged messages no longer stall the socket backlog.**
  The mailbox socket now ends each page of durable frames with one
  `acknowledge` frame, with no ID when the page acknowledged nothing. The
  Relay sends the next page of a backlog only on that frame. Before, a page
  of messages that all stayed unacknowledged stalled every page behind it
  until the socket reconnected.
- **Fixed: received content keeps the time of its first admission.**
  `DecryptedEnvelope.receivedAt` is the time the device first committed
  the content. A first pass, a retry, and a delivery after a restart give
  the same value. Content with no timestamp of its own gives this time as
  its `timestamp` for receipt matching, so each delivery gives the same
  timestamp. The 30-day receive age of stored content
  also counts from this time, through a retry, a redelivery, and a
  restart. Before, the first pass read the clock again after it stored
  the content.
- **Changed: the client acknowledges a Relay message after its commit.**
  On the Relay subscription and in `pullHostedRelayAfterWake`, the client
  decrypts each envelope and commits its content as a receive record in
  the same transaction as the ratchet step. It acknowledges the envelope
  only after that commit, and sends no acknowledgment when the commit
  fails, as Signal does. The receive queue then decides the group, gives
  the content to `onMessageDecrypted`, and sends the E2EE delivery
  receipt. That receipt is the only proof that the application processed
  the content. A Relay delivery receipt marks only the handoff of the
  content to the device. Content that waits for its group state stays on
  the device, not at the Relay. A hook that throws is tried again after a
  backoff. The device stores the count of each attempt before it calls the
  hook, so a hook call that ends the process also counts as an attempt.
  After 10 attempts, the content no longer holds back the
  later content of its conversation. Each start then offers it to the hook
  once: in the start pass, or at the registration of `onMessageDecrypted`
  when the start pass had no hook. After that offer, only
  `processPendingReceives` tries it again before the next start, until it
  expires or the application discards it. A pass of those that ends before
  the retry, at a deadline or at a failed page read, leaves the retry to
  the next pass. That retry runs after the other content
  of the device, so a hook call that ends the process on it does not stop
  the later content of its conversation. `pullHostedRelayAfterWake` commits, acknowledges, then
  runs `processPendingReceives`, and its new `deadlineMs` option bounds
  that pass. It gives no content to the application before the
  acknowledgment settles. `HostedRelayWakeClient` adds
  `processPendingReceives`. `receiveIncomingEnvelopes` commits each
  envelope and sends no acknowledgment. The content reaches
  `onMessageDecrypted` in a later pass of the receive queue, after the
  call returns. After `stop()`, the content waits for the next start of the
  queue from `startRelaySubscription`, or for `processPendingReceives`. At
  start, the client admits a new envelope only after its first read of the
  stored content ends, so new content of a sender device comes after its stored
  content, also when the clock stepped back across the restart. This order
  holds only when that first read completes. It does not hold after a first
  read that failed, after a `stop()` during the first read, or for an
  envelope received before the first start. Two processes that share one
  store, such as two browser tabs, each keep their own arrival order, so
  content of one process can come before content that the other process
  received earlier. Before, the client acknowledged only after the
  application had the content, so group content that waited for its group
  stayed at the Relay and came back on each delivery.
- **Added: a bounded receive queue with an expiry hook.** The new
  `protocol.receiveQueue` config sets how much the device holds. Stored
  content may wait 30 days, counted from its first commit on this
  device. The age is fixed. `protocol.receiveQueue` has no age field, and
  a client created with `protocol.receiveQueue.maxAgeMs` is refused with
  an error that names 12.0.0 and the fixed 30 days. Content expires when
  its age is equal to or more than
  30 days. The earlier prune deleted content only at an age of more
  than 30 days, so the expiry now comes 1 ms sooner. `maxItems` is 3000 and `maxBytes` is 750 MiB by default. They are
  provisional until a measurement sets them. `blockedGroupShare`, 0.25 by
  default, is the part of each bound that the waiting records of one group
  can fill. At a bound the client decrypts nothing more and does not
  acknowledge the envelope, so the Relay keeps it. A refused envelope
  expires at the Relay at the TTL of the Relay project, and no local hook
  reports that expiry. While the mailbox of the device is full, the Relay
  refuses a new message to it with `MAILBOX_FULL` to its sender. The new
  `onReceiveExpired` hook gets a `ReceiveExpiredEvent` for content that
  waited 30 days, before the client drops it. Before the hook, the
  client reads the record again, so content that the client completed
  before that read, such as at the redelivery of its envelope, gets no
  report. Before, the client deleted stored content after 30 days with no
  report.
- **Added: `decryptEnvelope` decrypts one envelope with no receive
  record.** It installs a sender key distribution that the content
  carries and checks the group context against the transport. It stores
  no content, decides no group state, and sends no receipt. The decrypt
  spends the ratchet step, so a plaintext that the application loses is
  gone. Use `processIncomingEnvelope` to keep the content until the
  application completes the receive.
- **Changed: `decryptGroupMessage` is deprecated.** Use
  `processIncomingEnvelope`, which returns a receive outcome and keeps the
  content until the application completes the receive.
  `decryptGroupMessage` completes the receive before it returns, so a
  plaintext that the application loses is gone. It throws
  `EncryptionError` with `STORAGE_QUOTA_EXCEEDED` when the receive queue
  has no room, and with `MESSAGE_DUPLICATE` for a message that this client
  processed or that gives no content.
- **Fixed: a retry deadline no longer resets a session whose resend
  arrived.** The commit of a resend now records its failed envelope as
  fulfilled before the client acknowledges the resend. At start, the
  client records it again for each stored resend before the retry request
  lifecycle starts. Before, a resend that waited for its group could reach
  the retry deadline, and the deadline reset the session.
- **Changed: metadata values rest encrypted on the IndexedDB and key-value
  stores.** Each value that `setMetadata` and `compareAndSetMetadata` write
  now goes through the store's record cipher, AES-256-GCM. These values
  include group master keys, the hosted device authentication key, and
  outbox intents. The first open after the upgrade encrypts each clear value
  that the store holds. A stop during that step is safe, and the next open
  continues it. A store that is full keeps its clear values and still opens.
  Metadata key names stay in clear, and some of them hold identifiers. The
  SQLite stores need no change, because the file cipher covers them. An
  earlier SDK version cannot read the encrypted values, so do not open the
  store with one after the upgrade.
- **Fixed: a membership change no longer makes the next distribution
  identified.** A member removal clears the group's endorsements. Before,
  the next send resolved the sealed sender of each distribution pre-message
  from the cache with no refresh. A pre-message to a member with no access
  key then went identified in `preferred` mode, or failed the send in
  `required` mode. A group send now refreshes the endorsements for all
  recipients before it seals the pre-messages, at preparation and again at
  dispatch. A pre-message goes identified only to a member that the refresh
  does not endorse.
- **Fixed: an expired sender key no longer blocks group sends.** When the
  own sender key of a group is older than `maxSenderKeyAge`, a group send
  rotates the key before it prepares the distribution pre-messages. The
  rotation deletes the handoff rows of the group. The send then gives the
  new key to each device that needs it, and encrypts with the new key. A
  distribution that fails, for example after a Relay refusal or an offline
  send, does not make a later send to the group fail with
  `SENDER_KEY_EXPIRED`.
- **Fixed: a retryable Relay refusal no longer ends a retry request.**
  The retry request scheduler now reads the Relay's `retryable` flag before
  the code and the HTTP status. A refusal with `retryable` true, for example
  `AUTHORITY_DENIED` with HTTP 401 while a Relay binding is missing, is a
  transport outage, or a rate refusal for `QUOTA_EXCEEDED`, `MAILBOX_FULL`,
  and HTTP 429. The request waits and is posted again with the same bytes
  and ID. Before, the request ended with `revoked-authority`. A refusal with
  `retryable` false keeps its terminal class. A `TOKEN_INVALID` after the
  one token refresh is `revoked-authority`.
- **Fixed: a failed `onDelivered` hook no longer loses the delivery.** The
  client now marks a delivery source announced only after the hook returns.
  Before, the client stored the mark first, so a hook that threw, a
  `stop()` during the hook, or a crash lost the event. The hook now runs at
  least once for each source. An error from the hook fails the Relay
  receipt or the encrypted delivery receipt, so the relay delivers it again
  and the hook runs again. Make the hook idempotent for one
  `clientMessageId`, `recipientDeviceId`, and `source`.
- **Fixed: a failed `onRetryTerminal` hook no longer marks the end
  emitted.** The SDK marks a retry end emitted only after the hook returns.
  A hook that throws keeps the scheduler running. The next scheduler pass,
  the next start, or the redelivery of the request runs the hook again.
  The hook now runs at least once for each request.
- **Added: a session reset when a retry request ends as
  `expired-content`.** Before the SDK calls `onRetryTerminal`, the
  requester waits for each decrypt from the device that sent the failed
  envelope that is in progress. It then archives its session with that
  device, and its next send to the user reads the device list again. The
  archive deletes the sender-key handoff rows of that device in every group.
  The requester then deletes the rows of each device of that account in
  every group, for a group message and for a pairwise message, as one
  Signal client does at an automatic session reset. The reset does not
  rotate a sender key. The next send to each group gives the current key to
  each device of the account. The requester then sends one
  null message to the device, at most one in an hour for each device. The
  next ordinary message starts the new session when no null message goes.
  The retry request record stores each step, so a replay after a restart
  or a stop does not archive a newer session. The other terminal classes,
  and a post that fails and is posted again, reset nothing.
  `onSessionArchived` runs for the archive. The event gets the optional
  field `recovery` of the new type `RetryTerminalRecoveryEvent`, which is
  exported from the main entry and from `/client`. It has the device, the
  sender key outcome, and the null message outcome `sent`, `limited`, or
  `failed`. The sender key outcome is `applied` when the failed envelope is
  a group message and the requester has a sender key for that group.
  Otherwise it is `skipped`. The rows of the account are deleted with each
  outcome.
- **Changed: a retry request is sealed when the client can seal it.** The
  client seals a retry request when it holds the access key of the target,
  and the Relay does not see the requester. The seal holds the payload of
  the identified request as `PLAINTEXT_CONTENT` (8), and the sealed post
  keeps the retry ID, the client message ID and the timestamp, so the Relay
  deduplicates it as before. A group send endorsement never seals a retry
  request. A retry request follows the `deliveryMode` of `sealedSender`, as
  a delivery receipt does. In `'preferred'` mode the request goes identified
  when the client has no access key or the Relay refuses it. In
  `'required'` mode the request never goes identified: it stays pending, and
  the scheduler posts it again until its deadline. In `'disabled'` mode it
  is always identified. Before, each retry request was identified in every
  mode, and an identified retry request does not have the privacy of a
  sealed one. The `sendRetryRequest` callback of `processIncomingEnvelope`
  gets an identified request, so `'required'` mode never calls it.
- **Changed: the client accepts a sealed retry request.** A sealed envelope
  with the content type `PLAINTEXT_CONTENT` goes to the retry request
  handler, never to a ratchet decrypt. `processIncomingEnvelope` rejects a
  sealed retry request with `INVALID_CIPHERTEXT`, as it rejects an
  identified one. A `11.0.x` client rejects this content type, so it drops
  a sealed retry request from a newer client, and that request ends as
  `expired-content` for the requester. A sealed retry request gets a
  resend only from a sender device that runs this release or a later one.
- **Changed: the `deliveryMode` documentation names what each mode
  covers.** The mode covers each message, resend, delivery receipt and
  retry request to a device of another account. A typing indicator, and a
  sync message to another device of the same account, are always
  identified. `onIdentifiedFallback` reports only a message or a resend.
- **Changed: a group send seals its sender-key distributions.** In
  `required` and `preferred` sealed-sender mode, each distribution
  pre-message goes through the sealed route to its one recipient. The
  recipient's access key comes first, and the group endorsement serves a
  member without one. When the relay rejects the access key, the SDK
  restricts the cached access mode of the recipient and posts the
  distribution again with the group endorsement. A `required` send checks
  this authorization before it encrypts a distribution and before any
  post. When it cannot seal a distribution, it throws
  `SEALED_SENDER_REQUIRED` and posts nothing. A `preferred` send posts a
  distribution identified only after the relay rejects each sealed
  authorization, and then calls `onIdentifiedFallback`.
  A saved send whose distributions have no sealed transport seals them
  from the stored ciphertext at replay, with no new ratchet effect.
- **Fixed: a refused distribution is repaired once.** When a device refuses
  a distribution conclusively, for example after a reinstall with the same
  device ID, the SDK refreshes the session of that device once and encrypts
  the distribution again. It replaces the stored pre-message before the
  post, so a replay never posts the refused ciphertext again. The repair
  post has a new transport ID, `<id>:repair:<n>`. A replay after a restart
  rebuilds a refused distribution from the current sender key with the same
  `senderKeyId`. The repaired device then decrypts the later group messages
  of the sender, but not the message of that send. When the sender key of
  the send is no longer current, the replay refreshes the session, drops
  the distribution, and continues. The next send gives the device the
  current key.
- **Fixed: a group send drops the distribution of a removed device.** When
  the relay refuses a distribution with `NOT_FOUND`, the SDK reads the
  recipient's device list. If the list no longer shows the device, the
  send drops that distribution and continues, as a direct send drops a
  removed device. The send then makes no device post to that device. This
  applies to the repair of a refused device message and to a device that the
  re-read of a skipped account adds. A refused device that the list still
  shows fails the send.
- **Fixed: all six post kinds name the registration of their device.** A
  direct message, a sync copy, a sender-key distribution, a group device
  message, a receipt, and a retry request send the registration ID of the
  recipient session. This applies on the identified route, on the
  access-key route, and on the group-token route. A post to a device with
  no session names none. A sealed post names the registration of each device in its body,
  and each hosted destination names the registration that the body gives
  its device. A device with registration 0 names none. The Relay refuses a
  device that was reinstalled with the same device ID. The refused post
  then gets the one session repair, and the reinstalled device decrypts
  the later messages. A group device post that the Relay refuses as a stale
  device gets the same repair. The send gives the device the key of the
  send and posts the device message again with the new registration. When
  the repair of a refused distribution refreshes the session of a device,
  that device leaves the shared group message of the send. The send posts
  the device message to it on its own with the new registration, so the
  device decrypts the message of that send. A device whose session changed
  for another reason, such as a receipt that refreshed it, also leaves the
  shared group message. When that device has no handoff row, it gets the key
  of the send before its device post. On the attempt that prepared the send,
  the device decrypts the message. On a replay, it gets the current key. It
  recovers the message through its retry request only when the send was
  Resendable and the send log kept it. For another send, the retry request
  gets the current distribution alone, and the device does not get that
  message. The group-token receipt names
  each refused destination with its code. A destination that the Relay
  refused as `STALE_DEVICE` leaves the shared group message. The send
  repairs that device and posts the device message to it on its own. When the Relay refuses a receipt or a retry
  request as a stale device, the SDK fetches a fresh bundle, starts a new
  session once, and posts the receipt or the request again under the new
  session. The session start archives the stale session in the same record
  write, and the `onSessionArchived` hook runs after the start succeeds.
  So a reinstalled device gets the retry request and resends the message.
  A retry request ends with the terminal class `missing-sender` only when
  the Relay has no bundle of the device or refuses the request again. When
  the refresh fails for another reason, the receipt or the request is
  posted again later. A failure before the session record write, such as a
  failed bundle fetch, keeps the stale session, and the next stale refusal
  refreshes again. A failure after that write, such as a failed SESAME
  registration, leaves the new session, and the next post uses it. The sealed post sends
  no sender identity. `sendMultiRecipientUnidentified` takes nine arguments.
- **Changed: a one-device sealed post can use the group endorsement on the
  direct route.** A sender-key distribution, a resend, or a group message
  to one device whose only sealed authorization is the group endorsement
  now posts to `/anonymous/delivery/send`. The Relay accepts the
  endorsement there only when it is for the destination account alone.
  The shared group message stays on `/anonymous/groups/send`, also for one
  device. When the direct route answers the endorsement with 401
  `ANONYMOUS_AUTH_REJECTED`, the SDK posts the same message once on the
  group route for that device and writes one `info` log line with the
  behavior `GROUP_ROUTE_FALLBACK`. A 401 `GROUP_CREDENTIAL_REJECTED` gets no
  route fallback. A `required` send never falls back to identified
  delivery.
- **Fixed: a resend of a group send is sealed with the group endorsement.**
  A resend to a member with no access key could not be sealed, because the
  resend did not look up the group of the original send. It now uses the
  group endorsement of that group for the one device. A `required`
  resend with no sealed authorization fails with `SEALED_SENDER_REQUIRED`
  and makes no identified post.
- **Fixed: a resend with only the sender key keeps the failed group message
  open.** When the sender logged no content for the device, it answers a
  group retry request with the current sender-key distribution alone. That
  resend gives the key but no content, so it no longer marks the failed
  group message processed. A redelivery of that message now decrypts with
  the key and gives its text. This applies, for example, when
  `receiveIncomingEnvelopes` reports the message in `failedMessageIds` and
  the application does not acknowledge it. A resend that carries content
  still marks the failed envelope processed. The client writes a `debug`
  log line with the behavior `RETRY_SENDER_KEY_RESEND`.
- **Added: `SendResult.refusedDestinationCount`.** A group send through
  the hosted group-token route reports the number of destinations that the
  Relay refused when it accepted the shared post. A later fan-out refusal
  is not counted. Other sends do not set the field.
- **Added: send log and storage protection types.** `SendLogStore`
  describes the storage of resendable group content: a payload for each
  group send and a row for each recipient device, kept until that device
  confirms the message or the entry expires. `LocalStoreProtection` names
  how a local store encrypts its data and where its key is kept. A
  `SignalProtocolLocalSecretVault` can declare `custody`. A vault that does
  not declare it counts as `same-origin`.
- **Added: recovery constants.** `RESENDABLE_CONTENT_RETENTION_MS` is 14
  days, `RETRY_PLACEHOLDER_DEADLINE_MS` is one hour, and
  `SEND_LOG_RESEND_JOB_TTL_MS` is one day. `MESSAGE_RECORD_TTL_MS` is now
  deprecated. It keeps the same 14-day value as
  `RESENDABLE_CONTENT_RETENTION_MS`.
- **Breaking: every local store must declare its protection.**
  `SignalProtocolLocalStore` now requires a `protection` member, so a store
  that the application writes must add it. The SQLite stores report
  `file-cipher` with the custody of their vault. They read the cipher from
  the setting that the database records, so a store with
  `encryptionAtRest: false` reports `none` and no key.
  `KeyValueSignalProtocolStore` reports `record-cipher` with the custody of
  its vault. `IndexedDbSignalProtocolStore` reports `record-cipher` with
  `same-origin` custody. `InMemorySignalProtocolStore` reports `none`. The
  Expo SecureStore, react-native-keychain, and Electron safeStorage vaults
  declare `os-keychain` custody, and the IndexedDB vault declares
  `same-origin`.
- **Added: the SQLite stores keep a send log.** The Node, Expo, React
  Native, and web SQLite stores implement `SendLogStore`. Schema version 3
  adds three tables for the payloads, the recipient rows, and the resend
  jobs. The store opens a version 2 file and adds the tables with no change
  to the existing data. The store clock sets `createdAt`, so retention does
  not read the client timestamp. `clearAllKeys` also clears the send log.
- **Breaking: every local store keeps a send log.**
  `SignalProtocolLocalStore` now extends `SendLogStore`, so a store that
  the application writes must add the send log methods.
  `KeyValueSignalProtocolStore`, `IndexedDbSignalProtocolStore`, and
  `InMemorySignalProtocolStore` now implement them with the same behavior
  as the SQLite stores. The key-value and IndexedDB stores encrypt the
  group, the content hint, and the content of each payload. The recipient
  rows and the resend jobs hold no content and stay in the clear. The
  IndexedDB schema version 8 adds three object stores and keeps the data of
  a version 7 database. `clearAllKeys` and the key-value reset
  also clear the send log.
- **Breaking: resendable content needs a protected store.** A sender
  keeps the plaintext of a resendable message to answer a retry request.
  `protocol.contentRecovery` now decides whether the local store may hold
  it. The default mode, `require-protected`, keeps it only when the store
  is encrypted and its key is in an operating system keychain or a
  declared application vault. The mode `allow-co-located-key` also keeps
  it when the key shares the storage of the data, as with
  `IndexedDbSignalProtocolStore` and the IndexedDB vault. Those stores
  encrypt each record, but a reader of the origin storage can also read
  the key. The mode `off` keeps no content. A store with no encryption
  never keeps it. When the policy refuses the store, the client keeps no
  pairwise message record, and a retry request for a direct message resets
  the session with no content. The client also deletes the message records
  and the send log entries that the store already holds.
  `contentRecoveryStatus` shows the decision and its reason, and the client
  logs it once at creation. To keep content recovery on a web store, use a
  keychain or application vault, or set `allow-co-located-key` after a
  product review. `retentionMs` sets the retention, at most 30 days.
- **Breaking: the client validates the store protection.** Creation fails
  when the local store declares no `protection`, an unknown value, or a
  cipher without a key. A declaration adds no encryption. It must state
  what the store does.
- **Corrected: storage protection and content hint documentation.** The
  security model lists the protection that each built-in store declares,
  and says that a deletion does not erase content. Received content is
  outside `protocol.contentRecovery`: every store keeps it until the
  application handles the envelope, and a later Relay receive deletes what
  is older than 30 days. `MessageRecord` holds no retry count. The `contentHint` docs give the retry request and
  `onDeliveryError` behavior of each hint.
- **Added: `contentRecoveryStatus.groupMembershipSource`.** The sender
  asks a group membership source before it gives group content to a device
  again. A managed group is checked against its verified group state, from
  `groups` with `resolveAciBytesByUserIds`. The hook
  `protocol.contentRecovery.isCurrentMember` answers for an ad hoc group
  and gets the prefixed group ID. The status field is `managed`, `hook`, or
  `none`, with the type `GroupMembershipSource`. A client with no source
  is still created and keeps content. It logs one warning at creation, a
  direct message resend works, and the client refuses each group resend.
- **Changed: a group message is resendable by default.** When
  `protocol.contentRecovery` keeps content, a group send of a `DataMessage`
  has the content hint `Resendable` unless the application sets another
  hint. The client writes the content and the recipient devices to the
  send log before it stores the outgoing intent, so a failed write stops
  the send before any post. The client writes the entry once. A replay of
  an unfinished send writes no row again, so a row that an E2EE delivery
  receipt deleted stays deleted. Each recipient gets the hint in the identified
  envelope, the sealed message for one device, and the shared sealed
  message for the group. When the policy keeps no content, or the send is
  a string or bytes with a `Resendable` hint, the send goes out as
  `Default` and the client logs this once.
- **Changed: an E2EE delivery receipt ends the content of its device.**
  When a device confirms a message with an E2EE delivery receipt, the
  client deletes the send log row of that device. The last row takes the
  content with it. A Relay delivery receipt, a read receipt, and a viewed
  receipt delete no row, because a device also acknowledges a copy that it
  could not decrypt.
- **Added: `forgetSentContent` and `getPendingRecipients`.**
  `client.getPendingRecipients(clientMessageId)` lists the devices that
  have not confirmed a group send with an E2EE delivery receipt.
  `client.forgetSentContent(clientMessageId)` deletes the logged content of
  one group send at once. It does not delete the pairwise message records.
- **Changed: content retention follows `retentionMs`.** The client deletes
  send log entries and pairwise message records past
  `protocol.contentRecovery.retentionMs` at creation, at `stop()`, and
  before the first resendable group send of each day. It also deletes
  expired send log entries before each lookup. A retry request for a
  pairwise message older than the retention gets no content. Before, the
  client used the fixed 14-day value for the message records.
- **Changed: the store clock sets the age of a pairwise message record.**
  Each local store sets `createdAt` of a `MessageRecord` from its clock at
  the first write, and keeps that value when a resend replaces the record.
  It does not store the `createdAt` that the caller gives. Retention, the
  sweep, and the sender refusal of an old retry request measure from this
  value, so the message timestamp does not change retention. A retry
  request for a message with no stored content takes its age from the
  failed timestamp. Records written before this change keep their stored
  `createdAt`. A custom `MessageRecordStore` must set `createdAt` the same
  way.
- **Breaking: `KeyStorageOps` needs `clearSendLog`.** A device lifecycle
  reset now clears the send log with the other local crypto state. A
  custom `KeyStorageOps` must add `clearSendLog(): Promise<number>`. The
  built-in stores already implement it.
- **Added: a retry request names the failed client message ID.**
  `RetryRequest` has an optional `failedClientMessageId`. When the relay of
  the requester delivers the client message ID of the failed envelope, the
  retry request carries it, so a sender can find the message when the
  relay assigns its own envelope ID. The payload stays at version 1, and a
  decoder that does not know the key ignores it. Each later attempt of the
  request carries the ID of the failed envelope, not the ID of a failed
  resend.
- **Changed: a retry request for a sender-key message has no ratchet key.**
  The SDK no longer reads a ratchet key from the ciphertext of a failed
  sender-key message. A retry request without `ratchetKey` names a
  sender-key failure.
- **Fixed: a pairwise retry request carries the ratchet key of the
  sender.** The SDK reads the ratchet key from the stored wire form of the
  failed message. A stale-session request now resets the session, and a
  request for a current session resends only. Before, the SDK read the
  wire form as a framed message, so no request carried a key. A sealed or
  malformed message still gives no key.
- **Fixed: a session reset for a retry request sends its null message.**
  When the content of a failed pairwise message is gone, and the request
  names the ratchet key of the current session, the sender archives that
  session. The sender then starts a new session from a fresh prekey bundle
  of the requesting device and sends the null message on it. Before, the
  null message found no session, so the sender did not acknowledge the
  request. A request with another ratchet key, for another device, or from
  another sender does not change the session.
- **Fixed: a new session from a prekey bundle keeps the earlier sessions.**
  A session that the client starts from a prekey bundle archives the
  current session and keeps the archived sessions. Before, it replaced the
  session record, so a message that the peer encrypted on an earlier
  session did not decrypt. After a session reset for a retry request, a
  message that the requester sent on the archived session now decrypts.
- **Changed: a sender answers a group retry request from the send log.**
  The sender looks up the send log rows of the device that asked: by the
  failed client message ID, then by the failed envelope ID, then by the
  failed timestamp. Each logged entry that it finds goes again to that
  device only, with its timestamp and content hint, and only when the
  current membership source admits the requester to the group of the
  entry. A row counts its resends, and the count survives a restart. A row
  with 5 resends gets no more. A requester that is not a current member,
  and a group with no membership source, get no content and no
  distribution. The answer to the failed envelope then ends with the new
  `RetryTerminalClass` value `membership-refused`. The sender stores the
  end, calls `onRetryTerminal` once, and answers no later request for that
  envelope from that device. The refusal is not a delivery error, and the
  sender acknowledges the request envelope. A group with no membership
  source also writes one `warn` log line for the group with the behavior
  `RETRY_GROUP_RESEND_REFUSED`. This deviates from the recovery design,
  which logged the refusal only. When no row names the
  message, a sender-key failure gets the current sender-key distribution
  of the group alone, so the device decrypts the later group messages of
  the sender. A retry request without a ratchet key never resets the
  pairwise session. A retry request that names another device of the
  sender gets no answer, and the client writes a `warn` log line with the
  behavior `RETRY_REQUEST_OTHER_DEVICE`.
- **Changed: a resend of logged group content carries the current sender
  key.** Each logged entry goes again with the current sender-key
  distribution of its group beside the content, in one pairwise envelope.
  The sender reads the distribution when it makes the resend, so the
  device also decrypts the later group messages of the sender. With no
  sender key for the group, the content goes alone. The `info` log line of
  the resend says whether it carried a distribution.
- **Breaking: a content adapter must put content beside a distribution.**
  `SignalProtocolContentAdapter.serializeContentBesideSenderKeyDistribution(content, groupId, distribution)`
  is a new required method. It returns one content with the logged content
  and the distribution. The default adapter adds the distribution to the
  JSON object of the content, in the form of
  `serializeSenderKeyDistributionText`. It throws when the content is not
  a JSON object.
- **Added: a resend of logged content survives a restart.** Before the
  membership check, the sender writes a pending resend job for each logged
  entry that a retry request attempt names. The job of the entry that
  answers the attempt names the failed envelope in the new field
  `SendLogResendJob.failedEnvelopeId`. The SQLite send log keeps it in the
  new column `failed_envelope_id` of `send_log_resend_job`. A job counts
  each post attempt before the post and ends as `posted` after it. The job
  of an entry that the membership or the resend limit refuses ends as
  `abandoned`. The client runs the pending jobs at `create()`, at each
  relay transition to connected, and after a failed job. The wait after a
  failure is a full-jitter wait from 1 s that doubles up to 30 s, and a
  failed job writes a `warn` log line with the behavior
  `RESEND_JOB_RETRY`. A job checks the membership again when it runs, and
  never resets a session: it makes one only when there is none. A job
  ends as `abandoned`, with one `info` log line, when it is older than
  `SEND_LOG_RESEND_JOB_TTL_MS`, when its logged entry is gone, when the
  answer to its failed envelope ended, when the membership refuses the
  requester, at the resend limit, or when no session can be made. A
  request without a request attempt writes no job. This deviates from the
  recovery design, which named a `send-log:resend-job` reliability record.
  The job lives in the send log store, with its entry.
- **Changed: a message record keeps no sender-key distribution.** The
  message records of the pairwise sends keep no chain key. A send of a
  distribution alone keeps no record. A record of a distribution beside
  other content keeps only that content, so it stays resendable. A
  sent-sync transcript to an own device follows the same rule. At
  `create()`, the client removes each distribution from the records that
  an earlier version wrote, once, and then writes the marker
  `migration:skdm-records-removed`. It keeps the content and the
  `createdAt` of a mixed record and deletes a record of a distribution
  alone. When this sweep fails, `create()` fails, and the next start
  sweeps again. The retry handler applies the same rule to each record
  that it reads. A group timestamp whose record it deletes gets the
  current sender-key distribution of the group, as a missing record does.
- **Changed: a start with content recovery off clears content once.** When
  content recovery is off, `create()` clears the message records and the
  send log once, and then writes the marker `resendable-content:cleared`.
  A later start with content recovery off clears nothing, until a start
  with content recovery on keeps content again. The clear deletes no
  sender-key state, so the next group send needs no new distribution.
  When the clear fails, `create()` fails, and the next start clears again.
- **Breaking: a content adapter must remove a distribution from a
  record.** `SignalProtocolContentAdapter.withoutSenderKeyDistribution(plaintext)`
  is a new required method. It returns the plaintext unchanged when it
  carries no distribution, the other content when a distribution travels
  beside it, and `null` for a distribution alone. It applies the same
  rule to the content inside a sent-sync transcript of the adapter's
  format. The default adapter implements it.
- **Breaking: a custom message record store must rewrite its records.**
  `MessageRecordStore.rewriteMessageRecords(rewrite)` is a new required
  method. It calls `rewrite` for each record, replaces the plaintext of a
  record when the result differs and keeps its `createdAt`, deletes the
  record when the result is `null`, and returns the number of changed
  records. The memory, key-value, web, and SQLite stores implement it.
- **Fixed: content beside a sender-key distribution reaches the
  application.** Before, the client installed a distribution and then
  dropped the rest of its content. A data message in the same envelope
  never reached `onMessageDecrypted`, and no delivery receipt went out for
  it. Now the client installs the distribution, then routes the other
  content as a receipt, a typing indicator, or a data message. This
  applies on the relay subscription and on `receiveIncomingEnvelopes()`.
  A distribution that comes alone still gives nothing to the application.
- **Breaking: a content adapter must decide a distribution-only content.**
  `InspectedSignalProtocolContent.senderKeyDistributionOnly` is a new
  required `boolean`. A custom content adapter must set it on every
  inspect result. It is `true` when the content carries a sender-key
  distribution and nothing else. The default adapter sets it.
- **Changed: content beside a sender-key distribution is group content.**
  Before the client installs such a distribution, it checks that the
  sender may send messages to the group of the distribution. When the
  group refuses the sender, the client installs no key and gives no
  content. `onMessageDecrypted` gets the content with `isGroup` set to
  `true` and the group ID as `conversationId`. A retry resend can carry
  the content of a failed group message beside the current sender key.
  The application then gets that content under the `messageId` of the
  failed message, on the relay subscription and on
  `receiveIncomingEnvelopes()`. The resend marks the failed message
  processed, so a later redelivery of that message is dropped. When the
  failed message decrypts first, the later resend is dropped.
- **Fixed: `processIncomingEnvelope()` asks for a failed group message
  again.** A group message that fails with a retryable error, for example
  after a lost sender-key distribution, now gets a retry request to its
  sender, and the client acknowledges it, as on the relay subscription.
  Before, the method threw with no request, so the message was lost. A
  group message with the Implicit content hint gets no request and is
  acknowledged. On every receive path, the stored request names the
  message as a group message, so a resend that brings only the sender key
  does not mark the message processed.
- **Added: the `onDeliveryError` and `onDeliveryRecovered` hooks.** When a
  received message fails to decrypt and the client asks the sender for it
  again, `onDeliveryError` tells the application that the content did not
  come. The content hint of the message sets the time. A message with the
  Default hint, or with no hint, gets the error at once. A Resendable
  message gets it one hour after the first failure,
  `RETRY_PLACEHOLDER_DEADLINE_MS`, when its content has not come. An
  Implicit message never gets it. A request that a rate limit refuses, or
  a request that ends, gets the error at once. It deletes nothing, and the
  retry request continues after it. When the content comes after the
  error, `onDeliveryRecovered` runs with the receive time of the first
  failure. Each hook runs at least once for each failed message, also
  across a restart. The client marks the error shown, or the recovery,
  only after the hook returns. A hook that throws, a client stop, or a
  crash before that mark runs the hook again at the next retry request
  pass, start, or redelivery. A hook that throws in a retry request pass
  does not delay the next attempt or the end of the request. A receive
  does not acknowledge a failed message whose error or recovery hook threw
  before the content, but an error from the recovery hook after the
  content does not fail the receive that gave it. Make each hook
  idempotent for one `failedEnvelopeId`. The events are
  `DeliveryErrorEvent` and `DeliveryRecoveredEvent`, with the cause type
  `DeliveryErrorCause`. They are exported from the main entry and from
  `/client`. For a failed group message, both events carry `groupId`, in
  the form of `DecryptedEnvelope.conversationId`, when the client holds
  the sender key that the message names. The error of a message with a
  missing sender key has no `groupId`. Its recovery has one when the
  decrypt that gave
  the content installed or used the sender key of the group. The client checks the time at each redelivery of the failed message and at each retry
  request write. With a relay, it also checks at `create()` and, while the
  client runs, at the time when the error is due. A pairwise message has
  no content hint by default, so its error comes at once.
- **Changed: a receive failure that no resend can repair asks for
  nothing.** Three failures are in this class: the group state refuses the
  sender, the identity of the sender is not trusted (`UNTRUSTED_IDENTITY`),
  and the envelope is malformed (`INVALID_CIPHERTEXT`). On the relay
  subscription, on `receiveIncomingEnvelopes()`, and on
  `processIncomingEnvelope()`, the client posts no retry request, stores
  no request record, and acknowledges the envelope. `onDecryptionError`
  runs once for the envelope, and a redelivery of it is dropped. The relay
  subscription writes an `error` log line that names the refusal. A
  ciphertext that does not decode or parse now fails with
  `INVALID_CIPHERTEXT`. Before, it got a retry request. Before, the relay subscription also asked again for a
  refused or untrusted envelope, and `processIncomingEnvelope()` did not
  acknowledge it.
- **Changed: a retry request ends 14 days after the first failure.** The
  deadline of a request is the time of attempt 1 plus 14 days, the default
  retention of resendable content, `RESENDABLE_CONTENT_RETENTION_MS`.
  Each later attempt keeps it, and the timestamp of the
  failed message does not change it. Before, the deadline was 24 hours
  after attempt 1 and no later than 30 days after the failed message. A
  request that a rate limit refuses waits for the end of the rate window
  and keeps its deadline, also across a restart. At the deadline the
  request ends as `expired-content`, also when its stored attempt is
  answered. A request whose content came does not end. A stored request
  keeps its stored deadline. At the deadline, a sender key that has not
  rotated since the failure is older than the default `maxSenderKeyAge` of
  14 days. After an `expired-content` end of a group message, the next
  group send then rotates that key, as any send does, and distributes the
  new key to each member.
- **Added: the `attempts-exhausted` retry terminal class.** When the
  resend that answers the fifth attempt of a request,
  `MAX_RETRY_RESPONSES_PER_MESSAGE`, also fails, the request ends as
  `attempts-exhausted` and posts no sixth attempt. `onRetryTerminal` runs
  with the class, and `onDeliveryError` runs with the cause
  `request-ended`. Only an `expired-content` end resets the session, so
  this end resets nothing. A switch over `RetryTerminalClass` must handle
  the new value.

## 11.0.0

- **Added: the connection reason `authority-refused`.** The mailbox
  subscription moves to `stopped` with this reason when the Relay refuses
  the socket token request or a pull with `retryable` false and the code
  `AUTHORITY_DENIED`, `NOT_FOUND`, or `OPERATION_EXPIRED`. A deleted account
  gets this refusal. The subscription does not reconnect and does not pull.
  A refusal with `retryable` true, for example a missing Relay binding, stays
  retryable. A `NOT_FOUND` on the socket token request names this device,
  so it stops with `device-unknown` instead. A `switch` over
  `RelayConnectionReason` must handle the new value.
- **Changed: one retry schedule for a Relay outage.** A failed socket, a
  failed socket token request, and a failed pull now share one backoff with
  a ceiling from 1 s to 30 s. A failure during a pending wait draws no new
  wait. Before, a failed pull retried on its own timer, and each failed
  token request also scheduled a pull. The ceiling starts again at 1 s when
  the Relay answers a ping or the token request gets a new device token.
- **Added: the `onRetryTerminal` hook.** A retry request that cannot
  recover ends once with a `RetryTerminalEvent`. The event has the
  terminal `class` and the `failedEnvelopeId`. The requester gets
  `missing-sender`, `revoked-authority`, `expired-content`, `deletion`,
  and `abuse-allowance-exhausted`. The sender of a resend gets
  `missing-prekey` when the Relay has no prekey bundle of the requester.
  The SDK stores the terminal state before it calls the hook. A restart
  calls the hook again only when the earlier call did not finish. The
  `RetryTerminalEvent` and `RetryTerminalClass` types are exported from the
  main entry and from `/client`.
- **Added: the retry request scheduler.** A retry request post that fails
  with a transport outage or a rate refusal is posted again at its next
  attempt time, with the same bytes and ID. The wait is the age of the
  stored attempt, from 1 minute to 1 hour. The Relay codes map to classes:
  `STALE_DEVICE` is `missing-sender`, `NOT_FOUND` is `deletion`,
  `AUTHORITY_DENIED` and `AUTHORITY_OVERRIDE` are `revoked-authority`, and
  `QUOTA_EXCEEDED` and `MAILBOX_FULL` are rate refusals. A client with a
  Relay runs the scheduler at creation, at the start of the Relay
  subscription, and at the next attempt time or deadline of a stored
  request. A stop stops it.
- **Changed: a redelivery of a failed envelope with a retry request record
  posts nothing.** It spends no request of the sender rate limit, and it is
  acknowledged. Before, each redelivery posted the stored request again and
  spent one request.
- **Changed: a retry request ends at its deadline.** The deadline is 24
  hours after attempt 1, and no later than 30 days after the failed
  message. A later attempt keeps it. A request with no answer at the
  deadline ends as `expired-content`, and no attempt starts after it.
- **Breaking: the retry request records use a new storage prefix.** Client
  creation moves each record of the earlier prefix once, and deletes the
  earlier keys. A moved record gets a deadline 24 hours after its stored
  attempt. The move is forward-only, so an earlier SDK does not read the
  moved records.
- **Fixed: a failed retry request post no longer strands the request.**
  Before, each failed post spent the sender rate limit, and the failed
  envelope stayed the only trigger of a new post. The stored record now
  owns the request, and the scheduler posts it again when the transport
  recovers. The next start posts a request whose first post a stop or a
  crash ended. It also posts an unanswered record that moved from the
  earlier prefix.
- **Fixed: a redelivery no longer extends the retry cooldown.** When the
  rate limit refuses the request of a failed resend, the next attempt waits
  for the end of the limit window from the refusal. Before, each
  redelivery spent the limit again and moved the window.
- **Added: `HostedRelayDeviceUnknownError`.** A device token request throws
  it when the Relay has no device for the stored session. The Relay sends
  this answer as `NOT_FOUND`. Its `code` is `NOT_FOUND`, its `status` is the
  HTTP status, and its `retryable` is false. The class is exported from the
  main entry and from `/client`.
- **Added: `HostedRelayDeviceRevokedError`.** A Relay call throws it when an
  account recovery revoked this device. Its `code` is `DEVICE_REVOKED`, its
  `status` is 403, and its `retryable` is false. The class is exported from
  the main entry and from `/client`.
- **Added: the connection reasons `device-revoked` and `device-unknown`.**
  The mailbox subscription moves to `stopped` with one of these reasons when
  the Relay refuses this device. It does not reconnect and does not pull. A
  `switch` over `RelayConnectionReason` must handle the new values.
- **Added: the `reregister` assertion purpose.**
  `createHostedSignalProtocolClient` with `assertionPurpose: 'reregister'`
  registers this device again with its stored identity and device key. It
  skips the stored session and asks for a `register` assertion. It throws
  before any assertion when the store holds no identity or no device key.
  It sends a fresh one-time prekey batch, so the operation ID is new. A
  retry after a lost answer sends the same operation again.
- **Changed: the device token request names its device key.** The body of
  each `/identity/token` request carries `deviceAuthenticationPublicKey`. A
  Relay that does not read the field ignores it.
- **Breaking: the SDK never registers or retries after a device refusal.**
  `createHostedSignalProtocolClient` throws the device error when the stored
  session cannot get a token. `isRetryableError` returns false for both
  errors. A receipt send that gets one of them makes no in-process retry.
- **Breaking: a refused device token is not a refusal of the destination.**
  A send whose token request the Relay refuses throws the device error. A
  client call can wrap it in an `EncryptionError` as the `originalError`.
  The send does not mark the destination device as refused.
  `getIdentityKey` and `fetchPreKeyBundle` throw the device error instead of
  returning null. `hostedRelayWakePresence` throws the device error as it
  is, not as a `HostedRelayPresenceError`. The profile access key
  registration does not mark the key as refused, so a later connect tries
  it again.

## 10.1.0

- **Added: the SDK names Relay protocol version 1 on HTTP.** Each HTTP
  request to a Relay route carries the header
  `x-open-e2ee-relay-protocol: 1`. The fetch of the connection document
  carries no version. The mailbox socket still offers `open-e2ee-relay.v1`.
  The Relay reads a request without the header as version 1, so a Relay
  that serves version 1 serves this SDK and SDK 10.0.0.
- **Added: `HostedRelayUpgradeRequiredError`.** An HTTP call throws it when
  the Relay no longer serves the protocol version of the SDK. Its `code` is
  `UPGRADE_REQUIRED`, and its `retryable` is false. The SDK does not retry
  it. The class is exported from the main entry and from `/client`.
- **Added: the connection reason `upgrade-required`.** The mailbox
  subscription moves to `stopped` with this reason when the Relay closes
  the socket with code 4426 and the reason `UPGRADE_REQUIRED`. It does not
  reconnect and does not pull. A close 4400 with the reason
  `PROTOCOL_UNSUPPORTED`, and the HTTP code `PROTOCOL_UNSUPPORTED`, stay
  retryable.

## 10.0.0

- **Breaking: `onDelivered` replaces `onDeliveryReceiptReceived`.** The
  hook gets one `DeliveredEvent` for each new receipt source of each
  recipient device. A Relay receipt gives `source: 'relay'` and
  `decryptionConfirmed: false`. An end-to-end receipt gives
  `source: 'e2ee'` and `decryptionConfirmed: true`. The status of a device
  only moves forward, `sources` holds each source that the device has given
  so far, and a second receipt of the same source changes nothing. A receipt
  for a send that has not resolved yet comes after the send resolves. The
  new `DeliveredEvent` and `DeliverySource` types are exported.
- **Breaking: an unknown hook name throws.** `registerHook()` and the
  `hooks` option of client creation throw for a name that is not a hook.
- **Breaking: the `server_delivery_receipt` message type and
  `IMPLICIT_ENVELOPE_TYPES` are removed.** An envelope is implicit only
  when its `contentHint` is `ContentHint.Implicit`.
- **Changed: only an end-to-end receipt deletes the retry copy.** The
  sender deletes its copy of a message for a recipient device when that
  device sends an end-to-end delivery receipt. A Relay receipt does not
  delete it.
- **Changed: end-to-end receipts are sealed when the client can seal
  them.** The client seals a delivery receipt when it holds the access key
  of the sender, and sends it identified otherwise. A receipt follows the
  sealed sender delivery mode of a message: in `'required'` mode the client
  does not send a receipt that it cannot seal, and a Relay that refuses the
  access key does not make the receipt identified.
  `sendMultiRecipientUnidentified()` takes an optional `contentKind`, so a
  sealed receipt carries `'receipt'`.
- **Added: each envelope names its content kind.** `Envelope` has an
  optional `contentKind`, of the new exported `ContentKind` type. The client
  sets `'receipt'` on each end-to-end delivery, read, and viewed receipt
  that it sends. The Signal Protocol Relay transport sends `'message'` for every
  other envelope, on identified, anonymous and group sends, so the Relay
  can tell a receipt from a message without reading it.
- **Added: the client takes Relay delivery receipts from the Signal
  Protocol Relay.** A Relay that states the receipt capability on a
  connection sends `delivery-receipt` frames on that connection, and a pull
  returns its receipts only when it asks for them. The client passes each
  receipt through the same ordered queue as the messages, hands each receipt
  ID off once, and acknowledges it to the Relay after the hand-off, in
  frames of at most 100 IDs on the socket or with `receiptIds` over HTTP.
  A Relay receipt states only that the recipient device acknowledged the
  message to the Relay, not that the device decrypted it.
- **Changed: `deliveryReceipts: 'auto'` leaves the receipt to the Relay
  when it can.** On the Signal Protocol Relay, the client sends no
  end-to-end delivery receipt for an identified message that the Relay
  acknowledgment lists as receipted. It sends the end-to-end receipt when
  the acknowledgment omits the message, when it fails, when no reply comes
  in 30 seconds, or when the connection closes first. A sealed message
  always gets the end-to-end receipt. `stop()` sends each receipt that
  still waits for a Relay reply, once. On any other relay, `'auto'` sends
  the same receipts as `'always'`.

## 9.5.0

- **Breaking: a retry request is now a mailbox envelope.** Before, a
  recipient that could not decrypt a message sent the retry request on a
  separate relay channel, and the Signal Protocol Relay had no such
  channel, so a hosted client could not ask for a resend. Now the
  recipient sends an identified `retry_request` envelope to the sender
  device through `send()`, on every relay. The receiving client takes the
  requester from the envelope sender, never from the payload. It resends
  only to the device that asked, and it keeps the request when the resend
  fails, so the next pull tries again. It acknowledges a malformed retry
  request and drops it. `SignalProtocolRelayServer` no longer has a
  separate retry-request channel, and `DefaultSignalProtocolClient` no
  longer starts a retry subscription. A custom relay must carry
  `messageType: 'retry_request'` like any other envelope. Each request,
  resend and null message carries its retry family ID in its
  `clientMessageId`. The sender reads the request attempt from it, and the
  requester finds the failed envelope of a resend or a null message by
  it. So a relay that assigns its own envelope IDs must deliver the
  `clientMessageId` with the envelope on every delivery path, as the
  in-memory relay and the Convex subscription and poll do. The client
  keeps the delivered envelope ID for its processed record and its
  acknowledgment. The client drops a request that carries a retry ID
  under another ID.
  `ProcessEnvelopeOptions.sendRetryRequest` now receives that envelope. The
  Convex component no longer has a retry-request table, its cron or its
  three functions, so deploy the new component.
- **Fixed: a client asks the sender of a sealed message for a resend.**
  Before, when a sealed message failed to decrypt inside the seal, the
  client used the sender of the outer envelope. For a hosted anonymous
  envelope that sender is empty, so the client could not ask for a resend
  and the message failed again at each pull. Now the client asks the
  sender device that it finds inside the seal. When the seal itself fails
  to open, the message names no sender. For a resend or a null message,
  the retry request record names the device that the request went to, so
  the client asks that device for the next attempt, on each receive path.
  It marks the message processed and acknowledges it only after that
  request posts. For any other message, the client sends no retry request
  and writes a log line. A foreground delivery acknowledges that message,
  and a background pull keeps it, as for any other message that fails to
  decrypt.
- **Fixed: a sealed message keeps its content hint.** Before, a sealed
  message carried the default content hint inside the seal, and the
  receiver did not read it. A sealed IMPLICIT message, such as the null
  message of a retry reset, that failed to decrypt then caused a retry
  request. Now the sender seals the content hint of the message, and the
  receiver puts it on the unsealed envelope. A sealed IMPLICIT message
  that fails to decrypt causes no retry request.
- **Fixed: `processIncomingEnvelope()` sends one retry request for each
  failed envelope.** Before, when `markDelivered` failed, the next
  processing of the same envelope sent a second retry request. Now the
  client stores the encrypted retry request under the failed envelope ID,
  as on the relay subscription path. A later processing of the same
  envelope posts the stored request again, so the relay sees one
  operation. Each post counts toward the retry rate limit. The record holds
  a fingerprint of the envelope as the Relay delivered it, the same on
  every receive path. The fingerprint covers the envelope ID, the sender,
  the message type and the ciphertext, but not the timestamps, so a push
  without a server timestamp and a pull with one match. When the relay
  gives the same envelope ID with changed content, the client sends no
  retry request, keeps the envelope unacknowledged and writes a log line.
- **Fixed: one failed message gets one resend.** Before, each retry request
  had its own ID, so two requests for one failed message gave two resends,
  and the requester decrypted both. Now the requester keeps one retry
  request record for each failed envelope. The record holds a random retry
  ID, and that ID names the request family on the wire: the request is
  `<retry ID>:retry-request`, the resend is `<retry ID>:resend`, and the
  null message of a retry reset is `<retry ID>:null`. Each attempt from 2
  adds `:<n>`, for example `<retry ID>:retry-request:2`. The failed
  envelope ID travels only in the request payload, in the new
  `failedEnvelopeId` and `retryId` fields. When the Relay refuses the
  stored request as expired, or when a resend or a null message fails to
  decrypt, the requester encrypts the next request attempt under the same
  retry ID, on each receive path. A second delivery of the same failed
  resend starts no new request attempt. The resend and the null message
  carry the attempt number of the request that they answer, so the answer
  to `<retry ID>:retry-request:2` is `<retry ID>:resend:2`. The sender
  encrypts one resend for each request attempt and stores it, so a second
  delivery of the same request attempt posts the stored resend again. A
  retry request ciphertext is at most 2,048 characters, and a failed
  envelope ID is at most 128 characters.
- **Fixed: a resend of an older message reaches the Signal Protocol
  Relay.** Before, a resend posted the original message time as its
  operation epoch. The Relay refuses an epoch older than 5 minutes, so it
  refused the resend of an older message. Now the resend keeps the original
  timestamp in the envelope, and posts the epoch of its stored attempt. A
  new encryption after the admission window posts a fresh epoch under the
  same attempt ID. `Envelope.operationEpochMilliseconds` and a new last
  parameter of `sendMultiRecipientUnidentified()` carry that epoch to the
  relay.
- **Fixed: a failed resend repeats the same post.** Before, each attempt
  encrypted the message again. A second attempt under the same client
  message ID then carried other bytes, and the Relay refused it as a retry
  conflict. Now each resend attempt stores its encrypted bytes and its
  epoch, and a second delivery of the same request attempt posts them
  again. A later request attempt gets a new encryption under the ID of
  that request attempt, for example `<retry ID>:resend:2`. When the Relay
  refuses the stored bytes as expired, the client encrypts again with a
  fresh epoch under the same ID. A retry conflict to a resend post means
  that the Relay holds an earlier encryption under that ID, so the attempt
  is complete. When the Relay admits the new bytes after the requester
  processed the earlier encryption, the requester drops them. The null
  message of a retry reset has its own IDs. The client keeps the records
  for 30 days, so a later delivery of the same request attempt posts them
  again.
- **Fixed: the application gets each message at most once, unless a local
  store write fails after the application got the message.** The Relay
  frees a message ID after the acknowledgment, so a second resend attempt
  can arrive after the first. The client processes one resend or the failed
  envelope itself for each failed envelope. When a resend decrypts, the
  client marks the failed envelope as processed, and it acknowledges a
  later delivery of the failed envelope and drops it. When the failed
  envelope decrypts on a later delivery, the client drops each resend for
  it. It acknowledges each dropped envelope and does not decrypt it. This
  applies to the relay subscription, to `receiveIncomingEnvelopes()` and to
  `processIncomingEnvelope()`, which throws `MESSAGE_DUPLICATE` for a
  dropped envelope. Two attempts that arrive at the same time are processed
  one after the other. A resend or a null message that fails to decrypt
  while the retry rate limit refuses its request stays unacknowledged, so a
  later delivery asks again. When the client cannot store that a resend or
  the failed envelope decrypted, it writes a warning with the behavior
  `RETRY_FULFILL_WRITE_FAILED` on each receive path, and continues as for
  any decrypted envelope: the relay subscription acknowledges it,
  `receiveIncomingEnvelopes()` returns its ID as processed, and
  `processIncomingEnvelope()` returns the plaintext. A redelivery of the
  failed envelope or of a resend may then give the message again. The
  client stores that the application got the content as the `fulfilled`
  flag of the processed record of the failed envelope, in one write.
  `getProcessedEnvelope()` returns the flag, and `storeProcessedEnvelope()`
  takes it as a new last parameter.
- **Fixed: the application never gets a null message.** Before, a
  decrypted null message of a retry reset reached `onMessageDecrypted` as
  the content `{"nullMessage":{}}`, and `processIncomingEnvelope()`
  returned it. Now the client consumes a null message when the content
  adapter reports `nullMessage: true`, and a custom adapter must report it
  for its own null encoding. The client marks the null message processed
  and acknowledges it on each receive path, and
  `processIncomingEnvelope()` throws `MESSAGE_DUPLICATE` for it. A null
  message answers a retry request when the sender has no plaintext. It
  marks its failed envelope processed, so the client drops a redelivery of
  that envelope, but it does not mark the content as delivered. A content
  resend for the same failed envelope that arrives later, of any attempt,
  is decrypted and given to the application once. When the client cannot
  store the processed record of a null message or of its failed envelope,
  it writes a warning with the behavior `RETRY_NULL_WRITE_FAILED` and
  still consumes the null message, so `processIncomingEnvelope()` still
  throws `MESSAGE_DUPLICATE`. A redelivery of the failed envelope may then
  give the message.
- **Breaking: a content adapter must decide the null message.**
  `InspectedSignalProtocolContent.nullMessage` is now a required
  `boolean`. A custom content adapter must set it on every inspect result,
  and report `nullMessage: true` for its own null encoding. The default
  adapter sets it.
- **Fixed: the hosted transport takes envelope IDs from the Relay.**
  Before, the hosted transport spread the decoded wire JSON over the
  envelope, so a sender could set `id` or `clientMessageId` in the wire
  and replace the Relay message ID. Now the transport keeps only the wire
  fields that a sender encodes: the ciphertext, the content hint, the
  message type, the timestamp and the version. The envelope ID and the
  `clientMessageId` both come from the Relay message ID, on the pull,
  subscription and ephemeral paths.
- **Fixed: a late resend attempt is still dropped.** A sender now refuses
  a retry request for a message sent more than 30 days ago. The Relay can
  keep the last resend post for 30 more days, so the requester keeps its
  retry records for 60 days.
- **Fixed: a processed envelope ID with new content is acknowledged.**
  Before, when the relay gave a processed envelope ID with changed bytes,
  the client threw on each pull and never acknowledged the envelope. The
  Relay can reuse an ID after it forgets a row. Now the client
  acknowledges the envelope, drops it and writes a debug log line.
  `hasProcessedEnvelope()` no longer takes a fingerprint, and the new
  `getProcessedEnvelope()` returns the stored record.
- **Breaking: `runPeriodicCleanup()` is removed.** It cleaned only a
  retry deduplication map that the client no longer fills, so it did
  nothing. Remove each call to it.

## 9.4.0

- **Breaking: `deliveryReceipts` defaults to `'auto'`.** Before, the default
  was `'always'`. Now a client that does not set `deliveryReceipts` uses
  `'auto'`, which sends the same receipts as `'always'`.
- **Fixed: steady traffic no longer holds back a delivery receipt.** Before,
  each new message from a sender restarted the 3 s batch timer of that
  sender, so messages that came less than 3 s apart held every receipt back
  until the traffic stopped. Now a receipt batch is sent 3 s after its last
  message or 30 s after its first message, whichever comes first, or at 100
  messages.
- **Fixed: `stop()` sends the batched delivery receipts.** Before, `stop()`
  dropped the receipts that waited in a batch, and `stopRelaySubscription()`
  sent each batch but left it in place, so its timer sent the same receipt a
  second time. Now both send each waiting batch once before the relay
  subscription closes. `stop()` waits for delivery receipt sends, including
  their app hooks, such as `onMessageEncrypted`, until one deadline 5 s
  after it starts. It waits for each receipt send that is in progress when
  it starts, except a send that an earlier `stop()` stopped, and for the
  sends that it starts. A delivery that finishes during the wait batches its
  receipt. At the end of each wait, `stop()` sends the batches that wait and
  waits for those sends until the same deadline. It does this again while
  the deadline is not past. `stop()` holds the receipt batches from its
  first flush until it clears its tracking state. During the hold,
  `stopRelaySubscription()` does not send them, and `stop()` drops a receipt
  batched after its last flush. At the deadline it stops each receipt send
  that is left: a send that waits in an app hook stops, and that receipt is
  not sent. A send that is in its relay call at the deadline is waited for,
  and that receipt can still be sent. A hook of a delivery receipt send that
  awaits `stop()` holds `stop()` until the deadline. `stop()` does not wait
  for read and viewed receipt sends. A call to `startRelaySubscription()` or
  `startRetryRequestSubscription()` while `stop()` runs is refused and
  logged; start again after `stop()` resolves. A `stop()` call that overlaps
  a running `stop()` waits for it and settles as it settles.
  `stop()` clears the retry timer of a failed delivery, read, or viewed
  receipt send that started before `stop()` stops its relay work.
- **Changed: `deliveryReceipts: 'auto'` sends a receipt for each message that
  asks for one.** Before, `'auto'` sent a receipt only for a message that
  arrived through sealed sender, so the sender of an identified message got no
  receipt and kept its copy of that message for 14 days. Now `'auto'` sends
  the same receipts as `'always'`.
- **Fixed: a resent message keeps its retry copy.** Before, a resend that
  answered a retry request deleted the sender's copy of the message, so a
  second retry request for that message found no copy and the message could
  not be sent again. Now the resend replaces the copy with the copy of the new
  encryption. Only a delivery receipt from that recipient device, or the 14-day
  limit, deletes it.
- **Added: `SendResult` carries `duplicate` and `expiresAt`.** `client.send()`
  now returns what the relay reported for the device posts of the send.
  `duplicate` is true only when the relay had already accepted every device
  post, so the send stored no new copy. This is the case when the application
  calls `send()` again with the `clientMessageId` of a send whose posts the
  relay accepted but whose result did not arrive. `expiresAt` is the earliest
  time at which the relay drops the copy of a device post that the device has
  not acknowledged. A group send also counts its shared sealed post. For a
  group send over a group token, the shared post reports that the relay had
  already accepted its fan-out, not that each destination stored a copy. Each
  field is present only when every post reported it, so both are absent on a
  relay that does not report them. The sync copies to this account's other
  devices do not count. The sender key pre-messages of a group send do not
  count. `send()` still resolves only after every device post, the sync
  copies, and the outbox record complete. A send that the outbox had already
  completed returns the result that it stored.
- **Fixed: a hosted client accepts an ephemeral message only after it handled
  it.** Before, the client did not give the relay the promise of its work for
  an envelope, so the hosted transport did not wait for it. The client
  accepted each ephemeral message before it decrypted it, even when the work
  then failed, and sent an extra acknowledgment for each ephemeral message
  that it handled. A durable message whose work failed stayed in the mailbox
  until the next reconnect, and the notification batch of a burst ended before
  its work. Now the hosted transport waits for the work of each envelope. It
  accepts an ephemeral message after its work succeeds, and acknowledges a
  burst in one socket frame after its work. A durable message whose work fails
  stays in the mailbox, and the hosted transport gives it again on the next
  recovery pull or socket replay. The transport continues with the next
  message at once, whatever its sender, so it does not keep the order across a
  failed message. It holds back no message. While a failed message remains,
  the client pulls again after a random wait from half to one and a half of
  the failed-work wait, which starts at 2 s and doubles to 64 s. A failed
  message remains until its work succeeds or a recovery page shows it gone. A
  page shows it gone when the page is not full and does not hold the message.
  The client must also have started to pull the page more than 5 s after the
  first failure of the message. Then the message expired or was acknowledged
  elsewhere. A full recovery page whose batch acknowledged a message pulls the
  next page after a random wait from 1 s to 3 s. A full page that acknowledged
  nothing pulls again only while a failed message remains, after the
  failed-work wait. The failed-work wait starts again at 2 s after a recovery
  pull that leaves no failed message, and when a new socket opens. A socket
  open while a failed message remains schedules one failed-work pull; the
  replay can make that pull empty. The `onEnvelope` callback of
  `SignalProtocolRelayServer.subscribe` returns `void | Promise<void>`, so a
  custom relay can also wait for the work of each envelope.

## 9.3.0

- **Fixed: a hosted client with `hosted.profileKeys` now sends sealed 1:1
  messages.** Before, the hosted factory gave the sealed sender cipher no
  contact store, so each 1:1 message was identified and the Relay saw its
  sender. Now a hosted client sends a sealed 1:1 message only when
  `hosted.profileKeys` is set, and only to a contact whose profile key
  `contacts` holds. Each other 1:1 message is identified. Until the client
  holds the profile key of a contact, its messages to that contact are
  identified and carry this account's profile key. The client also registers
  with the Relay the access key that it derives from this account's profile
  key, so a contact that holds that profile key can send sealed messages to
  this account. When the Relay refuses the access key of a contact, the
  client sends that message identified and records the refusal in
  `contacts`. Messages to that contact stay identified until its profile key
  changes. A hosted client without `hosted.profileKeys` sends identified
  messages only.

## 9.2.0

- **Fixed: a hosted Relay request that never answers now ends after 30 s.**
  Before, a device post on a dropped connection had no deadline. It kept its
  send open with no end, so later sends to the same recipient waited, and four
  such posts held every relay request slot of the client. Now each hosted
  Relay request aborts after 30 s, response body included, and rejects with
  "Signal Protocol Relay request could not be completed". Send the same
  operation again: the Relay drops a repeat of an operation that it accepted.
  The same deadline applies to the connection lookup, the managed group
  authority, and each managed group request. A connection lookup that times
  out uses a cached connection up to one hour old, as it does when the Relay
  cannot be reached. Every hosted Relay request that the deadline ends rejects
  with the same error, whose `cause` is "Signal Protocol Relay request timed
  out". This is also true on a platform whose fetch drops the abort reason.
- **Changed: the hosted mailbox socket waits a random time before it
  reconnects.** The ceiling of the wait starts at 1 s, doubles after each
  failed attempt up to 30 s, and starts again at 1 s when the Relay answers a
  ping, 30 s after a socket opens. A socket that closes sooner keeps the
  ceiling growing, so a loop of short connections waits up to 30 s. Each
  wait, the first one too, is a random time from zero up to the ceiling. The
  HTTP recovery pull while the socket is down now waits a random time from 1 s
  to 3 s, not exactly 2 s. Before, every client that lost its socket at the
  same moment, for example in a Relay deploy, reconnected and pulled at the
  same moment.
- **Added: a hosted Relay send result carries `duplicate` and `expiresAt`.**
  `SignalProtocolRelayServer.send()` and `sendMultiRecipientUnidentified()`
  return them when the Relay reports them. `duplicate` is true when the Relay
  had already stored the message, so the call stored no new copy. `expiresAt`
  is the time at which the Relay drops a stored copy that the device has not
  acknowledged. A send to several devices reports `duplicate` true only when
  every device reports it, and the earliest `expiresAt`. A group send token
  reports `duplicate` true when the Relay had already accepted a send with the
  same ID. That does not tell that each device stored a copy. `duplicate` is
  absent when the call sent the request again after an uncertain answer,
  because the first request can have stored the copy that the repeat found.
  Both are absent for an ephemeral message and from a relay that does not
  report them. A receipt whose `duplicate` or `expiresAt` has the wrong type is
  refused. The SDK does not read the `persisted` field of a receipt. The values
  are true only from a Relay that stores each message before it answers. Until
  then, the hosted Relay can report an `expiresAt` for a message that it
  delivered and did not store, and `duplicate` false for a repeat that it
  delivered. `client.send()` does not return these fields.
- **Added: `deliveryReceipts` selects the messages that get a delivery
  receipt.** `'always'`, the default, keeps the current behavior. `'auto'`
  sends a receipt only for a message that arrived through sealed sender, and
  `'off'` sends none. The hosted Relay does not yet report the delivery of an
  identified message itself, so with `'auto'` the sender of an identified
  message gets no receipt. The sender keeps a copy of each message that it
  sends, plaintext included, to send it again on a retry request. A delivery
  receipt deletes that copy. With `'off'`, or with `'auto'` for an identified
  message, the copy stays until it is 14 days old, and only client creation
  and `stop()` delete such old copies. Read receipts are not affected. Any
  other value makes client creation throw.
- **Breaking: `DecryptedEnvelope` has a required `arrivedSealed` field.** It is
  true when the message arrived through sealed sender. Code that builds a
  `DecryptedEnvelope`, for example a test double of `onMessageDecrypted`, must
  set it.
- **Fixed: the hosted mailbox socket ignores a frame of an unknown type.**
  Before, the client closed the socket and reconnected with reason `frame`, so
  a Relay that added a frame type made every older client reconnect. A frame
  that is not JSON, has no string `type`, or is a known type with a missing
  field still closes the socket.

## 9.1.0

- **Added: `hostedRelaySandboxIdentity` creates the identity assertion callback
  for a Sandbox environment.** Pass `hostedRelaySandboxIdentity(storage)` as
  `hosted.getIdentityAssertion`. The callback signs a device-owned assertion
  with an Ed25519 key that it keeps in the device-local store, one key for each
  publishable key. The Relay binds the Sandbox account to that key, so a device
  that loses its store loses the account. The callback supports only device
  registration in a Sandbox environment. It rejects a production connection,
  recovery, provider migration, and recent or step-up assurance.
- **Added: `IdentityAssertionRequest` carries `environment` and
  `publishableKey`.** The SDK reads both from `relayUrl`, so a callback can use
  them without a second configuration value.
- **Fixed: the published declarations compile with `skipLibCheck: false`.**
  The root declarations no longer name the internal profile key exchange or
  import Convex types. `verifyUnidentifiedAccessMode` moved to its own module
  in the `./profile` entry, which keeps its Convex peer. A packaging check now
  compiles each export subpath with `skipLibCheck: false`.
- **Fixed: a type guard no longer narrows `EncryptionError` to `never`.** Each
  `EncryptionError` and SQLite store error subclass declares its `name` as a
  literal type. Before, a subclass with no other members had the same shape as
  its base class, so the false branch of its guard removed the base class too.

## 9.0.0

9.0.0 is a major release. The entries below give the details. To upgrade from
8.2.0:

1. **Reset group Sender Key state.** Sender Keys now use format `v2`. Discard
   queued group sends, reset sender-key state on every device, and
   redistribute keys with upgraded peers.
2. **Update custom local stores.** A receive commit applies
   `SenderKeyReceiveCommit.skippedKeys` atomically with the record. Skipped
   keys carry `senderKeyId`. Key-value backends implement
   `pruneSkippedSenderKeys` inside `atomicWrite`.
3. **Use only client exports.** The public package no longer exports relay
   implementations, the group server engine, or credential and certificate
   issuers.
4. **Check group IDs on receive.** With a group store, a managed-format group
   ID needs verified local state. `onGroupSenderKeyRotated` receives the raw
   group ID.

- **Fixed: overlapping Braid sessions complete their key exchanges independently.**
  The incremental KEM no longer caches a commitment shared across sessions.
  It no longer rejects a valid encapsulation key from an interleaved session.
  Interleaved sessions now use their own key material, including after state restore.
  The wire format and persisted state format remain unchanged.
- **Corrected: SPQR recovery and key-derivation documentation.** Braid recovery
  depends on delivered chunks and peer replies, with no fixed message-count bound.
  The notes now describe the production message-key expansion and supported limits.
- **Fixed: managed announcement groups enforce the sender's role.** Both
  encryption paths require an administrator. All group message receive paths
  apply the same rule before consuming a message key. Member key distributions
  and ad-hoc Sender Keys remain available.
- **Fixed: group receives fail closed for a managed group ID without a master key.**
  With a group store, a raw group ID in the managed format (the 32-byte group
  identifier in lowercase hex) requires verified local state on every receive
  path. Ad-hoc Sender Keys remain available for IDs in other formats. The public
  group receive methods accept ad-hoc Sender Keys without a group store.
- **Fixed: membership changes rotate the active sender key.** The callback
  used a prefixed group identifier for a separate record. Sends continued
  using the old record, which let removed members decrypt new messages. The
  callback now uses the send path's raw identifier and persists pending key
  distribution. The next send distributes the new key before its ciphertext.
  Restart and outbox write failure preserve that pending distribution.
- **Fixed: public Sender Key operations use one record for raw and prefixed group IDs.**
- **Changed: `onGroupSenderKeyRotated` receives the raw group ID.** Automatic
  and manual rotation pass the ID without the `open-e2ee:group:` prefix.
- **Changed: Sender Key getters wait for an active operation on the group.**
  `hasGroupSenderKey`, `getGroupSenderKeyDistribution`, and
  `getGroupSenderKeyStats` return state after an active send, rotation, or
  receive for that group completes.
- **Fixed: concurrent sends cannot overwrite completed group key rotation.**
  Group operations share a lock through preparation, persistence, and relay
  posting. Pending distributions stay paired with their ciphertext. An older
  outbox retry preserves a later key's pending distribution.
- **Fixed: client stop releases group receive lock waits held behind a group send.**
- **Fixed: a group attachment upload no longer blocks receives for that group.**
  The group lock covers the Sender Key work only. A separate ordering lock
  keeps sends to the group in order across the upload.
- **Fixed: hooks of a group send run after the group lock.** A hook such as
  `onSessionEstablished` that called `hasGroupSenderKey` for the same group
  deadlocked the send. The client now calls these hooks after the group
  operation finishes.
- **Corrected: group implementation ownership.** Signal publishes its group
  server in `storage-service`. The internal SDK contains the enforcing engine
  used by the OpenE2EE Signal Protocol Relay.
- **Fixed: Sender Keys archive rollback.** Distribution processing and local
  rotation update the cache after storage succeeds. A failed write preserves
  delayed messages through later receives, retries, and manager restarts.
- **Fixed: Sender Keys cache isolation.** Group, sender, and device tuples now
  retain separate archived states when identifiers contain delimiters.
  This preserves delayed messages and record ownership across creation,
  rotation, deletion, and manager restarts. Cache lookups no longer use
  another tuple's archived key.
- **Fixed: atomic group receives.** Skipped-key additions and eviction now commit with state and
  optional received content. Current and archived generations use this boundary,
  including receives without a durable ID. Custom local stores must apply
  `SenderKeyReceiveCommit.skippedKeys` atomically with the record. Custom
  key-value backends must implement `pruneSkippedSenderKeys` inside `atomicWrite`.
- **Fixed: skipped Sender Keys remain separate across rotations.** Each stored
  key now includes its distribution identifier. A delayed message uses the
  correct generation even when two generations share the same chain index.
  Atomic receive commits consume only that generation's key. Custom local
  stores must add `senderKeyId` to skipped-key lookup, storage, and deletion.
  `SenderKeyReceiveCommit.consumedSkippedKey` now carries the identifier and index.
- **Changed: Sender Keys use HKDF-Extract before HKDF-Expand.** This corrects
  message-key derivation to match the reference algorithm. Sender-key state
  and distribution messages now require `senderKeyVersion: 'v2'`. Signed
  frames require version byte `0x44`. Old state, distributions, and frames
  fail closed. Before upgrading, discard queued group sends and reset group
  sender-key state on every device. Then redistribute keys with upgraded peers.

  SQLite discards skipped keys from its old schema because they lack generation
  identifiers. This pre-launch break provides no legacy derivation or reader.
- **Breaking: public exports contain only client code.** Relay implementations
  and the group server engine stay private. The public package also excludes
  credential issuers, certificate issuers, and the group administration CLI.
  The private repository retains these implementations and entry points.
  Client transports, storage adapters, group encryption, credential receipt,
  and presentation remain public. Public guides use OpenE2EE Signal Protocol Relay.
- **Changed: public exports check a declaration inventory.** Each mixed module
  classifies its client and server declarations. An unclassified declaration or
  class member fails the export. TypeDoc generates API documentation from the
  projected client source. Build and package checks verify that the public
  artifact excludes server code. Release checks also verify SDK imports in
  source examples, declarations, and generated documentation against public exports.

## 8.2.0

- **Changed: a group send posts to the member devices at the same time.**
  Before, a group send posted each sender-key distribution message, each
  device post, and each copy for the sender's other devices one after the
  other. Now each phase of a group send posts at the same time, under the
  client's bound of 4 relay requests, and a phase starts only after the phase
  before it settles: the sender-key distribution messages, then their
  confirmation, then the group message and its device posts, then the copies.
  A failure for one device does not stop the other devices of the phase.
  After every device of the phase settles, the send rejects with the error of
  the first failed device in member order. When a distribution message fails,
  the stored send keeps only the distribution messages that the relay did not
  accept, so a replay with the same `clientMessageId` posts only those. The
  sessions for the members are set up at the same time, and the index in the
  `clientMessageId` of each distribution message follows the member order.
- **Changed: a group send that distributes a new sender key reads each
  member's device list once.** Before, such a send read the list of a member
  up to three times: to prepare the distribution, to set up the sessions, and
  to send the group message. The device posts of one group send check and
  refresh the group's endorsements one at a time, so one refresh serves them
  all.
- **Changed: a direct send posts to each device of the recipient at the same
  time.** Before, a direct send posted to one device after the other. A
  failure for one device stopped the posts to the devices after it. Now the
  send posts to every device at the same time, and a failure for one device
  does not stop the other devices. After every device settles, the send
  rejects with the error of the first failed device in recipient order. The
  copies for the sender's other devices start only after every device post
  settles. These copies, and the copies of read state and other account
  state, also post at the same time. A replay with the same `clientMessageId`
  posts to every device again. A relay that remembers the result of a device
  does not store the message again. After the hosted Relay forgets a result
  (60 s), that device gets a second copy, and the recipient drops it as a
  duplicate. When two sealed-sender posts of one send fail authorization,
  the access mode steps down two times, to `DISABLED`, as before.
- **Changed: one client has at most 4 relay requests in flight.** The device
  posts and copies of a direct send, the prekey fetches of session setup, and
  the requests of hosted sealed-sender delivery share this bound. The clients
  that use one hosted Relay transport share one bound. A request that finds
  the 4 slots full waits, and the waiting requests start in the order that
  they came.
- **Changed: a direct send through the hosted Relay posts before it reads
  the recipient's device list, when this process read the list less than
  5 min before.** Before, a direct send to a recipient whose list was more
  than 60 s old waited for the device-list read before it posted. Now the
  send posts to the known devices, reads the list, and in the same send posts
  the same message to each device that the list newly shows. A device linked
  60 s to 300 s before a send now receives that send. A send after a restart,
  after 5 min, or after reads that failed, still waits for the read. The
  stored send records the pending read, so a replay reads the list before it
  completes. Sender key distribution, and sends through the Convex and memory
  relays, keep the read before the post.
- **Changed: a direct send through the hosted Relay that posts before the
  read drops a removed device.** Before, a send threw the Relay's `NOT_FOUND`
  when a post named the mailbox of a device that the recipient had removed.
  Now such a send waits for its device-list read, drops that device from the
  send and its result, and succeeds. A `NOT_FOUND` for a device that the list
  still shows, or when the read fails, still fails the send. A send that does
  not read the list, because the last read is less than 60 s old, still
  throws.
- **Fixed: a sealed-sender send through the hosted Relay repairs a device
  that the Relay refuses as `STALE_DEVICE`.** The identified path fetched a
  new prekey bundle and sent again, but the sealed path threw. Now both paths
  repair the device.
- **Fixed: a device-list time later than the clock counts as old.** When the
  wall clock went back, a send used the old list until the clock passed that
  time again. Now the send reads the list.
- **Fixed: an app entry that awaits SDK work at the top level finishes.**
  When a bundler splits code, each module that the SDK loaded with `import()`
  got its own chunk. That chunk imported the app's entry chunk, so it waited
  for the entry module to finish evaluation. An entry module that awaited a
  send or a sync at the top level never finished, and the SDK work stopped. In
  a Vite 8 build, the first send stopped. Now the SDK loads with `import()`
  only a module that imports nothing, so no SDK chunk imports the entry chunk.
  The SDK loads the other modules with static imports.
- **Changed: session setup fetches the prekey bundles of a recipient's
  devices in parallel.** Before, a send that set up sessions with a
  recipient fetched one prekey bundle for each device in turn. Now the
  fetches run at the same time, and one client has at most 4 of these relay
  requests in flight, also when it sets up sessions with more than one
  recipient. The client then establishes the sessions one at a time, so
  every device gets its session and its device record on every store. A
  device with no bundle, or a device whose fetch fails, does not stop the
  other devices.
- **Fixed: an encrypted Expo store on the web fails before it uses the
  vault.** The web build of `expo-sqlite` has no SQLCipher, and Expo
  SecureStore has no web implementation. `expoStore()` on the web rejected
  with `KEY_STORAGE_ERROR` from the default vault, and with a custom vault it
  wrote a key before it rejected. Now `expoStore()` and `resetExpoStore()`
  reject with `SqliteEncryptionUnavailableError` (`KEY_STORAGE_ERROR`) when the
  `expo-sqlite` build has no SQLCipher, before they use the vault or a file.
  The same refusal applies to a native build without the `useSQLCipher`
  option. `encryptionAtRest: false` still opens a store without encryption. The
  guide names `./local/store/web-sqlite` for encrypted browser storage.
- **Fixed: the Electron vault names the Secret portal key.** On Linux, a
  Chromium feature can make `safeStorage` use that key. The feature is
  `SecretPortalKeyProviderUseForEncryption`, and the ciphertext starts with
  `v12`. The vault refused that key, but its `KEY_STORAGE_ERROR` named the
  fixed fallback key.
  Now the error names the Secret portal. Outside a Flatpak or Snap sandbox,
  the portal gives the same key to each Electron app of the user. The vault
  still refuses the key, and the vault file does not change.
- **Fixed: concurrent SESAME writes for one user keep every change.** Each
  write of a SESAME user record or device record reads the record, changes
  it, and writes it back. Two concurrent writes for one user could both read
  before either wrote, and the second write then removed the change of the
  first: a device that a concurrent `addDevice` added, a session, or a
  cleared verification flag. Now a per-user lock orders these writes in
  `DefaultSesameManager`, on every store. The lock orders the writes of one
  client process only. It does not order two browser tabs or two processes
  that share one store.
- **Changed: hosted sealed-sender delivery reads the recipients at the same
  time.** Before a sealed-sender send through the hosted Relay, the transport
  reads the device directory of each recipient account that it has not
  cached. It read one account after the other. Now it reads the accounts at
  the same time, with one read for each account, also when two sends need
  the same account. A direct send also delivers to each device of the
  recipient at the same time. At most four of these requests are in flight
  for each client. A failure for one device no longer stops the delivery to
  the other devices. After every device settles, the send rejects with the
  error of the first failed device in recipient order, and a successful send
  returns the server timestamp of the last device in that order.
- **Fixed: SESAME writes and store sweeps keep a newer session.** A SESAME
  write that carries a session read it before the protocol took the session
  lock. When a send or a receive committed a newer session between that read
  and the write, the write put the older session back, and the next send
  used a message key again. `deleteStaleRecords()` and
  `cleanupExpiredSessions()` read the records, decided, and wrote without a
  lock, so they could delete a device that got a session after the read, or
  write back a session and a verification flag that a SESAME write had
  changed. Now these writes and each device change of a sweep take the
  session lock of the device and then the per-user lock, and read the
  records under them. A PreKeyMessage receive now compares the incoming
  identity with the identity that the store pins when it writes. An identity
  pinned while the message decrypts gets `pendingVerification` and an
  identity change event. It is no longer replaced. The locks order one
  client process only.
- **Fixed: key cleanup, session setup, and device removal keep a newer
  session.** `cleanupExpiredKeys()` read the session and wrote it back
  without the session lock. `establishSession()` registered the session
  state that it read after the session was established. When a send
  committed a newer state between the read and the write, the write put the
  older state back, and the next send used a message key again. When the
  device list of a recipient no longer listed a device, or listed a new
  identity for it, the removal deleted the session under the per-user lock
  only, so a send that was in progress could put the session of the removed
  device back. Now the cleanup runs under the session lock. Session setup
  registers the state of the session that the store holds under the session
  lock. A device removal takes the session lock of the device and then the
  per-user lock. Two device-list syncs for one recipient still run one after
  the other. The locks order one client process only.

## 8.1.0

- **Changed: the web SQLite store is no longer experimental.** Its last
  graduation gate, a soak, now runs in Chromium on each change to the main
  branch and on each pull request that is ready for review. It drives open,
  write, read, and close cycles, one long session of churn, and writes that
  two tabs make in turn, and it fails when latency, memory, or the file size
  grows over the run. The guides now name `webSqliteStore` first for
  browsers where the origin private file system works, and `indexedDbStore`
  where it is not available. The error of `DefaultSignalProtocolClient.create()`
  without storage names both.
- **Fixed: an open of the web SQLite store under a full origin quota rejects
  with `StorageQuotaExceededError`.** The open rejected with
  `OPFS_FILE_BUSY`. After a failed first open, the store could also fail every
  later open with `SQLITE_CANTOPEN`. Now the open rejects with
  `StorageQuotaExceededError` (`STORAGE_QUOTA_EXCEEDED`), a new store writes
  no key and no database file, and the open succeeds after space frees.
- **Changed: hosted prekey reads send the destination mailbox generation.**
  The hosted Relay client sends the `mailboxGeneration` field on each prekey
  bundle fetch and each prekey status read, which includes an identity key
  read. The Relay keeps the prekeys of a device for each mailbox generation,
  so a read after a recovery gets the prekeys of the recovered device. The own
  device sends the generation of its session. For another device, the client
  reads the device directory first. When the Relay does not find the prekeys
  at a cached generation, the client reads the directory one more time and
  tries again. A directory read now also removes the cached generation of each
  device that the directory no longer lists.
- **Changed: group zero-knowledge proofs and credential presentations are
  about twice as fast.** The constant generators of the group credential and
  encryption systems keep a table of their multiples and their encoding. A
  proof, a presentation, and a presentation verification calculate each sum
  of products with one constant-time multiscalar multiplication, which uses
  these tables. The Lizard decode uses an addition chain for its field
  exponentiation. The proofs, the credentials, and their bytes do not change.

## 8.0.0

8.0.0 is a major release. The entries below give the details. To upgrade from
7.2.0:

1. **React Native and Expo: install a global random source.** Install
   `react-native-get-random-values` 2.x or `react-native-quick-crypto`, and
   load it before the first SDK call.
2. **Pass a secret vault.** The profile key, the device ID, the
   device-lifecycle state, and the key-value store's value key live in a
   `SignalProtocolLocalSecretVault` that the app passes. A call without one
   throws `SECRET_VAULT_REQUIRED`. Bare React Native apps can use
   `./local/vault/react-native-keychain`, Expo apps
   `./local/vault/expo-secure-store`, and Electron apps
   `./local/vault/electron-safe-storage`.
3. **Key-value store: change the import and the names.** The store moves from
   `./local/store/react-native` to `./local/store/key-value`, and its names
   drop the `ReactNative` prefix. To keep existing data, move its value key
   into the vault before the first open.
4. **Bare React Native: `./local/store/react-native` is now the SQLite
   store.** `reactNativeStore()` opens an SDK-owned SQLCipher database on the
   optional peer `@op-engineering/op-sqlite` 18.2.5 or later, with the
   op-sqlite SQLCipher build turned on.
5. **Expo: await the store.** Replace `expoStore()` with `await expoStore()`.
   The SDK owns the database, its schema, and its key.
6. **Node and Electron: open the new SQLCipher store.** `nodeStore({
   directory, vault })` opens an SDK-owned SQLCipher database on the optional
   peer `better-sqlite3-multiple-ciphers` 13.0.3 or later. It does not read
   the files of the 7.2.0 Node store.
7. **Remove the deleted names.** The `./local/store/expo/db` and
   `./local/store/expo/schema` entries, the Expo database and key functions,
   the profile-key storage functions, `createReferenceReactNativeBackend`, and
   the `drizzle-orm`, `expo-crypto`, and `fs-native-extensions` peers are
   removed.
8. **Hosted Relay: copy the connection URL from the console again.** The
   API path and the developer environment kind changed, and the sandbox and
   staging hosts moved to new names.

Browser apps can also use the new `./local/store/web-sqlite` store, an
encrypted SQLite database in the origin private file system. It is optional,
and the IndexedDB store stays at `./local/store/web`.

- **Removed: the optional `expo-crypto` peer.** The SDK does not load
  `expo-crypto`, so `package.json` no longer lists it. An app that installed
  `expo-crypto` only for the SDK can uninstall it.
- **Added: web SQLite store gates in WebKit.** A macOS job runs the web
  SQLite store's contract, interruption, and multi-tab gates in WebKit on
  each change to the web SQLite store, the SQLite core, the storage contract,
  the key vault, the gate, or a dependency. Linux WebKit (WebKitGTK) has no
  origin private file system, so the web SQLite store does not run there. In
  each job that must run these gates, a gate that skips for want of the
  origin private file system fails. The store stays experimental: its
  storage-pressure and soak gates do not exist yet.
- **Fixed: the SQLite stores report full storage as
  `StorageQuotaExceededError`.** When the database file cannot grow because
  the disk or the storage quota is full, a write on the Expo, bare React
  Native, Node, or web SQLite store rejects with `StorageQuotaExceededError`
  (`STORAGE_QUOTA_EXCEEDED`), with the SQLite error as `originalError`. It
  rejected with the SQLite error or a `KEY_STORAGE_ERROR`, and the web SQLite
  store reported a full origin quota as a disk I/O error. The rejected write
  does not persist, the store stays open, and the write succeeds after space
  frees.
- **Changed: each store and vault guide names the optional peers of its
  entry.** Each guide has an install command for the peers that its entry
  loads. For example, `./local/store/web` and `./local/store/web-sqlite` need
  `idb`, and a bundler fails the app build without it.
- **Fixed: a group delete deletes the skipped sender keys.** The in-memory,
  key-value, and IndexedDB stores kept them after
  `deleteAllSenderKeysForGroup`. These keys decrypt skipped group messages.
  The stores now delete them together with the sender keys of the group. A
  group whose identifier starts with the identifier of the deleted group
  keeps its keys.
- **Fixed: sender keys no longer collide.** Group `a` with sender `b:c` and
  group `a:b` with sender `c` shared keys. In the in-memory and IndexedDB
  stores, they shared one sender key record. In IndexedDB, they also shared
  one skipped key. In database version 7, a sender key record has an array
  key of group, sender, and device. The key of a skipped key adds the index,
  and a group index finds the skipped keys of a group. The in-memory store
  keys both with JSON arrays.
- **Changed: IndexedDB version 7 deletes stored sender keys.** The upgrade
  deletes the version 6 sender key records and skipped keys. After the
  upgrade, each group needs a new sender key distribution before its messages
  decrypt. A late message for a deleted skipped key does not decrypt.
- **Fixed: `deleteAllSenderKeysForGroup` on the Expo store deletes the
  group's skipped message keys.** On a store from `expoStore()`, it deleted
  the group's sender keys and kept each skipped message key, which still
  decrypts its message after the group is gone.
- **Fixed: the Expo store keeps SESAME user records and device identity
  pins.** On a store from `expoStore()`, `setUserRecord` stored nothing, and
  `setDeviceRecord` stored only the session. A user or device with no session
  had no record, and `getDeviceRecord` returned the identity from the contact
  trust store, not the pin that was set. The store now returns each user and
  device that was set, with the pin that was set and the device's current
  session, if any. `setDeviceRecord` and `deleteDeviceRecord` change the
  record and its session together or not at all. `getAllUserIds` and
  `getSesameDeviceIds` list the users and devices that were set, as on the
  other stores.
- **Fixed: the Expo store keeps a registration ID that is set before the
  identity key.** On a store from `expoStore()`, `setLocalRegistrationId` did
  nothing until an identity key was stored.
- **Fixed: a client on the key-value store can send after it establishes a
  session.** `./local/store/key-value` (`./local/store/react-native` before
  the move) lost the session from each SESAME device record, so every send
  failed with `No active session`. It also returned the device identity pin as
  a plain object, not its bytes, after a reopen. The store now joins each
  device with the session under its session key, and it keeps the pin bytes.
- **Fixed: a client on the IndexedDB store can send after it establishes a
  session.** `./local/store/web` returned each SESAME device record with no
  session, so every send failed with `No active session`. `getUserRecord` and
  `getDeviceRecord` on the IndexedDB store, and `getUserRecord` on the
  in-memory store, now join each device with the session under its address,
  and the stored identity pin wins over one derived from the session. On the
  IndexedDB store, `setDeviceRecord` writes the device and its session in one
  transaction, and `deleteDeviceRecord` removes the session with the device.
- **Fixed: the in-memory store returns no session for a device whose session
  is deleted.** After `deleteSessionRecord`, `getDeviceRecord` and
  `getUserRecord` on `./local/store/memory` returned the session that
  `setDeviceRecord` stored earlier. The store now keeps each device without
  its session and joins the device with the session under its address, as
  the other stores do. `setDeviceRecord` rejects a session record that is not
  current, and `setUserRecord` stores no session.
- **Added: `./local/store/web-sqlite`, a web store on encrypted SQLite.**
  `webSqliteStore(options?)` opens an SDK-owned SQLite database in the origin
  private file system. The SQLite3 Multiple Ciphers Wasm engine runs in a
  dedicated module worker and encrypts the whole file. On first use the store
  creates the database key in the secret vault, by default IndexedDB in the
  same origin, then the file. Each open applies the SDK migrations.
  `resetWebSqliteStore(options?)` deletes the file, creates a new key, and
  opens an empty store. `createPreKeyMaintenanceStore` takes an open store.
  The tabs of an origin share the database, and the opens and resets of a
  name run one at a time across the tabs. A reset fails with `INVALID_STATE`
  while any tab has the store open. The page's Content Security Policy must
  allow `'wasm-unsafe-eval'` for the worker; without it, the open fails with
  `SQLITE_ENGINE_UNAVAILABLE`. A context without OPFS gets
  `OPFS_UNAVAILABLE`. The key in IndexedDB protects a copy of the database
  file; it is not an XSS defense.
- **Breaking: the SDK owns the Expo database.** `expoStore(options?)`
  opens an SDK-owned SQLCipher database in the `expo-sqlite` default
  directory. On first use it creates the database key in the secret vault
  (Expo SecureStore by default), then the file. Each open applies the SDK
  migrations. `ExpoSignalProtocolStore` has no public constructor, and
  `close()` closes the store. An open fails with `LOCAL_STORE_KEY_LOST` when
  the file exists and the vault holds no key for it. It fails with
  `INVALID_STATE` when a store of the process holds the same name, or when a
  newer SDK wrote the file. `createPreKeyMaintenanceStore` takes the open
  store. The options accept `encryptionAtRest: false`, which opens a
  plaintext database and does not use the vault. An open with the other
  setting than the one that created the file fails with
  `SqliteKeyMismatchError` (`KEY_STORAGE_ERROR`), not `LOCAL_STORE_KEY_LOST`.
  Keep application tables in a separate database file.
- **Breaking: `expoStore()` is now async.** It returns a promise of the open
  store. Replace `expoStore()` with `await expoStore()`.
  `ExpoSignalProtocolStoreFactoryOptions` is now `ExpoSignalProtocolStoreOptions`.
- **Breaking: the Expo module functions that exposed the database or its key
  are removed.** The `./local/store/expo` entry no longer exports
  `getKeyStorage`, `resetKeyStorage`, `getDatabaseKeyManager`,
  `resetDatabaseKeyManager`, `clearDatabaseKeyCache`, `getPrimaryIdentityKey`,
  or `getContactIdentity`. The `./local/store/expo/db` entry, with
  `configureSignalProtocolExpoDbBindings`,
  `resetSignalProtocolExpoDbBindings`, `getDrizzle`, `getRawDatabase`, and its
  tables, is removed. The `./local/store/expo/schema` entry is removed. The
  `drizzle-orm` peer dependency is removed.
- **Breaking: `ExpoSignalProtocolStore.getDatabaseKey()` is removed.** The
  database key stays in the secret vault, and the store does not return it.
- **Changed: `clearAllKeys` on the Expo store empties every table and keeps
  the database key.** The file stays open with the same key.
  `resetExpoStore(options?)` is the full teardown: it deletes the database
  file, creates a new key, and opens an empty store. It is the only way to
  open a store whose key is lost.
- **Added: `@open-e2ee/signal-protocol-sdk/local/vault/electron-safe-storage`.**
  `ElectronSafeStorageSignalProtocolSecretVault` is a
  `SignalProtocolLocalSecretVault` for the Electron main process. The app
  passes its own `safeStorage`, so the SDK does not import `electron`. The
  vault encrypts each secret with `safeStorage` and keeps only the ciphertexts
  in a file that the app names. It fails closed when async encryption is not
  available, on the Linux `basic_text` and `unknown` backends, and on Linux
  when a ciphertext does not start with `v11`. A `v10` ciphertext means that
  no secret service answered, so `safeStorage` used its fixed fallback key.
- **Added: the optional peer `better-sqlite3-multiple-ciphers` 13.0.3 or
  later.** The SQLite store for Node and Electron uses it. An app that does
  not use that store does not install it.
- **Breaking: the Node store is an SDK-owned SQLCipher database.**
  `nodeStore(options)` takes `{ directory, vault }` in place of the optional
  `{ dataDir }`, and opens an encrypted SQLite database on
  `better-sqlite3-multiple-ciphers` in `directory`. On first use it creates
  the database key in `vault`, then the file. The options also accept `name`,
  `encryptionAtRest: false`, and `logger`, as the Expo store does. It runs in
  Node and in the Electron main process; in Electron, pass the safeStorage
  vault. `NodeSignalProtocolStore` has no public constructor, and
  `NodeSignalProtocolStoreConfig` is now `NodeSignalProtocolStoreOptions`.
  `close()` closes the store. An open fails with `LOCAL_STORE_KEY_LOST` when
  the file exists and the vault holds no key for it, and with
  `INVALID_STATE` when a store of the process holds the same file or a newer
  SDK wrote it. The store does not read the files of the earlier Node store.
  Keep application tables in a separate database file.
- **Breaking: the `fs-native-extensions` peer dependency is removed.**
- **The Node store has one owner process.** An open store holds the owner
  lock `<name>.lock` beside the database until `close()`, and the operating
  system releases it when the process exits. An open or a reset in another
  process fails at once with `SqliteStoreInUseError` (`KEY_STORAGE_ERROR`),
  before it reads the vault or touches the file.
- **Added: `resetNodeStore(options)`, `createPreKeyMaintenanceStore(store)`,
  and `sqliteDatabaseKeySlot(path)` on `./local/store/node`.**
  `resetNodeStore` deletes the database file, creates a new key, and opens an
  empty store. `sqliteDatabaseKeySlot` names the vault slot of the key for a
  database path, so an app can move the key when it moves the directory.
- **Changed: the Node store has the semantics of the Expo store.** A user
  record is the aggregate of the user's sessions, so `setUserRecord` stores
  nothing. `setDeviceRecord` does not pin the identity key of a device,
  `setDeviceSession` does not require a registered device, and
  `setLocalRegistrationId` stores nothing before the identity key.
  `deleteAllSenderKeysForGroup` keeps the group's skipped sender keys.
- **The Expo store runs on a shared SQLite core.** The store's schema,
  queries, and transactions move from the Expo entry to an internal core that
  runs on any SQLite binding. Every statement and transaction on the
  database goes through one queue, so concurrent store calls no longer
  collide in `BEGIN` or `ROLLBACK`. A save that replaces a signed prekey with
  the same key ID now zeroes the private key that it replaces.
- **The Expo account wipe empties every SDK table.** `clearAllKeys` and
  `wipeAllSignalProtocolData` on the Expo store now empty every SDK table, as
  the web and Node stores do. This adds the metadata, sender keys, skipped
  sender keys, message records, profile keys, group master keys, group state
  cache, and auth credential cache, and for `clearAllKeys` the KEM one-time
  prekeys.
- **A bare React Native app can bundle the SDK.** The root entry no longer
  uses `export * as` to export the `safety`, `keys`, `encoding`, `blocking`,
  and `media` namespaces. `@react-native/babel-preset` has no transform for
  that syntax, so Metro in a bare React Native app rejected the whole bundle.
  The namespaces and their members do not change.
- **Added: `EncryptionErrorCode.SQLITE_ENGINE_UNAVAILABLE`,
  `EncryptionErrorCode.OPFS_UNAVAILABLE`, and
  `EncryptionErrorCode.OPFS_FILE_BUSY`.** The web SQLite store fails with
  these codes when its Wasm engine cannot load in its worker, when the browser context has no OPFS storage for it, or when it
  cannot open its database file this time, usually because another tab still
  holds the file. Retry after `OPFS_FILE_BUSY`; the file is unchanged. An
  exhaustive `switch` over `EncryptionErrorCode` needs the three new cases.
- **Changed: the package ships the SQLite3 Multiple Ciphers 2.5.1 Wasm
  engine.** `dist/local/store/sqlite/web/sqlite3mc/` holds `sqlite3.mjs` and
  `sqlite3.wasm` from the signed release, about 1.5 MB. `sqlite3.wasm` is
  unmodified. `sqlite3.mjs` carries two recorded patches, so a failed pool
  install never deletes the database files and a failed attach holds no file
  handle. Both files are pinned by sha256. Only the worker of
  `./local/store/web-sqlite` loads them. `THIRD_PARTY_NOTICES.md` lists their
  licenses.
- **Added: the bare React Native SQLite store at `./local/store/react-native`.**
  `reactNativeStore(options?)` opens an SDK-owned SQLCipher database on
  op-sqlite, with its key in the react-native-keychain vault by default, on
  the same SQLite core and with the same options, errors, and reset as
  `expoStore`. `resetReactNativeStore(options?)` deletes the database
  and opens an empty store, and `createPreKeyMaintenanceStore` takes the open
  store. `close()` checkpoints the write-ahead log into the database file
  before it closes the connection. The app turns on the op-sqlite SQLCipher build with
  `"op-sqlite": { "sqlcipher": true }` in its `package.json`. Without it, an
  encrypted open fails with `KEY_STORAGE_ERROR` before it creates a file.
  `@op-engineering/op-sqlite` 18.2.5 or later is an optional peer, and only
  this entry imports it.
- **Breaking: the own profile key lives in the application's secret vault.**
  The SDK no longer writes the profile key to `localStorage`, and it no longer
  picks a storage by platform. `getOwnProfileKey`, `setOwnProfileKey`,
  `getOrCreateOwnProfileKey`, `getOwnProfileKeyBase64`, and
  `rotateOwnProfileKey` take a `SignalProtocolLocalSecretVault` as their first
  argument. `updateEncryptedProfile` takes a `vault` parameter when it gets no
  `profileKey`. The vault holds the key as its raw 32 bytes under
  `signal_profile_key_v1`. To upgrade, pass the vault to each call. On Expo,
  use `ExpoSecureStoreSignalProtocolSecretVault` from
  `@open-e2ee/signal-protocol-sdk/local/vault/expo-secure-store`. Remove each
  use of `setProfileKeyStorage`, `getProfileKeyStorage`,
  `resetProfileKeyStorage`, `createMemoryStorage`, and `ProfileKeyStorage`.
  These exports are deleted.
- **Breaking: the device ID and the device-lifecycle state live in the
  application's secret vault.** `getDeviceId` and `preloadDeviceId` take the
  vault as their first argument. `DeviceLifecycleDeps` has a `vault` field in
  place of `secureStore`, and the `DeviceLifecycleSecureStore` type is
  deleted. The vault holds each value as UTF-8 text. To upgrade, pass the same
  vault to `DeviceLifecycleManager`, `getDeviceId`, and `preloadDeviceId`. The
  SDK does not read the plain SecureStore values that an earlier version
  wrote, so reset the device when you upgrade.
- **Breaking: a call without a vault throws `SECRET_VAULT_REQUIRED`.** Each
  function above, and the `DeviceLifecycleManager` constructor, throws an
  `EncryptionError` with the new code `EncryptionErrorCode.SECRET_VAULT_REQUIRED`
  when the vault is absent. The error context names the operation.
- **Breaking: the shared `./device` entries import no platform package.**
  `./device`, `./device/device-id`, and `./device/lifecycle` now load without
  Expo, React Native, or `react-native-device-info`. They take platform
  metadata as input, and they omit each field that the application does not
  supply. To upgrade:
  - Spread `getDeviceLifecyclePlatform()` into the `DeviceLifecycleManager`
    dependencies. `DeviceLifecycleDeps` extends the new
    `DeviceLifecyclePlatform` type: `generateDeviceName`,
    `getDeviceFingerprint`, `deviceType`, `platform`, `osVersion`, and
    `appVersion`, each optional. Without `generateDeviceName`, the device name
    is `Unknown Device`. Without `getDeviceFingerprint`, registration sends no
    `idfv` and does not reclaim a device.
  - Pass the same facts to `getLocalDeviceMetadata`, which now takes them as
    its argument.
  - Pass a `TransferDeviceInfo` to `generateTransferQRCode`,
    `prepareNewDeviceTransfer`, `createEmptyBackup`, `createDeviceBackup`, and
    `prepareOldDeviceTransferWithBackup`. Get it from
    `getTransferDeviceInfo()`, or pass `{}` to send no metadata. The QR code
    omits `deviceType` when the metadata has no platform, and
    `TransferQRCode.deviceType` is optional.
- **Added: `./device/react-native`.** It reads device metadata on bare React
  Native through `react-native` and `react-native-device-info`, and it reaches
  no Expo package. It exports `getDeviceMetadata`, `getTransferDeviceInfo`,
  and `getDeviceLifecyclePlatform`. Its lifecycle facts include a fingerprint
  from `getUniqueId()`.
- **Changed: `./device/expo` reads the lifecycle and transfer metadata.** It
  now imports `expo-device` too, and it adds `getTransferDeviceInfo` and
  `getDeviceLifecyclePlatform`. Expo has no device fingerprint without another
  package, so its lifecycle facts have no `getDeviceFingerprint`. Supply one
  to keep reclaim detection.
- **Added: a secret vault for bare React Native apps.**
  `ReactNativeKeychainSignalProtocolSecretVault` from
  `@open-e2ee/signal-protocol-sdk/local/vault/react-native-keychain` stores
  vault secrets with `react-native-keychain`, a new optional peer at 10.0.0 or
  later. The adapter sets fixed options that the app cannot change: iOS
  `AFTER_FIRST_UNLOCK_THIS_DEVICE_ONLY`, Android `AES_GCM_NO_AUTH` storage at
  the `SECURE_SOFTWARE` level, and no `cloudSync` key. The secret stays on the
  device. react-native-keychain 10.0.0 turns iCloud sync on for any
  `cloudSync` value, `false` included, so the adapter never sends that key.
- **Breaking: React Native and Expo apps must install a global random
  source.** The SDK reads random bytes on React Native only from the global
  `crypto.getRandomValues`. It no longer uses `expo-crypto` for random bytes,
  and the key-value store no longer imports `expo-crypto`. To
  upgrade, install `react-native-get-random-values` 2.x or
  `react-native-quick-crypto`, and load it before the first SDK call.
  Without a global source, the SDK throws `SecureRandomUnavailableError`.
- Added: `SecureRandomUnavailableError`, with the code
  `SECURE_RANDOM_UNAVAILABLE` and the guard `isSecureRandomUnavailableError`,
  exported from `/types`. The SDK throws it when the runtime has no
  cryptographically secure random source.
- **Breaking: `getGroupServiceIds` on the in-memory relay is now
  asynchronous.** It returns a `Promise`. To upgrade, `await` each call.
- **Breaking: `GroupAuthorizationServerEngine` takes its runtime as a
  required argument.** The engine no longer picks a host random source, so a
  server bundle of the engine reaches no client platform seam. To upgrade,
  pass a `GroupServerEngineRuntime` with `now` and `randomBytes` as the second
  constructor argument. The in-memory relay's
  `InMemoryGroupAuthorizationServer` still supplies its own runtime.
- Fixed: the username discriminator had a small bias toward low values. The
  SDK now draws it with rejection sampling, so each value in the range has
  the same probability.
- **Fixed: on React Native, the hosted Relay socket did not open.** The SDK
  built the socket URL with the `protocol` setter of `URL`, and the React
  Native `URL` has no setters. Now the SDK builds the URL itself.
- **Fixed: on React Native, `isVerifyUrl`, `parseVerifyUrl`, and
  `parseProvisioningQR` accepted a lookalike custom-scheme link,** such as
  `signalprotocol://verify-evil`. The React Native `URL` reads no host or path
  for a custom scheme. The SDK now parses these links, the relay connection
  URL, Web Push endpoints, object store URLs, and TUS upload locations with
  its own parser, which gives the same result on every runtime.
- **Changed: the SDK rejects a URL that is not in a canonical form.** Upgrade
  step: give each URL as ASCII, without credentials, a fragment, an empty
  query (`?` with nothing after it), or a `.` or `..` path segment. Write the
  host in the form that a WHATWG `URL` gives, and do not use an `xn--` label,
  an IPv4 address in a short or hexadecimal form, or an IPv6 address in a
  non-compressed form. Do not write a port with a leading zero. Percent-encode
  a space, a non-ASCII character, and a `'` in a query. This applies to the
  verification and provisioning links and their `VerifyLinkConfig` and link
  prefix, the relay connection URL, Web Push endpoints, and object store
  upload and download URLs. A TUS server must return a `Location` that is an
  absolute URL, a path that starts with `/`, or a relative path, not a
  network-path reference that starts with `//`. A query value that is not
  valid UTF-8 now makes a verification or provisioning link invalid.
- **Changed: `encryptFile` and `decryptFile` throw an `EncryptionError` with
  the new code `BINARY_BLOB_UNAVAILABLE` when the runtime's `Blob` cannot hold
  bytes.** The React Native `Blob` rejects binary parts and has no
  `arrayBuffer()` or `text()`, so these methods cannot work there. They now
  throw before they touch the session, so the key message stays unconsumed.
  Upgrade step: on React Native, use `streamingEncrypt` and `streamingDecrypt`
  from `@open-e2ee/signal-protocol-sdk/files`.
- **Fixed: on a React Native runtime without `Buffer`, `TextDecoder`, or
  `structuredClone`, the stores, the relay clients, and message decoding
  failed.** These parts now use the SDK's base64, UTF-8, and clone functions.
  UTF-8 decoding uses the runtime's `TextDecoder` only when it passes a
  conformance check, and a built-in WHATWG decoder otherwise, so invalid
  UTF-8 gives the same result on every runtime.
- Changed: the Expo store models decode base64 strictly. A stored key that is
  not padded standard base64 with zero trailing bits now fails to load.
  Before, the models skipped invalid characters. The SDK writes only this
  form, so the change affects only a row that was changed by hand.
- Fixed: the Convex relay's `subscribe` threw in a browser that loads the SDK
  without a bundler `define`, where there is no `process` global. It now
  falls back to polling there, as it does when `EXPO_PUBLIC_CONVEX_URL` is not
  set.
- **Fixed: the Expo store's `getDetailedStats()` and full data wipe now
  complete.** Before, both read or deleted a table that does not exist, so
  `getDetailedStats()` failed and the wipe (`wipeAllSignalProtocolData()` on
  the store from `getKeyStorage()`) rolled back. The `users` count is now the
  number of distinct users that have a session.
- Fixed: on the Expo store, a signed prekey that reuses the ID of a replaced
  signed prekey is now the current signed prekey. Before, the store kept the
  replaced mark, so `getEcSignedPreKey()` returned `null`.
- Fixed: `createPreKeyMaintenanceStore().cullReplacedPreKeys()` on the Expo
  store now culls the four prekey tables one at a time. Before, it opened
  four transactions at the same time on one connection, and the cull failed
  with "cannot start a transaction within a transaction".
- **Breaking: the key-value store moves to `./local/store/key-value`.** In
  7.2.0, `./local/store/react-native` exported it. Change each import of the
  key-value store from `@open-e2ee/signal-protocol-sdk/local/store/react-native`
  to `@open-e2ee/signal-protocol-sdk/local/store/key-value`.
  `./local/store/react-native` now exports the bare React Native SQLite
  store.
- **Breaking: the key-value store names drop the React Native prefix.** The
  store works over any key-value backend, so its names do not name a
  platform. Change each name:
  - `ReactNativeSignalProtocolStore` → `KeyValueSignalProtocolStore`
  - `reactNativeStore` → `keyValueStore`
  - `ReactNativeStoreFactoryOptions` → `KeyValueSignalProtocolStoreOptions`,
    which `create`, `reset`, and `keyValueStore` all take
  - `ReactNativeKeyValueStorage` → `KeyValueStorage`
  - `ReactNativeKeyValueOperation` → `KeyValueOperation`
- **Breaking: the key-value store keeps its value key in a secret vault.**
  Before, the store wrote its 32-byte value key into the same key-value
  backend as the data it encrypted, under `@signal:databaseKey`, and logged a
  warning. Pass a `SignalProtocolLocalSecretVault` backed by the platform
  keychain or keystore, such as `ReactNativeKeychainSignalProtocolSecretVault`,
  as `vault` to `create`, `reset`, or `keyValueStore`. Without a vault,
  each of them throws `SECRET_VAULT_REQUIRED`. To keep
  existing data, before the first open on this version, read the base64 value
  of `@signal:databaseKey` from your backend, write its decoded bytes to the
  vault under `signal_key_value_encryption_key`, and remove
  `@signal:databaseKey` from the backend. The key-value store guide describes
  key custody.
- **Breaking: a lost value key is an error, not a new key.** When the backend
  holds store data and the vault holds no key, `create` rejects with an
  `EncryptionError` whose code is the new `LOCAL_STORE_KEY_LOST`, and it
  changes nothing. Before, a missing key gave a new key that could not read
  the old data. Catch the code, and then restore the vault entry or call
  `KeyValueSignalProtocolStore.reset({ storage, vault })`. `reset` deletes
  every store record, and then makes a new key. If the process stops between
  the two steps, the next `create` opens an empty store.
- **Breaking: `createReferenceReactNativeBackend` is no longer exported.** It
  is now test code of the SDK. To verify your backend, use
  `assertBackendConformance` or `runBackendConformance`, which stay exported.
  To get an in-memory backend for your own tests, write one that passes the
  kit.
- Added: `./local/store/key-value/realm` with `createRealmKeyValueBackend`, a
  key-value backend over an open Realm. The SDK does not import `realm` and
  does not declare it as a dependency or peer. Your application installs
  `realm` and adds `realmKeyValueSchema` to its schema list. Each store write
  runs in one `realm.write` transaction. The adapter is tested with the
  conformance kit on realm 20.2.0 in Node. Realm has no maintainer since
  2025-09-30. The key-value store guide lists its known build issues.
- Added: `createTransactionalKeyValueBackend` in `./local/store/key-value`,
  with the types `TransactionalKeyValueEngine`, `KeyValueTransaction`, and
  `KeyValueReader`. It makes a key-value backend from an engine's own
  transaction and a synchronous handle with `get`, `set`, `delete`, and
  `keysWithPrefix`. The SDK applies each `atomicWrite` batch inside that
  transaction, so a backend does not copy the batch rules. The Realm backend
  uses it. To upgrade a backend that you wrote for an engine with
  transactions, replace its `atomicWrite` code with this function and run the
  conformance kit again. The key-value store guide has an op-sqlite sketch.
- **Fixed: `stop()` resolved while a relay delivery or a retry request was in
  progress.** The decrypt then went on after logout and wrote to the store
  after the app could have closed it. `stop()` now resolves only after the SDK
  work of the deliveries, retry requests, and receipt sends in progress
  finishes. It does not wait for app hooks, so a hook can await `stop()`. This
  includes the session hooks of a resend for a retry request, when the resend
  sets up a session with a new or stale device. Another resend to the same
  user that waits while such a hook runs stops waiting and sends nothing, and
  its message record stays for the next retry request. When a hook returns
  after `stop()`, the SDK drops the work after the hook and writes nothing
  more. The relay delivers the envelope again after the next start, and the
  hook gets the plaintext again. A delivery that fails is logged and no longer
  rejects as an unhandled promise.
- **Breaking: the managed Signal Protocol Relay hosts use the lane tokens.**
  The SDK pins `https://sandbox.relay.open-e2ee.dev`,
  `https://stage.relay.open-e2ee.dev`, and
  `https://stage-sandbox.relay.open-e2ee.dev`.
  `https://relay.open-e2ee.dev` does not change. A connection URL on
  `development.relay.open-e2ee.dev`, `staging.relay.open-e2ee.dev`, or
  `staging-customer-development.relay.open-e2ee.dev` is now invalid. Copy the
  connection URL from the console again.
- **Breaking: the Signal Protocol Relay API path is `/signal/v1/*`.** A
  connection URL is now `https://<host>/signal/v1/connection/<key>`, and the
  SDK sends each request under `/signal/v1/`. The SDK rejects a connection URL
  with the old `/v1/connection/` path, and a connection document whose
  `protocolEndpoint` is not `<origin>/signal/v1`.
- **Breaking: the developer environment kind is `sandbox`.** The
  `environment` of a hosted Relay connection is now `'sandbox' |
  'production'`. The SDK rejects a connection document that names the old
  kind. The Relay gives a sandbox publishable key the prefix `pk_sandbox_`.

- **A bare React Native example.** `examples/react-native` runs the encrypted
  exchange in a React Native 0.87.1 app with no Expo module. Alice uses
  `reactNativeStore()` on the op-sqlite SQLCipher build, with the database key
  in `react-native-keychain`. On each launch, the app logs the SQLCipher
  version and the first 16 bytes of the SDK database file, and requires that a
  wrong key fails the open of an SDK database. The run fails when the build has
  no SQLCipher or when the file starts with the plaintext SQLite header. CI
  builds the release APK and runs it twice on an Android emulator, and requires
  these lines on each run. On every change, CI also builds the example's Metro
  release bundle with the packed SDK and the stock Babel preset, and compiles
  it with Hermes.

- **The Expo example checks that SQLCipher encrypts its database.** On each launch,
  `examples/expo` logs the SQLCipher version and the first 16 bytes of the SDK
  database file. The run fails when the build has no SQLCipher or when the
  file starts with the plaintext SQLite header. The Android emulator job
  requires both lines on each run. The example now depends on
  `expo-file-system` to read the file.

## 7.2.0

- **Fixed: a send now reaches every device that the relay lists for the
  recipient.** Before, after one device of the recipient had a session, a
  send used only the devices that the sender already knew. A device that the
  recipient linked later received nothing. When the first message came from
  one device of the recipient, the reply went only to that device. A device
  that the relay removed still got a copy. Now a 1:1 send, and a sender key
  distribution to a group member, reads the recipient's device list from the
  relay (`getActiveDevices`) when the last read is older than 60 s. The send
  then makes a session for each listed device that has none, and removes each
  local device that the relay does not list. Inside the 60 s window, a send
  makes no relay read. If the read fails and a session exists, the send goes
  to the known devices and the next send reads the list again.
  `SendResult.recipientDeviceCount` now counts the devices that the relay
  accepted a copy for.
- Changed: the relay's `getActiveDevices` now decides which devices a 1:1
  send goes to, also after a manual `establishSession`. On the in-memory
  relay, call `registerDevice` for each recipient device, as the examples
  do. A device that is not registered gets no copy, and a send to a
  recipient with no registered device fails with `RECIPIENT_NOT_REGISTERED`.
- **Changed: the React Native and Expo peer ranges have no upper bound.**
  Each peer now has only a lower bound. The bounds are `react-native` 0.83.6
  and `expo` 55.0.27, or later versions. The Expo module bounds are
  `expo-constants` 55.0.7, `expo-crypto` 55.0.16, and `expo-device` 55.0.15,
  or later versions. The `expo-secure-store` bound is 55.0.15 and the
  `expo-sqlite` bound is 55.0.17, or later versions. Before, a project on
  React Native 0.84, Expo SDK 56, or a later line got `ERESOLVE` from
  `npm install`. The README lists the versions that CI installs, bundles, and
  runs on an Android emulator.
- **Changed: every other peer range has a lower bound only.** A new major
  release of a peer now installs. The `react` peer changes from `^19.0.0` to
  `>=19.0.0`, `convex` from `^1.42.1` to `>=1.42.1`, `idb` from `^8.0.3` to
  `>=8.0.3`, and `react-native-device-info` from `^15.0.1` to `>=15.0.1`. The
  `fs-native-extensions` peer changes from the exact `1.2.7` to `>=1.2.7`.
  Version 1.5.1 passes the Node store checks on Node.js 22 and 26. The
  `drizzle-orm` peer changes from `^0.45.1` to `>=0.45.1`, and the
  `@convex-dev/r2` peer from `^0.10.2` to `>=0.10.2`. A weekly check installs
  the latest and next release of each peer against the SDK. CONTRIBUTING.md
  states the range rules.
- Changed: the Expo example uses Expo SDK 57, React Native 0.86.3, and
  React 19.2.3.
- Fixed: the Drizzle migrations of the Expo example did not build the store
  schema of the SDK. On a device, the first sync failed with
  `no such column: instance_id`. The new migration
  `0003_kyber_prekey_instance` adds `kyber_prekeys.instance_id` and
  `kyber_prekey_used.kyber_prekey_row_id`, and it keeps the existing rows.
  It also marks each earlier current Kyber prekey as replaced, so that each
  identity has one current Kyber prekey. The Expo bundle check in CI now
  fails when the example migrations do not build the packed SDK schema.
- Fixed: `useKeyRotation` threw a `TypeError` on the first app state change
  when `AppState.currentState` was `null`. React Native keeps it `null` when
  its native AppState module is not available. Now the hook rotates only
  after the app returns from `background` or `inactive`. The `currentState`
  property of `RelayLifecycleAppState` now accepts `null` and `undefined`,
  as the React Native 0.87 types declare. The SDK source now typechecks
  against those types.
- Fixed: the bare React Native store documentation said that the store needs
  a Web Crypto polyfill. It does not. AES-256-GCM uses the bundled Noble
  implementation when `crypto.subtle` is absent. The store does need
  `expo-crypto`, so a bare application must install Expo modules.

## 7.1.0

- **New: `watch()` registers a presence watch and receives pushed updates.**
  On the mailbox socket, `watch()` now sends one `presence-watch` request for
  the first 16 watched accounts. It sends the request when the socket
  connects, at each change of that set, and again every 120 s
  (`PRESENCE_WATCH_RENEWAL_MILLISECONDS`). The answer is the current presence
  of those accounts. After that, the Signal Protocol Relay pushes a
  `presence-update` frame for each change, and `watch()` calls the listener
  as it does for a changed read. The 30 s poll now reads only the accounts
  past the first 16. After a watch fails, or has no answer in 10 s, the poll
  reads every account every 30 s, and the watch tries again 120 s later. A
  new presence key from `grant()` for a watched account sends the watch
  again. A malformed `presence-update` frame reconnects the socket. The wake
  client and the HTTP carrier have no watch. A Relay without
  `presence-watch` closes the socket with 1008. The client then reads after
  30 s and tries the watch again after 120 s.

## 7.0.0

- **Breaking: 1:1 content can carry the profile key, with
  `hosted.profileKeys`.** Give `createHostedSignalProtocolClient` a
  `HostedRelayProfileKeys` object: a `getOwnProfileKey()` function and a
  `contacts` store. Each 1:1 DataMessage then carries the account's profile
  key in the Signal `DataMessage.profileKey` field, inside the encrypted
  content. Before a 1:1 string or byte send to a contact that does not have
  the current key, the SDK sends one `PROFILE_KEY_UPDATE` DataMessage (flag
  4). The receiving SDK keeps the key with `storeReceivedProfileKey`, derives
  the contact's presence key, and calls `grant()`. It gives a key update to no
  application hook. The SDK calls `accessKey()` when the socket connects and
  when the profile key changes, so a rotation revokes the old presence key and
  the next message delivers the new one. The app writes no key code. No key
  goes in a field that the Relay can read: the profile key goes only in
  encrypted content, and the presence key goes only in the `presence-key` and
  `presence-read` frames. Group messages do not carry the key. Each device of
  an account must return the same profile key. A 6.0.x receiver does not know
  the key update and gives it to `onMessageDecrypted`. Update all clients to
  7.0.0 before you set `hosted.profileKeys`.

- **New: hosted presence with `hostedRelayPresence(client)`.** It has
  `policy()`, `setting()`, `setVisibility()`, `read()`, and `watch()`. Each
  request is one versioned frame on the mailbox socket. Its answer comes back
  on the same socket. One read frame carries at most 100 accounts, and
  `read()` splits a longer list. A null result hides why the account has no
  presence.

- **New: `HostedRelayPresenceError`.** Its `code` is the Signal Protocol
  Relay's own code, for example `PRESENCE_SETTING_FORCED` or `QUOTA_EXCEEDED`.
  The SDK adds the codes `NOT_CONNECTED`, `BUSY`, `TIMEOUT`, and
  `FRAME_REJECTED` too. With code 1008, a Signal Protocol Relay without
  presence frames closes the socket. Each pending request then fails with
  `FRAME_REJECTED`, and the subscription reconnects.

- **New: `watch()` polls every 30 s in the foreground.** It reads when the
  socket connects and then every 30 s. It calls the listener only on a change.
  The poll stops while the socket is down. With `bindRelayLifecycle`, the
  socket closes in the background, so the poll stops there too. On web, a
  hidden tab continues to poll.

- **No heartbeat.** The SDK sends no presence heartbeat and reports no
  presence state. The Signal Protocol Relay records the socket edges.

- **New: the presence key, with `accessKey()` and `grant()`.**
  `accessKey(profileKey)` derives a 16-byte key from the 32-byte profile key.
  It uses HKDF-SHA-256 with an empty salt and the info
  `open-e2ee-presence-key-v1`. It registers the key and returns it as 22
  base64url characters. A new key revokes the old one.
  `grant(account, presenceKey)` keeps a contact's key for `read()`.

- **New: `hostedRelayWakePresence(client)` for a client with no socket.** A
  wake client has no mailbox subscription. It runs in a push handler or a
  background task. Its presence has the same members without `watch()`. Each
  request is one authenticated `POST /v1/signal/presence`. Neither carrier
  falls back to the other.

## 6.0.0

- **Breaking: the `SignalProtocolRelayServer` contract requires the relay
  connection state.** `SignalProtocolClient` gains the `relayConnectionState`
  getter and `subscribeRelayConnectionState(listener)`, which returns an
  `Unsubscribe`. The `RelayConnectionState` type has a `state` (`stopped`,
  `connecting`, `connected`, or `reconnecting`), a `since` time, and on
  `reconnecting` a `reason` (`handshake`, `protocol`, `closed`, `error`,
  `frame`, `authentication`, or `silent`). The reason names the site that
  failed, never an error message. The state reads `stopped` before
  `startRelaySubscription()` and after `stopRelaySubscription()`. A token
  renewal emits nothing unless its new socket fails, and the same value never
  emits twice. `SignalProtocolRelayServer` requires both members, so a custom
  adapter must implement them. The memory and Convex adapters report
  `connected` and `stopped` only. The state is local to this device and is not
  presence.

- **New: `useRelayConnectionState` and `useRelayLifecycle` hooks, and
  `bindRelayLifecycle`.** `useRelayConnectionState({ signal })` gives the
  state to a component for a local indicator. `bindRelayLifecycle(signal,
  appState, { keepOpenInBackground })` from `./client` takes an object with the
  shape of React Native's `AppState`, so the client entry imports no
  react-native. `useRelayLifecycle({ signal, keepOpenInBackground })` from
  `./hooks` passes `AppState` to it and does nothing on web.

- **Behavior change: the lifecycle binding closes the socket in the
  background.** With `bindRelayLifecycle` or `useRelayLifecycle`, `background`
  calls `stopRelaySubscription()`, which closes the socket with code 1000.
  `active` starts the subscription again after that stop, and the Relay
  replays retained messages over the new socket. `inactive` changes nothing,
  and there is no grace delay. A stop that the app made stays in effect.
  `keepOpenInBackground: true` keeps the socket open, for example while an
  Android foreground service runs.

- **Behavior change: the hosted subscription gives up on a silent socket at
  60 s.** The ping watchdog reconnects 60 s after the open or after the last
  answered ping, not 90 s. The Relay closes a silent socket at 75 s, so the
  client now gives up first.

## 5.0.0

- **Breaking: one rotation entry point publishes every due prekey in one
  publication.** `SignalProtocolClient.rotatePreKeys()` replaces
  `rotateEcSignedPreKey()` and `rotateKyberPreKey()`. It reads the prekey
  inventory once per identity type, decides which keys are due (the EC signed
  prekey and the Kyber last-resort prekey by the 2-day rule, the one-time sets
  by the refill threshold of 10), and publishes every due key in one
  `uploadPreKeys` call. It returns a `PreKeyRotationResult`
  (`signedRotated`, `kyberRotated`, `oneTimeReplenished`, `errors`).
  `rotateKeysHeadless` and `useKeyRotation` call the same entry point;
  `HeadlessRotationResult` is gone. The relay contract gains
  `publishPlannedPreKeys(userId, deviceId, plan, identityType?)` with the
  `PreKeyPublicationPlan` type: the adapter reads the inventory, the plan
  decides the uploads, and an empty plan publishes nothing. The
  `SignalProtocolRelayServer` methods `uploadEcSignedPreKey` and
  `uploadKemLastResortPreKey`, the Convex mutations of the same names, the
  `EcSignedPreKeyUpload` and `KemLastResortPreKeyUpload` types, and the
  `rotateEcSignedPreKeyCore`, `rotateKyberPreKeyCore`, and
  `replenishOneTimePreKeysCore` functions are gone. `checkRotationNeeded` and
  the pre-send `ensurePreKeysValid` check read the inventory once. On the
  hosted transport a rotation with nothing due makes one HTTP call (the status
  read) and a rotation that publishes makes three (status, publish, status);
  before, a full rotation made eight and a check with nothing due made two.

- **A one-time prekey refill keeps retained private keys and refills each
  set on its own count.** `replenishOneTimePreKeysCore` and the server sync
  share one refill owner, `client/one-time-prekey-refill.ts`. It checks the EC
  and KEM server counts separately against the threshold of 10, marks a set
  replaced only when it makes a new batch of that type, starts every batch at
  the highest local ID plus one (retained replaced keys included), and returns
  both batches for one upload. Before, the rotation core checked only the EC
  count, marked both sets replaced, uploaded no KEM keys, and generated every
  EC batch at IDs 0 to 99, so each refill overwrote the private keys that a
  peer could still address. The rotation cores and `rotateKeysHeadless`
  default to the active identity types (`['aci']` unless PNI keys are
  enabled) instead of `['aci', 'pni']`. The Expo store rejects a one-time
  prekey that reuses a stored ID instead of overwriting the row.

- **Breaking: the SDK reports no device presence.** `useConnectionPresence`
  and its `hooks/use-connection-presence` subpath, the
  `SignalProtocolRelayServer` methods `markDeviceConnected`,
  `markDeviceDisconnected`, and `heartbeat`, and the `active` and `lastSeen`
  device fields are gone from every adapter, together with the Convex
  `deviceHeartbeats` table and the `presenceHeartbeat` function. The hosted
  mailbox subscription sends the text frame `ping` every 30 seconds while its
  socket is open, treats the Relay's `pong` as no frame, and reconnects
  through its normal path after two unanswered pings. `getDevices` on the
  hosted transport carries `lastSeenAt` (Unix milliseconds, or `null` before
  the first connection) for the caller's own account.

- **An ephemeral send no longer reports an offline recipient.** The Relay
  accepts an `ephemeral` delivery to a device with no live connection and
  drops it, with the same response as an online delivery. The hosted
  anonymous delivery path no longer classifies `RECIPIENT_OFFLINE`; a Relay
  that still answers it surfaces as `DELIVERY_FAILED`. No sender can learn
  whether a recipient is connected from a delivery response.

- **Documentation names `DefaultSignalProtocolClient` for class-only members.**
  JSDoc examples in the client configuration, the `Remote object storage not
  configured` error text, and the media, safety, and package-surface documents
  name `DefaultSignalProtocolClient` for `create`, `verify`, `media`, `receive`,
  and `processIncomingEnvelopes`, which exist on the class and not on the
  `SignalProtocolClient` interface. The generated API reference follows.

- **A durable hosted send repeats one uncertain delivery.** When the Relay
  answers a `user-visible` or `background-sync` delivery with 503
  `DELIVERY_UNCERTAIN`, the hosted transport and the anonymous delivery path
  post the identical request once more under the same message identifier
  before the error reaches the caller. An `ephemeral` delivery is not
  repeated. `HostedRelayHttpError` carries the Relay's `retryable` hint, and
  its constructor takes `{ data, retryable }` options in place of a bare
  `data` argument.

## 4.0.0

- **Breaking: interfaces no longer carry an `I` prefix.** Every exported
  contract uses its bare name: `SignalProtocolClient`,
  `SignalProtocolRelayServer`, `ProtocolStore`, `SessionStore`,
  `SenderKeyStore`, `IdentityKeyStore`, `KemPreKeyStore`,
  `SignalProtocolLocalStore`, `Logger`, `GroupServer`, `ProvisioningService`,
  `KeyRotationService`, and the rest. Where the bare
  name belonged to the sole implementing class, the class is now
  `DefaultSignalProtocolClient` or `DefaultSignalProtocolManager`, and the
  low-level constructor call is `DefaultSignalProtocolClient.create()`.
  `createSignalProtocolClient()` and `createHostedSignalProtocolClient()` are
  unchanged. The device-lifecycle contracts are `DeviceLifecycleSecureStore`,
  `DeviceLifecycleConvexClient`, `KeyStorageOps`, and `DeviceLifecycleLogger`,
  so the lifecycle logger no longer shares a name with the SDK `Logger`.

## 3.0.0

- **Breaking: the SDK is dual-licensed under MIT or Apache-2.0.** The package
  `license` is `(MIT OR Apache-2.0)`. `LICENSE` states the grant, and
  `LICENSE-MIT` and `LICENSE-APACHE` carry the full texts. The
  AGPL-3.0-or-later terms and the commercial license (`COMMERCIAL.md`) are
  withdrawn.
- **Breaking: the Convex relay server is no longer published.** The
  `./remote/relay/convex` and `./convex.config` entry points, the
  `remote/relay/convex/**` sources, and the `@convex-dev/rate-limiter` peer
  dependency leave the public package. Production clients connect to the
  OpenE2EE Signal Protocol Relay through `createHostedSignalProtocolClient()`,
  development uses `inMemoryRelay()`, and any backend can implement
  `ISignalProtocolRelayServer`. The Convex R2 object store
  (`./remote/object-store/convex-r2`) stays.
- **Breaking: `./device/expo-metadata` is now `./device/expo`.** The Expo
  device metadata module moved to `device/expo/index.ts`. The duplicate
  `./remote/relay/convex/relay` entry point is removed with the Convex relay.
- **The hosted relay is the OpenE2EE Signal Protocol Relay.** Documentation,
  doc comments, and user-visible error messages say `OpenE2EE Signal Protocol
  Relay`, or `Signal Protocol Relay` as the short form, instead of
  `OpenE2EE Relay`, `Managed Relay`, or `hosted Relay`. Code that matched
  the old error message text must match the new text. Domain-separation labels
  are unchanged.
- Correct the browser and Expo example package integrity. Both lockfiles pin
  the public tarball, and release verification packs the public candidate
  under the publication runtime and checks both pins before an export.
- **Breaking: the Kyber last-resort prekey takes the next key id on every
  rotation.** Rotation, prekey regeneration, and the local-only rotation path
  previously regenerated the key under id 1, which the local store now refuses
  because it retains replaced keys under their ids for in-flight PQXDH
  messages. Only a complete key reset starts at id 1 again. The
  `KemLastResortPreKeyUpload` key id is no longer fixed at 1.
- **Breaking: Node.js 22.12 is the minimum supported runtime.** Node.js 18 and
  20 have reached end of life, the S3 object store dependencies require Node.js
  20 or later, and the committed lockfile installs with npm 11. The Node store
  authority checks run on Node.js 22 and 26.

- **Breaking: hosted mailbox subscriptions deliver from the socket.** A
  `durable-message` frame carries the envelope, and the subscription hands it
  to the receive handler without a pull. Acknowledgments travel over the same
  socket as one `acknowledge` frame per delivered batch, bounded at one hundred
  message ids. The HTTP pull remains for recovery: once per reconnect attempt,
  after a handler failure, and after a full recovery page. The HTTP
  acknowledgment remains for the push-wake path and for a batch whose socket
  closed before its acknowledgment left. Relay must reply `acknowledged`
  without re-sending pending messages.

- **Hosted group transport and issuer authority.**
  Clients create encrypted groups, invite members, synchronize revisions, and
  distribute sender keys through Relay. Long-lived clients refresh signed
  authority. Cached endorsements bind to their issuer, and issuance cannot
  exceed the issuer's expiry. Self-hosted trust remains explicit.

- **Interrupted receives preserve an encrypted device-local receipt.** Receipt
  persistence shares the transaction that advances cryptographic state.
  Retries recover application handling after a restart without decrypting the
  same envelope twice. Acknowledgment follows successful application handling.

- **Breaking: endorsement cache entries include their public issuer key.**
  Custom stores must preserve that key with each entry. The `groups/server`
  entry point exposes the existing group authorization engine for Relay hosts.

- **Hosted mailbox subscriptions stop dispatch after unsubscribe.** Polling
  waits for each asynchronous message handler before the next envelope, batch
  completion, and next poll. A handler failure closes the batch and leaves
  unacknowledged envelopes available for retry.

- **Breaking: Relay adapters implement `getPreKeyInventory`.** Prekey
  synchronization reads both signed-key records and both one-time-key counts
  through one operation. The Signal Protocol Relay uses one status request per
  decision. Inventory is not a reservation or cache. Canonical identity checks and fresh replenishment
  checks remain separate.

## 2.0.2

- Correct the browser and Expo example package integrity for the release environment.
- Check example pins before publication and publish the checked tarball.
  This release changes package metadata and publication checks.

## 2.0.1

- Select secure randomness for browsers, Node, and Expo through package imports.
  ML-KEM receives explicit random input on Hermes.
  React Native uses the application's Web Crypto provider before loading Expo crypto.
- Use Noble AES when the runtime has no Web Crypto implementation.
- Export the metadata table required by Expo storage. Read recipient identities
  with the column names returned by SQLite.
- Keep in-memory relay message identifiers unique across resets and restarts.
  Persistent clients no longer discard new replies as duplicate deliveries.
- Add runnable browser and Expo examples, including encrypted replies and
  SQLCipher persistence. Explain private testing and public verification.

## 2.0.0

- Six Jazzer.js targets run for 150 seconds each on Ubuntu 24.04.
  The previous runner selected coverage reporting instead of fuzzing.

- **Hosted control messages accept an omitted send identifier.**
  One generated UUID survives token retries.

- **Explicit account recovery bypasses stored sessions.**
  The SDK requests a recovery assertion.

- **Update the Noble dependencies.** Ciphers, curves, and hashes use 2.4.0.
  Post-quantum uses 0.7.1.

- **Breaking: Hosted Relay setup now uses one environment-scoped public
  connection URL.** The SDK resolves the exact protocol endpoint and
  publishable key from that URL, rejects project or environment mismatches
  before it creates identity state, and supports the non-streaming Fetch
  responses used by React Native and Expo. Applications no longer select a
  Relay hostname or pair it with a second public value.

- **Hosted encrypted attachment uploads preserve broker-signed headers.** The
  default Fetch adapter no longer adds a second case-variant `Content-Type`
  header that can invalidate a presigned upload request.

- **Breaking: the hosted client now owns its authenticated Relay transport.**
  Applications supply one environment-scoped Relay URL, local storage, and an
  identity-assertion callback. The SDK registers or resumes the device, renews
  short-lived tokens with device-key proof, maintains prekeys, and performs
  direct delivery, mailbox, push, and encrypted-object operations without
  application-supplied hosted adapters. Encrypted-object upload requests now
  require the SHA-256 digest of the exact bytes.

- **Breaking: Managed Relay adapters no longer accept certificate roots.** The
  SDK compiles separate customer Development, customer Production, and internal
  Staging fixture roots. It selects one profile from the exact
  environment-scoped connection origin. Bootstrap data and application adapters
  cannot replace hosted trust. Self-hosted Relay trust remains explicit and
  separate.

- **Hosted Relay push registration now declares the device platform and one
  authorized notification profile.** Android and Web registrations accept
  background wakes or generic visible alerts. iOS also accepts the
  Notification Service Extension profile. The SDK rejects invalid
  provider-platform pairs before transport. Apple notification filtering stays
  unavailable until signed physical-device verification passes. Push remains a
  best-effort wake; authenticated Relay mailbox pull remains delivery.

- **Breaking: Relay envelopes use one required delivery class.**
  `user-visible` persists and can request a generic alert, `background-sync`
  persists without a visible alert, and `ephemeral` is online-only and never
  enters an offline mailbox. The SDK infers the class for standard chat work.
  The independent `urgent` and `ephemeral` booleans no longer exist. Relay
  adapters that cannot prove live transient acceptance reject ephemeral work
  instead of reporting false delivery or retaining typing state.

  Convex validates stored component documents before it deploys the new
  schema. Every 1.x `messages` row lacks the required class, so a 2.0 deploy
  requires an empty component mailbox. Stop sends and let retention drain the
  table, or clear it before deployment. This is a deliberate clean prelaunch
  replacement; 2.0 does not parse or backfill the obsolete envelope shape.
  See "Upgrading" in the Convex component README.

## 1.0.0

- **Hosted Relay supports data-only push wake hints across Expo, APNs, FCM,
  and Web Push.** The SDK registers one destination for the authenticated
  device and derives no account, device, scope, or generation identifiers from
  application input. A wake starts an authenticated durable-mailbox pull.
  The SDK acknowledges only envelopes that it processes successfully, and the
  same pull remains available when push delivery is unavailable.

- **Hosted Relay now supports provider migration, recovery progress, and
  managed device linking.** Migration assertions use the existing purpose-aware
  identity callback with typed source and target roles. Recovery reports typed
  phases while Relay remains the account authority. Managed linking requires a
  provisioned account identity. It also requires distinct active and new
  device-auth keys. It sends no ratchet, sender-key, skipped-key, or outbox
  state.

- **Breaking: sends use a durable exact-ciphertext outbox and always return a
  logical-send identifier.** `SendResult.clientMessageId` is required. The SDK
  generates it when `SendOptions.clientMessageId` is absent, exposes it on send
  errors through `isOutgoingMessageError`, and replays the persisted encrypted
  transmission after an unknown Relay result. Receivers retain processed Relay
  envelope identifiers for 30 days and acknowledge duplicates without running
  protocol decryption again. Automatic sender-key rotation also persists its
  pairwise distribution messages before group transport. Custom
  `ISignalProtocolLocalStore` implementations must now implement
  `deleteMetadata` for bounded outbox and deduplication retention.

- **Breaking: linked-device backup format 2 transfers account identity only.**
  A linked device generates fresh prekeys and establishes independent sessions.
  The SDK rejects old or extended backup shapes that carry prekeys, ratchet
  sessions, sender-key state, message state, or outbox state.

- **Profile-key credential issuance is blinded.** The authenticated issuer
  receives an ACI-bound blinded request, not the raw profile key. The client
  unblinds and verifies the response before it creates a group presentation.

- **Breaking: sealed-sender delivery now uses one multi-recipient wire format
  for direct and group sends.** The direct path supports one recipient through
  the same format, and the SDK rejects the retired V1 wire format. Hosted Relay
  adapters no longer implement the V1 send method. `preferred` delivery falls
  back to identified delivery only after an anonymous authorization rejection;
  other anonymous-delivery failures do not change the privacy route.

## 0.4.0

- **Breaking: sender certificates now bind to Relay scope and issuer
  validity.** The signed sender certificate requires an opaque 16-byte scope.
  The signed server certificate requires its validity interval. Recipients
  reject the old certificate shape. The new hosted bootstrap accepts a
  publishable key and identity assertion callback. It then uses the account,
  device, and scope bindings that Relay returns. Identified delivery does not
  require a sender certificate.

- **Hosted Relay bootstrap now registers a complete EC and ML-KEM prekey
  inventory.** The SDK creates and stores signed, last-resort, and one-time
  prekeys before bootstrap. It sends only public material. Exact retries reuse
  the original operation and public registration snapshot, so a restarted
  client cannot publish an old one-time prekey as a new registration.

- **The README now provides a runnable encrypted round trip and a current demo.**
  The quickstart exercises two SDK clients through the in-memory relay. The new
  recording shows the same two-device and relay flow as the live desktop and
  mobile demo.

- **Error-surface checks reject unresolved codes and cover media attachment
  codes.** The analyser now reports forwarded code arguments in CI.
  It also checks every `MediaAttachmentErrorCode` value.
  This release removes `RemoteObjectStoreNotConfigured` because no media
  operation could produce it.

- **The retry-request wire surface no longer includes
  `RetryReason.INVALID_MESSAGE`.** No local failure produced it. The incoming
  retry handler did not support it. Malformed ciphertext failures use the supported
  `DECRYPTION_FAILED` recovery path.

- **Generated API pages and shipped documentation examples now have source
  gates.** CI regenerates `docs/api` with pinned tool versions. It rejects a
  diff. The snippet runner scans every packaged Markdown file and the internal
  lifecycle docs. It executes every complete example and matches its output.
  For an example that cannot run, it compiles every SDK name against the packed
  package. A renamed or deleted export therefore fails the build in every
  document that names it.

  An example that previews an unreleased API declares the import paths that do
  not exist yet. The build fails if one of them resolves. Only pseudocode is
  exempt, and the build names each exempt block on its own line.

- **The error guide now documents all 33 `EncryptionErrorCode` values.** Its
  session examples also use the current `ProtocolAddress` method signatures.

## 0.3.0

- **Breaking: seven error classes and sixteen `EncryptionErrorCode` members are
  removed, because nothing in the library ever threw them.** Each class was
  exported and paired with a type guard, so an application could branch on it —
  but no code path constructed any of them, which made every one of those
  branches dead code that read as handled. Removed, with their `is*` guards:
  `IdentityKeyChangedError`, `SessionConflictError`,
  `RegistrationIdChangedError`, and the four intermediate classes
  `CryptoError`, `SessionError`, `ProtocolError` and `ClientError`. Removed
  codes: `IDENTITY_KEY_CHANGED`, `IDENTITY_KEY_ERROR`, `SESSION_CONFLICT`,
  `REGISTRATION_ID_CHANGED`, `INVALID_REGISTRATION_ID`, `MESSAGE_TOO_OLD`,
  `INVALID_MESSAGE_VERSION`, `RATCHET_ERROR`, `DATABASE_ERROR`,
  `DATABASE_LOCKED`, `KYBER_ERROR`, `KDF_ERROR`, `HMAC_VERIFICATION_FAILED`,
  `SPQR_KEY_ALREADY_USED`, `SPQR_EPOCH_REGRESSION` and `UNKNOWN_ERROR`. The
  enum goes from 49 members to 33.

  What to use instead: an identity that changed is an identity that is not
  trusted, and the library throws `UntrustedIdentityError` /
  `UNTRUSTED_IDENTITY` for it from five sites on the session and sending
  paths. Code branching on `isIdentityKeyChangedError` or on
  `IDENTITY_KEY_CHANGED` was never reached and should branch on
  `isUntrustedIdentityError` instead. The other removed names have no
  replacement, because there was no event behind them.

- **`UntrustedIdentityError` and `isUntrustedIdentityError` are exported from
  the package root.** They were reachable only from
  `@open-e2ee/signal-protocol-sdk/types/errors`, while the error-handling guide
  imported them from the root — so the first thing a reader copied did not
  resolve. `StorageQuotaExceededError` also gains the
  `isStorageQuotaExceededError` guard its five siblings already had.

- **Every documented error code is now traceable to a construction site.** A
  check parses the library for the sites that decide whether a class can be
  thrown, and fails the build when an exported error class or a declared code
  survives with none — so the surface cannot drift back. Being named in a
  `switch` counted as use before, which is what hid `IDENTITY_KEY_CHANGED`
  through all nineteen releases that declared it and never threw it.

## 0.2.3

- **`@noble/post-quantum` 0.6.1 → 0.7.0.** Upstream hardening of the
  primitives under the post-quantum ratchet: an intermediate-overflow fix
  in ML-KEM's NTT multiplication, stricter input validation throughout,
  and ML-KEM public-key cache detachment. The 0.7.0 breaking changes are
  confined to hybrid-KEM aliases and a utils export, neither of which this
  package imports. The bump also unifies the dependency tree on single
  copies of `@noble/hashes` and `@noble/curves` 2.3.0.

## 0.2.2

- **The unfixable `image-size` development dependency is replaced with an
  inert local stub.** Both open advisories against `image-size` cover every
  released version and have no fix. The package reaches the tree only
  through Metro's image-asset pipeline, which nothing in this repository
  exercises. An npm override now points it at a local package that throws
  on use, so the development install carries no known-vulnerable code and
  `npm audit` reports clean across the whole tree.

- **Continuous fuzzing runs against the parser seams.** ClusterFuzzLite
  builds Jazzer.js fuzz targets over the wire-message, sender-key,
  sealed-sender, and post-quantum ratchet decoders, the base64 conversions,
  and the persistent session-record codec, on every push, pull request, and
  manual dispatch. Writing the targets' rejection contract surfaced one
  defect, fixed here: a session record with a malformed map encoding
  escaped the codec as a `TypeError` instead of its controlled error.

- **The README carries the OpenSSF Best Practices badge.** The project
  earned the passing level at bestpractices.dev (project 14043).

- **`SECURITY.md` states the supported release line correctly.** The
  supported-versions table had not moved past 0.1.x; it now names 0.2.x
  and states the no-backports rule.

## 0.2.1

- **Two GitHub code-scanning findings in shipped code are fixed.** The
  URL-safe base64 conversions stripped trailing `=` padding with a `/=+$/`
  replace, which backtracks quadratically on input that is mostly `=`
  characters; padding is now stripped by index in linear time. The Node
  store's `getKey` probed the key file with `access()` before reading it,
  leaving a race window between the check and the read; it now reads
  directly and treats `ENOENT` as an absent key. Neither fix changes
  observable behavior on well-formed input. The scan's prototype-pollution
  alerts against the Node sender-key trees were confirmed false positives:
  every decoded dictionary level is rebuilt with a null prototype before it
  is indexed, and the full-interface tests already prove `__proto__` keys
  round-trip as plain data.

- **Vulnerable development-dependency versions are updated.** `js-yaml`,
  `nanoid`, `postcss`, and `brace-expansion` move past their published
  denial-of-service advisories. The two `image-size` advisories have no
  fixed release yet; they sit behind Metro's dev-time asset parsing and do
  not reach the published package, whose production dependencies audit
  clean.

- **`@noble/ciphers` moves to 2.3.0.** A routine minor update of the
  symmetric-cipher dependency, applied internally so the public Dependabot
  pull request can close against this release.

## 0.2.0

- **ML-KEM Braid key-agreement progress is now observable.** A new
  `protocolStrategy.onBraidProgress` callback reports a `BraidProgressEvent`
  after every braid-mode send and receive: the chunks this side has carried in
  the current epoch, the chunks the open transfers account for, the epoch, and
  whether the operation produced the epoch secret. Braid mode spreads one
  ML-KEM key agreement across many messages, and until now the chunk counts
  lived entirely inside the state machine, so a host had no way to show or log
  how far a ratchet had traveled. A direct-mode session never raises the
  callback. The hook is guarded exactly as `onProtocolSelected` is: a consumer
  that throws is logged and the protocol path continues.

- **The web store's atomic commits leave no window for a partial commit
  under tab death.** A dying page closes its IndexedDB connection
  gracefully, and a transaction that is idle at an await boundary then
  commits the writes it already holds. The atomic session/trust commit
  awaited each write in turn, so a tab death after the session write could
  commit the session while the consumed one-time prekey survived — CI
  observed exactly that once in Firefox. The identity-rotation commit
  deleted sessions through an awaited cursor walk, with the same windows
  between the new pin and each deletion. Both commits now enter every
  mutation in one synchronous batch before any settles, and a structural
  browser test fails on every run — no kill timing required — if a commit
  regains an await boundary between writes.

- **ML-KEM Braid key agreement completes.** A braid session now reaches its
  first epoch on both sides; before this it could not complete one at all,
  failing at the 66th alternating message with `Future epoch requested`.
  Braid is the default SCKA mode, so this was the default path. The two sides
  derive an epoch secret at very different times by design — the encapsulator
  from a single `Encaps1` over the header, the decapsulator only after
  `Decaps` over the full `ct1 ‖ ct2` — and everything sent across that gap has
  to go out under the epoch the peer can still follow. `spqrSend` took that
  epoch from the chunk it was emitting, so it lost it on exactly the messages
  that carry no chunk: once its ciphertext is acknowledged, a sender has
  nothing left to send until the encapsulation-key transfer finishes. It then
  fell back to its own SPQR epoch, which had already advanced, and the peer
  rejected the message. The braid state machine reports the epoch it is
  sending under on every send, including the empty ones, and `spqrSend` now
  uses that for both the message-key derivation and the wire epoch. No wire
  format, serialized state, or public API changes.

- **Session state survives cloning under a cross-realm `structuredClone`.**
  `cloneProtocolState` now checks once whether the ambient `structuredClone`
  returns objects of the calling realm, and falls back to its portable clone
  when it does not. Reached across a realm boundary — the arrangement a Node
  `vm` context produces, and one Jest builds for everything it runs —
  `structuredClone` returns a working `Map` whose prototype belongs to the
  other realm, so `instanceof Map` reports false for it everywhere downstream.
  Two silent losses followed: the session codec wrote such a `Map` as `{}`,
  and the portable clone rebuilt it as a prototype-only husk whose `size`
  getter throws. ML-KEM Braid felt this first, because its decoders are the
  only protocol state held in a `Map` that has to survive many clones — a
  receiving decoder discarded every chunk it had accepted, held at one chunk
  forever, and the key agreement could never complete. Single-realm hosts, the
  browser and React Native included, always took and still take the native
  path.

- **Restoring a braid encoder state now rejects a malformed polynomial.** Each
  `polys` element is a run of big-endian 16-bit coefficients. An odd-length
  element read one byte past the end. The resulting
  `undefined` folded into the low half of a coefficient. A truncated state
  therefore decoded to a polynomial with a fabricated final term. The decoder
  now refuses empty and odd-length elements, as the reference does.

- **Encoding a braid message now rejects a chunk that is not 32 bytes.** The
  slot holds exactly 32 bytes. A shorter chunk left the rest of the slot zeroed and
  encoded a chunk the sender never held. A longer chunk raised a bounds error
  that named no field. Both now fail and report the length offered. The braid
  state machine only ever produces 32-byte chunks.

- **Deriving an SPQR send key now rejects a zeroed chain key.** Two paths
  install one. An epoch advance for receiving alone installs a zeroed send
  chain key. Pruning writes one over each retired send chain. Deriving from
  either would key a message from a known constant. No production path reached
  that state, so the check is defense in depth.

- **The unused SPQR binary header codec is gone.** `serializeSPQRHeaderBinary`
  and `deserializeSPQRHeaderBinary` emitted an unversioned framing. No
  production path used it. The documented wire format does not describe it. Use
  the protobuf codec, which carries the version capability.

## 0.1.0

- **First non-prerelease release.** Identical in code to `0.1.0-alpha.14`;
  the version graduates the `0.1.0-alpha` series. The alpha label is retired
  because the condition it described no longer holds: every shipped store
  adapter now carries the full `ISignalProtocolLocalStore` contract with its
  graduation checklist running as continuous CI gates — the storage contract
  suites in real Chromium, Firefox, and WebKit, the backend-conformance kit
  on Hermes, and the interruption, storage-pressure, multi-tab, and soak
  suites. The `0.x` caveat stands: public APIs and persisted formats may
  change before `1.0`.

## 0.1.0-alpha.14

- **`ReactNativeSignalProtocolStore` is no longer experimental.** Every gate
  on its graduation checklist now runs continuously. A new
  backend-conformance kit — `runBackendConformance` and
  `assertBackendConformance`, exported from the package — executes thirteen
  cases against any `ReactNativeKeyValueStorage` implementation: round-trips,
  key listing, batch removal, in-order atomic application, checks evaluated
  against pre-batch state, null-guarded creation, all-or-nothing failure,
  exact-userId session removal with in-batch visibility, a single winner
  between concurrent guarded batches, and durability across reopen. Negative
  tests prove the kit catches a non-atomic backend, a prefix-matching
  session removal, and an unserialized backend. A new
  `createReferenceReactNativeBackend` — the executable specification of the
  backend contract — passes the kit on the Hermes engine React Native ships
  with, in a new CI gate that runs the bundled kit on the sha256-pinned
  Hermes CLI and requires an explicit pass sentinel, because Hermes exits 0
  on an unhandled async rejection. Interruption and storage-pressure jest
  suites drive the adapter over the reference backend: a simulated process
  kill before commit leaves every atomic security write all-or-nothing and
  a retry after reopen lands it whole, and quota exhaustion is exercised
  through every write path.

- **Quota exhaustion in the React Native store now surfaces as a typed
  error.** The backend contract gains a documented quota signal: a backend
  rejects the failing write with an error named `QuotaExceededError` and
  commits nothing. The adapter maps that signal to the public
  `StorageQuotaExceededError` (code `STORAGE_QUOTA_EXCEEDED`) at the same
  adapter-boundary seam the browser store uses, so both stores report
  storage pressure identically.

## 0.1.0-alpha.13

- **`IndexedDbSignalProtocolStore` is no longer experimental.** Every gate
  on its graduation checklist now runs continuously: the storage contract
  suites in real Chromium, Firefox, and WebKit; the multi-tab
  compare-and-set suite; the interruption suite; the storage-pressure
  suite; and a new soak gate. The soak drives 2,000 full
  construct/initialize/write/read/close cycles through the adapter in one
  real Chromium page, samples renderer memory — including ArrayBuffer
  backing stores, which plain JS-heap readings miss — after forced
  garbage collection, and fails if the late-run median of memory or
  per-cycle latency grows beyond a small tolerance over the early-run
  median. Injecting a per-cycle leak into the adapter turns both
  detectors red. `npm run soak:web-store` runs longer sessions on demand.
  The React Native adapter remains experimental; its checklist is
  unchanged.

- **Quota exhaustion in the browser store now surfaces as a typed error.**
  A write that exhausts the origin's storage quota rejects with the new
  public `StorageQuotaExceededError` (code `STORAGE_QUOTA_EXCEEDED`)
  instead of the raw engine `QuotaExceededError`. The mapping lives at the
  adapter boundary — one seam covering every store method, matched by
  error name so it holds across engines — and because every write commits
  in one atomic transaction, the typed error always means the write did
  not persist, never a partial record. A jest suite drives quota-shaped
  backend failures through every write path, and a new Chromium
  storage-pressure spec in the real-browser gate clamps the origin's
  quota, exhausts it against the real engine, and asserts the typed
  rejection, intact prior state, and a clean retry once space frees.

- The real-browser gate now includes an interruption suite: a Playwright
  spec destroys a real tab while a write is in flight — an atomic
  session/trust commit, an identity rotation, a fresh-database bootstrap,
  and a prekey batch — then reopens the store from a fresh tab and asserts
  it is readable and each atomic security commit landed all-or-nothing,
  never partially. The kills are sampled at several points inside each
  write, in all three engines, and a deterministic structural test backs
  them: each atomic security commit must open exactly one readwrite
  transaction, which is what makes every kill land all-or-nothing. Tearing
  either commit into two transactions turns the structural test red on
  every run.

- **Two tabs no longer race the IndexedDB store into silent data loss.** Two
  cross-connection races existed in the browser adapter. First, the database
  encryption key bootstrap read then wrote in separate transactions, so two
  tabs initializing a fresh database concurrently could each generate a
  different key — records written by the losing tab then failed authenticated
  decryption everywhere else. Second, first-contact trust pinning checked
  then wrote in separate transactions, so two tabs pinning different
  identities were both told `NEW_IDENTITY` while one pin silently replaced
  the other. Both paths now create through IndexedDB's `add()`, which refuses
  to overwrite: the bootstrap loser adopts the winner's key, and a
  first-contact loser re-evaluates its candidate against the pin that won.
  Rotation, verification, and the atomic session/trust commit already
  performed their compare-and-set inside a single transaction and are
  unchanged.

- The real-browser gate now includes a multi-tab compare-and-set suite: a
  Playwright spec drives two tabs — two live IndexedDB connections on one
  origin — through concurrent key bootstrap, first-contact pinning,
  rotations, verification-versus-rotation, and one-time-prekey consumption,
  in all three engines. The two races above are what this suite caught, and
  reverting either fix turns it red.

- **Reading sessions or group sender keys no longer fails on Firefox and
  WebKit.** `getSessionsForUser` and `getAllSenderKeysForGroup` in the
  IndexedDB store decrypted each row inside the cursor loop. An IndexedDB
  transaction deactivates the moment the event loop turns to anything that is
  not one of its own requests, so awaiting Web Crypto mid-iteration let the
  transaction commit and the next cursor advance threw
  `TransactionInactiveError`. Chromium's laxer transaction lifetime and the
  fake-indexeddb test double both tolerated the pattern, which is how it went
  unseen. Both methods now collect the encrypted rows inside the transaction
  and decrypt after it completes, the pattern the prekey reads already used.
  No key agreement, payload, or wire byte changed.

- **`IndexedDbSignalProtocolStore.close()`.** The store held its database
  connection open for the life of the page, and an open connection blocks
  deletion and version upgrades of the database from anywhere else — so an
  application signing out or clearing local state had no supported way to
  release it. `close()` closes the connection and drops the in-memory
  database key; call `initialize()` again before any other operation.

- The storage contract suites now also run against
  `IndexedDbSignalProtocolStore` inside real Chromium, Firefox, and WebKit
  pages on every change to the source repository. The suites are the same
  modules the jest gate runs; the Firefox and WebKit failures above are what
  the gate caught on its first run.

## 0.1.0-alpha.12

- **AES-GCM without additional data no longer fails in the browser.** Every
  AES-GCM call built its Web Crypto parameters with `additionalData` always
  present, holding `undefined` when the caller passed no AAD. Node converts
  those parameters through WebIDL, where a member set to `undefined` is
  absent, and accepts them. Chrome parses them by hand: a present
  `additionalData` key must be a BufferSource whatever its value, so the same
  call throws `AeadParams: additionalData: Not a BufferSource`. Device
  provisioning and device transfer pass no AAD at all, so both worked under
  Node and were unusable in a browser. The parameters are now built in one
  place, which omits the member when there is nothing to put in it. No key
  agreement, payload, or wire byte changed.

## 0.1.0-alpha.11

- **BREAKING: device provisioning no longer requires React Native, and
  `getDeviceMetadata` moved to its own subpath.** `device/provisioning`
  statically imported `react-native` and `expo-constants` at module scope.
  Both are optional peer dependencies, so the package's own contract says a
  consumer may have neither — but a static import of an absent package throws
  `ERR_MODULE_NOT_FOUND` before the module runs, which made the entire
  device-linking surface unimportable in Node and in the browser. The two
  imports existed for three fields of one function. Provisioning itself is a
  protocol and already takes the device's description as a
  `LocalDeviceMetadata` parameter, so it is now platform-free, and
  `getDeviceMetadata` lives at
  `@open-e2ee/signal-protocol-sdk/device/expo-metadata`. It is no longer
  re-exported from the `device` barrel. Callers off Expo build the four
  fields themselves; callers on Expo change one import path. No key
  agreement, payload, or wire byte changed.

- **`local/vault` no longer drags Expo SecureStore in behind the
  interface.** The barrel re-exported
  `ExpoSecureStoreSignalProtocolSecretVault`, so importing the vault
  *contract* failed without `expo-secure-store` installed. The barrel now
  exports only `ISignalProtocolLocalSecretVault`; the implementation keeps
  its own subpath, `local/vault/expo-secure-store`, which is where every
  caller in this repository already imported it from.

- **New check: `node ./scripts/smoke-import-surface.mjs`, wired into CI.**
  Packs the package, installs it into a consumer outside the repository whose
  `node_modules` has every optional peer removed, and imports all 59
  published export subpaths. Entry points that are genuinely bound to a
  platform are listed explicitly, and the list is verified in both
  directions, so an exemption that stops being true fails the check rather
  than lingering. Nothing caught the two defects above: the checks that name
  every subpath resolve types without ever loading a module, and the checks
  that load modules run from inside the repository, where the optional peers
  are installed as devDependencies and Node's resolver finds them.

- **Bundling the sealed-sender codec no longer pulls React Native in with
  it.** The codec imported two base64 helpers from the `internal/crypto`
  barrel, and that barrel also exports `generateRandomBytes`, whose
  third-choice runtime fallback is a dynamic `import('expo-crypto')`. The
  fallback is correct — it is how the SDK finds a secure random source on
  Expo, behind two other sources and a `try`/`catch` — but a bundler
  resolves what it can reach without asking whether the branch will run, and
  `expo-crypto` reaches `react-native`, whose entry point is Flow rather than
  TypeScript. Anything bundling the codec for a server or a browser was
  therefore parsing a mobile UI framework, and any bundler without a Flow
  loader stopped there. The helpers now come from `internal/crypto/utils`,
  which imports nothing but types, so the reachable graph ends where the
  encoding does. No encoder, decoder, or byte changed.

## 0.1.0-alpha.10

- **BREAKING: the quickstart adapters are named for what they are —
  in memory, not mocks.** Nothing in either adapter is a test double: the
  protocol and the cryptography are real, and only the infrastructure is
  simulated. The name said otherwise, and readers discounted the quick
  start because of it. The `mock` subpaths are gone rather than aliased —
  this is a pre-1.0 alpha with no customers, so a compatibility layer would
  only preserve the wrong word. Update imports and identifiers:

  | Before | After |
  |---|---|
  | `@open-e2ee/signal-protocol-sdk/local/store/mock` | `@open-e2ee/signal-protocol-sdk/local/store/memory` |
  | `@open-e2ee/signal-protocol-sdk/remote/relay/mock` | `@open-e2ee/signal-protocol-sdk/remote/relay/memory` |
  | `mockStore()` | `inMemoryStore()` |
  | `mockRelay()` | `inMemoryRelay()` |
  | `MockSignalProtocolStore` | `InMemorySignalProtocolStore` |
  | `MockSignalProtocolStoreOptions` | `InMemorySignalProtocolStoreOptions` |
  | `MockSignalProtocolRelayServer` | `InMemorySignalProtocolRelayServer` |
  | `MockSignalProtocolRelayServerOptions` | `InMemorySignalProtocolRelayServerOptions` |
  | `MockStoreFailureController` | `StoreFailureController` |
  | `MockStoreFailureOptions` | `StoreFailureOptions` |
  | `MockRelayFailureController` | `RelayFailureController` |
  | `MockRelayFailureOptions` | `RelayFailureOptions` |
  | `MockStorageWriteError` | `InjectedStorageWriteError` |

  The failure controllers moved with the adapters and kept their behavior.
  They were never test doubles either — they are deterministic, seeded
  failure injection for the documented recovery exercises — so they lost
  the `Mock` prefix instead of the subpath.
  No runtime behavior changed: the storage-failure error message drops the
  word "mock" and `InjectedStorageWriteError` reports the new class name,
  and nothing else on the wire, in storage, or in the failure semantics
  moved. The doc-snippet runner that executes every shipped snippet is now
  `scripts/run-doc-snippets.mjs` with a `doc-snippet:` marker, because the
  snippets it runs were never mock snippets.

- **`protobufjs` is no longer a dependency of the published package**, and
  the eval gate that proves it is now part of CI. The relay's sealed-sender
  certificate issuer was the last module importing it, through
  `protobufjs/minimal`'s `Writer` — which generates no code, so it was never
  what made the SDK throw `EvalError` under a strict Content-Security-Policy,
  but it did pull `protobufjs` and `long` into every install to write four
  fields. Issuance now goes through the same hand-written sealed-sender codec
  that validates the certificates it produces, so the field numbers an
  Ed25519 signature is computed over are described in one module instead of
  two that had to agree. The package declares six direct production
  dependencies and resolves to six packages in total; `protobufjs` remains a
  development dependency, where the wire tests use it as an independent
  oracle. The bytes are unchanged, which is the whole of the risk here — a
  certificate is a signature over exactly these bytes, and any shift would
  have invalidated every one already issued. Golden vectors captured from the
  old writer before the rewrite pin the issued bytes for four shapes,
  including a multi-byte UUID and an expiry above 2^53, and each is
  re-validated through the certificate chain with real keys.

- **A varint that cannot fit a `uint32` is refused at the encoder instead of
  written wrong.** `encodeVarint` stops at five bytes, so it truncated
  anything above 4294967295 — 2^32 came out as `80 00`, which the 64-bit
  decoder then correctly rejected as non-canonical — and it wrote `NaN` as 0
  and `1.5` as 1. All three now throw a named error at the point the mistake
  is made. Callers that need the wider range already have `encodeVarint64`.
  Nothing in this package encoded a value in the refused range.

  One decode-side strictness note that belongs with the wire work above and
  was not recorded when it landed: an unknown field encoded as a group (wire
  types 3 and 4) is rejected rather than skipped, where `protobufjs` skipped
  it. Groups are deprecated, no schema here uses them, and skipping one
  correctly means matching its end tag — a parser state this format has no
  reason to carry.

- **The sealed-sender wire codec is hand-written, and no signed certificate
  region is re-encoded on the way through.** Its five message types and the
  `UnidentifiedSenderMessage.Type` enum were assembled at runtime by
  `protobufjs` reflection, which compiles its encoders with `new Function` —
  the construct a `script-src 'self'` policy blocks — and they are now static
  encoders and decoders over the shared wire primitives. Every byte is
  unchanged, which carries more weight here than anywhere else in the wire
  work: a server certificate's signature is computed over its serialized
  inner bytes and a sender certificate's over its own, so a shift in field
  order, in a nested length prefix, or in whether an explicitly-set zero
  reaches the wire would invalidate every certificate already issued. The
  decoders hand signed regions back as the raw bytes they arrived as, never
  as a re-encoded structure. The 19 committed golden vectors pin all of it in
  both directions. Two decode paths do change, both for messages that were
  already malformed or came from a peer this version does not know: an inner
  message whose `type` names no declared arm — including an absent field,
  which reads as 0 — now decodes to the value that arrived, where reflection
  substituted the enum's first arm and so reported a `PREKEY_MESSAGE` the
  sender never wrote, and callers that route on the value must narrow it with
  `isSealedSenderContentType`; and a message with no `senderCertificate`
  decodes to empty wrapper fields, which certificate validation rejects,
  instead of raising `TypeError` from a null dereference. A third shift is
  smaller still: string fields decode through `TextDecoder`, which maps
  invalid UTF-8 to U+FFFD replacement characters where reflection produced
  other strings — for one shape, an empty string the required-field check
  then rejected. A certificate whose `senderUuid` is not valid UTF-8
  therefore now decodes instead of failing that check; such bytes can only
  exist under a trusted issuer's signature, and every issuer this SDK has
  shipped writes valid UTF-8.

- **The SPQR wire and ratchet-state serializer no longer builds its schema
  at runtime**, so the post-quantum ratchet works under a `script-src 'self'`
  policy. The ML-KEM Braid codec described its eight messages to
  `protobufjs` reflection, which compiles each encoder with `new Function` —
  the one construct a strict Content-Security-Policy forbids, and the reason
  the SDK threw `EvalError` in a hardened browser, an extension service
  worker, or anywhere else code generation is off. The eight messages now
  have hand-written encoders and decoders over the wire primitives, and the
  module imports nothing from `protobufjs`. Every exported function keeps
  its name and signature, and the presence rules that decide what reaches
  the wire are unchanged: an explicitly-set zero is still written, an absent
  field still decodes to its typed zero rather than `undefined`, and the
  `V1Msg` `inner_msg` oneof still emits exactly one arm. That matters more
  than usual here, because the encoder, decoder, and authenticator messages
  are *persisted* ratchet state — an install that upgrades has to decode the
  bytes it wrote before it upgraded. Byte identity is pinned by 49 golden
  vectors covering each message, each oneof arm, empty and maximal repeated
  fields, and epochs at 0, 1, 2^32, 2^53−1, 2^53+1, and 2^64−1.

  Three behaviors moved, each away from silent corruption. A persisted
  decoder chunk that carries an index but no data used to yield a map entry
  holding `undefined`, which surfaced later as a confusing failure inside
  Reed–Solomon reconstruction; it is now rejected where it is read, naming
  the chunk — nothing in this package has ever written that shape, so it can
  only come from corrupt state. Encoding state that violates its declared
  types — a field that is not the `Uint8Array` it claims, a size that is
  negative or above 4294967295 — now throws a named error where the old
  encoder silently wrapped the value and wrote wrong bytes. And
  `isSerializationReady()` now always returns `true`: with static codecs
  there is no schema to build and no not-ready state to report
  (`initSerialization()` stays as an awaitable no-op for callers that
  sequence on it).

- **The Double Ratchet and sender-key message codecs no longer build their
  wire types at runtime.** `SignalProtocolMessage`,
  `PreKeySignalProtocolMessage`, `SenderKeyMessage`, and
  `SenderKeyDistributionMessage` were encoded and decoded through
  `protobufjs` reflection, which compiles each encoder with `new Function` —
  the exact construct a `script-src 'self'` policy blocks. All four are now
  hand-written encoders and `ProtoReader` decode loops over the shared wire
  primitives, and neither module imports `protobufjs`. Nothing on the wire
  moves: the twenty committed golden vectors for these two modules pin every
  byte in both directions, including the behavior that is easiest to lose in
  a rewrite — presence, not value, decides what is written, so a counter of
  0 and a prekey id of 0 stay distinguishable from an absent field, an empty
  bytes field still reaches the wire and is still dropped on decode, and
  unknown fields are still skipped. Decoding is stricter in one respect
  inherited from the primitives: a field whose wire type contradicts its tag
  is now rejected rather than read as its declared type.

- **The protobuf wire primitives now cover 64-bit varints and the field
  shapes the message schemas actually use**, which is the groundwork for
  encoding every message here without `protobufjs` — and so without the
  runtime code generation that a `script-src 'self'` policy blocks. The
  varint helpers stopped at 32 bits in five bytes, so the SPQR epoch, a
  uint64, had no representation that survived a round trip; there are now
  bigint encode and decode functions with a ten-byte ceiling, alongside
  helpers for bool, enum, string, fixed64, embedded-message, and repeated
  fields, and a `ProtoReader` cursor that owns the read-tag-dispatch-skip
  loop every decoder repeats. The existing 32-bit functions are untouched
  and byte-compatible. Two contracts are deliberately stricter than
  `protobufjs`: a varint must be canonically encoded, because these bytes
  are signed and MAC'd and a redundant encoding would make the signed byte
  string malleable; and a field whose wire type contradicts its tag is
  rejected rather than misread. Nothing on the wire moves — no encoder has
  ever emitted the forms now refused.

- **The public repository's snippet check no longer requires an unpublished
  file.** `0.1.0-alpha.8` removed the internal pricing preview from the
  export, but `run-mock-snippets.mjs` — which ships in both repositories —
  still read it unconditionally, so the public "shipped mock snippets" CI job
  failed with ENOENT from the `0.1.0-alpha.9` push onward. The runner now
  validates that file's snippets only where the file exists, which is the
  boundary the export already draws. `ossf/scorecard-action` also moves to
  v2.4.4 (dependabot, applied here so the export carries it).

## 0.1.0-alpha.9

- **BREAKING: the multi-recipient content ceiling is the reference's
  96 KiB, and the shared payload is stored once, not once per
  recipient.** The 256 KiB ceiling was a misreading of the reference,
  which validates what each recipient will *receive* against the same
  96 KiB message-size constant it applies to individual sends — its
  256 KiB constant is an HTTP entity-read cap on the whole request, not
  a content bound. Worse, the fan-out stored a full copy of the shared
  ciphertext in every recipient's row, so one full-size send to a large
  group multiplied itself by the device count inside a single
  transaction — the reference's message store instead inserts one
  shared multi-recipient payload and hands each recipient a pointer,
  and this relay now does the same: per-recipient rows keep only their
  48 bytes of key material, delivery reassembles the exact wire form,
  and the shared payload row shares the message queue's retention.
  Found by this round's adversarial review; the ceiling boundary and
  the once-per-send storage each carry a revert-proven test.

- **The mock relay's send dedup is now sender-scoped, matching the
  Convex backend**, and `clientMessageId` is documented as requiring
  global uniqueness: sealed senders are anonymous by design, so every
  sealed send to a device shares one dedup namespace, and a reused
  counter or timestamp from two senders would silently collapse into
  one stored message.

- **The change-log walk now stops where the tenure ends, not where
  readability ends.** The S10a work narrowed the change log's entry gate to
  members but left the walk's continue condition on the weaker readable
  set, so a removal that left another of the requester's aliases pending —
  an ACI member whose PNI was invited, then the ACI removed — kept serving
  post-tenure history to a principal the group now lists only as invited,
  from any `fromVersion` inside the old tenure. Both gates now share one
  membership predicate: the walk serves through the tenure-ending
  transition, inclusive, and nothing after it. Versioned `getGroup` had the
  sibling misclassification: a requester with no tenure at all fell into
  the same `before_join` refusal as the join-version floor, telling a
  revoked-then-re-invited member that their membership was intact. The
  no-tenure case is now refused as `not_a_member`, `before_join` is raised
  only against a live tenure, and the accepted-join read translates
  `not_a_member` into `GROUP_ACCESS_REVOKED`. Found by this round's
  adversarial review; the alias-removal walk, the versioned-read reasons,
  the empty-page fault, and the snapshot-regression guard each carry a
  revert-proven test, and the S10a catch-up test now proves the snapshot
  mechanism against a server whose log throws.

- **The Node store now implements all of `ISignalProtocolLocalStore`, and the
  compiler enforces it.** `NodeSignalProtocolStore` was missing 37 of the
  interface's 72 members — the whole Sesame device-record, sender-key,
  skipped-sender-key, and message-record surfaces, plus metadata and the
  prekey-recovery helpers — so multi-device linking and both group APIs were
  unavailable to any Node process, and passing the store as `adapters.storage`
  needed a cast. All 37 are implemented against the same encrypted, atomically
  committed state document the adapter already used, and the class now carries
  an `implements ISignalProtocolLocalStore` clause, so a missing member or a
  drifted signature fails the build instead of surfacing as a runtime gap. The
  store also joins the shared storage contract with extended boundaries and the
  shared sender-key resolution contract, which the other adapters already ran.

- **The Node store's registration ID survives a restart.** It was held in an
  in-memory `Map` inside an adapter whose entire purpose is persistence, so
  every process start reported registration ID 0 and every peer read the
  restart as a reinstall. It is now part of the persisted state document,
  keyed by identity type so ACI and PNI stay distinct. Kyber prekey usage
  markers, previously in-memory for the same reason, persist alongside it.

- **BREAKING: the group change log is served in pages.** `getGroupChanges`
  returned the entire remaining log in one response — in practice the
  Convex transport silently truncated its restore at 4096 changes with no
  has-more signal, which is worse: a long log simply stopped syncing. The
  endpoint now returns `{ entries, hasMore }`: at most 64 entries per
  request, `hasMore` set only when the page was cut for size with the
  requester still a member, and each resumed request authorized
  independently at its own `fromVersion` snapshot. A walk that ends at the
  log's tip or at the requester's own tenure-ending transition is complete
  and says so — a removed member never sees `hasMore` dangle past the
  change that removed them. The client sync loop pages until done,
  resuming from the last verified revision, and treats a has-more page
  that served nothing as a server fault rather than looping on it. The
  reference's clients also drive an explicit paging loop off a has-more
  signal, though their resume cursor is server-supplied where ours is the
  client's own last verified revision; the page size here follows the
  shape, not a verified reference constant. The Convex transport bounds
  its storage restore to one page plus the look-ahead entry that decides
  `hasMore`, so the read cost now scales with the page rather than with
  `min(history, 4096)`.

## 0.1.0-alpha.8

- **An internal pricing exploration is no longer published, and business
  planning is now structurally unexportable.** `docs/pricing-preview.html` —
  an internal pricing and revenue exploration — was allowlisted into the
  public export in `0.1.0-alpha.5`. Nothing linked to it and it was never in
  the npm package, but it had no business being public. It is removed from
  the allowlist, and the release policy now refuses any file whose name
  matches pricing, revenue, or business-model patterns, so re-adding one
  becomes a deliberate policy edit instead of a one-line allowlist change.

- **The assurance figures are now a build product.** The figures table in
  `docs/ASSURANCE.md` was hand-maintained and had gone stale across two
  releases. `npm run assurance:update` regenerates it from a real run and
  refuses to write figures from a failing run; `release:verify` refuses to
  cut an export when the figures are more than three days old. The README no
  longer duplicates the numbers — it points at the one generated table.

- **README: the product speaks before the disclaimer.** The Signal
  non-affiliation paragraph moved below the benefit bullets (still above the
  fold); the nav line gains `open-e2ee.dev` and `docs.open-e2ee.dev`, which
  the README previously never linked; the hard-coded patch version — four
  releases stale at time of fix — is replaced by the `0.1.0-alpha` maturity
  line, with the npm badge carrying the exact version; the weekly-downloads
  badge, which renders a near-zero number for a days-old package, is
  replaced by a native-modules count that states a real differentiator.

- **`COMMERCIAL.md` answers the highest-intent click.** Commercial licensing
  previously dead-ended at an email address. The new file states who needs a
  commercial license, what it changes and does not change, the public tiers,
  and how buying works. Shipped in the npm package too.

- **A contribution surface that tells the truth about the export model.**
  `CONTRIBUTING.md` explains that `main` is generated, why PRs are ported
  rather than merged, and that issues are triaged in public;
  `CODE_OF_CONDUCT.md`, issue templates (with a security-reporting
  off-ramp), and a PR template complete the set.

- **Vulnerability reporting: private GitHub reporting and a safe harbor.**
  `SECURITY.md` now offers GitHub private vulnerability reporting alongside
  email, and commits to a good-faith safe harbor for security research.

- **`docs/E2EE.md` grew from a summary into the architecture explainer its
  README billing promises** — server-becomes-relay, device as source of
  truth, identity as device keys, recovery as a product decision, metadata
  visibility, and the new failure modes, each linking to the doc that goes
  deeper. Its "ML-KEM (Kyber)" phrasing is corrected to "ML-KEM (FIPS 203)",
  matching the distinction this changelog drew in `0.1.0-alpha.6`.

- **The npm package no longer ships 1.8 MB of generated API reference.**
  `docs/api` (391 generated files) stays in the repository for browsing but
  leaves the tarball; installs should not pay for reference docs that are
  regenerable and hosted.

- **Supply-chain hardening.** Every workflow action is pinned to a commit
  SHA; dependabot watches npm production dependencies and workflow actions
  weekly; CodeQL runs the security-extended queries on every push, PR, and
  weekly schedule.

- **The composition guide leads with the shipped API.** The "Target
  Composition" section — `deviceStorage`, `createExpoDeviceStorage`,
  `signal.messages.subscribe`, none of which exist in the package — sat above
  the real API at the top of `docs/CLIENT_COMPOSITION.md`, which is exactly
  the position that gets copy-pasted. It moved to the bottom under "Future
  Direction (Not Shipped)" behind an explicit these-imports-fail warning.

- **The Node store README no longer claims an interface the adapter does not
  implement.** `NodeSignalProtocolStore` covers the core single-device
  surface but not the Sesame device-record, sender-key, or message-record
  portions of `ISignalProtocolLocalStore` — and it has no `implements`
  clause, so the compiler was never checking the README's claim. The README
  now states the real coverage and points multi-device and group users at
  the interface docs. Completing the adapter is tracked work; documenting
  the boundary honestly could not wait for it.

- **BREAKING: the group change log is for members; pending principals catch
  up by snapshot.** The change log authorizes at the snapshot at
  `fromVersion`, and a pending-profile-key entry appears in that roster, so
  an invitee could walk the log forward from their invitation — reading, for
  the whole invitation-to-acceptance window, a narration `getGroup` refuses
  them by name, including who made each change. The server now requires the
  requester to be a *member* of the authorizing snapshot (rejecting with the
  distinct reason `not_a_member`), which closes the log to invitees outright
  and, for members, states the tenure bound that the roster check previously
  provided by accident.

  Pending principals do not lose their catch-up path — they lose the log as
  the mechanism. A pending client now advances by fetching the current state
  as a fresh signed baseline, verified and installed whole, which is also
  how the reference ecosystem's clients behave whenever the server does not
  recognize them as a member. Acceptance is unaffected: it was always
  submitted against the current state, which is exactly what the snapshot
  provides. The specification records this as S10a, with the C1/C3 span
  rules restated to make explicit what was previously implicit: a pending
  view is a provisional baseline, not a span with living continuity, and a
  member's span begins at the verified transition or baseline that makes
  them a member.

  One behavioral consequence: an invitee whose invitation is withdrawn no
  longer receives the deletion as a signed change (the log that carried it
  is closed to them). The next catch-up finds the current state refused and
  surfaces `GROUP_ACCESS_REVOKED`, mutating nothing — the cached pending
  view remains the last verified state, and a later re-invitation serves a
  fresh baseline. Members are untouched: removal and ban still arrive as
  verified transitions through the log, never as refusals.

- **A full 256 KiB multi-recipient payload is accepted, as advertised.** The
  content ceilings are enforced on the base64 columns as string-length
  limits, and the multi-recipient limit was computed as `ceil((n / 3) * 4)`
  instead of `4 * ceil(n / 3)` — two characters short of what 256 KiB
  actually encodes to, since 262144 is not a multiple of 3. A payload at
  exactly the advertised ceiling was refused with a 413. The single-recipient
  limit was computed the same way but 96 KiB divides by 3, so only the
  multi-recipient bound was wrong.

- **A FORBIDDEN group read now says which question it answers, and only a
  membership refusal reads as revocation.** Two different rejections share
  the 403 `FORBIDDEN` code on the group read paths: "you may not read this
  group at all" (banned, or absent from the authorizing roster) and "you may
  not read this version of it" (the join-version floor added in the
  removal-revocation work). They differed only in message text, and the
  client treated any `FORBIDDEN` on a pinned baseline read as
  `GROUP_ACCESS_REVOKED` — so a floor rejection, raised while the membership
  itself was fine, would have been reported to the application as a revoked
  membership. The rejections now carry a machine-readable `reason`
  (`not_readable` / `before_join`) alongside the code, the client interprets
  only `not_readable` as revocation and propagates everything else, and the
  conformance tests assert on the reason rather than on message wording.

- **A multi-recipient send may name each device only once, and retry
  requests are rate limited.** The multi-recipient path is deliberately
  exempt from the per-recipient inbound-bytes budget, matching the
  reference, because a group-send token is supposed to price it. That
  exemption assumes one call fans out to *distinct* devices. The reference
  gets that from its wire format, which parses recipients into a map keyed
  by service ID, so duplicates collapse before the handler ever sees them;
  our flat array does not, so one endorsed device repeated a thousand times
  in a single call stored a thousand copies of the ciphertext against an
  unmetered budget. The handler now rejects a repeated `(userId, deviceId)`
  with a 400 rather than collapsing it, since a repeat is a client bug and
  quietly picking between two conflicting key blocks would bury it.

  `sendRetryRequest` was unmetered too, and nothing else on that path bounds
  it: a retry request carries no caller-supplied content to charge by size,
  and it names an original sender the caller never has to have talked to, so
  there is no relationship to check either. It is now counted per requester
  against a token bucket sized for the legitimate case — a client returning
  from a broken session asks for one per message it could not decrypt — and
  refuses only a caller that keeps asking indefinitely.

- **BREAKING: group-send tokens are verified before any account is read, and
  sealed sends carry the recipient identities they claim.** A group-send
  token is a signature over ACIs, but sealed sends name recipients by user
  ID, so the relay resolved every named recipient to its stored ACI — up to
  one indexed read per recipient, a thousand on the multi-recipient path —
  *before* it could check the token. An anonymous caller holding a garbage
  token could bill that work to the deployment on every call, on the one
  path that is deliberately exempt from the per-recipient send budget
  because the token is supposed to be the gate.

  The order is now the reference implementation's, where sealed payloads
  name recipients by service ID and the token is checked against the request
  before any account is touched: the caller supplies the ACI it claims for
  each recipient, the entire cryptographic check runs against those claims
  first, and only then is each claim bound to the recipient's stored
  account. A caller who lies about a binding has necessarily already
  presented a token our own group server issued over the claimed set, so
  the reads it spends were an authenticated member's to spend.

  The claims ride the existing plumbing: the endorsement cache now stores,
  next to each member's endorsement, the ACI it was issued over — the
  identity that is *correct* to claim, as opposed to whatever a later lookup
  would resolve — and the send paths pass them through. This changes the
  app-owned `EndorsementCacheStore` interface (entries are now
  `{ endorsement, aciBytes }` records rather than raw bytes) and adds
  `targetAciBytes` / per-recipient `aciBytes` arguments to the sealed send
  mutations, required when authorizing by group-send token.

- **One ACI, one account.** Nothing stopped two user IDs from registering
  the same ACI: `identify` is host-owned and unvalidated, and the second
  account to claim an ACI would inherit every authorization decision made
  about the first — sealed-sender access, group-send endorsements, identity
  binding. The `accounts` table now has an `aciBytes` index and
  `rememberAccount` refuses a claim on an ACI already registered to a
  different user ID with a 409 `CONFLICT`. A deployment that already holds
  duplicate-ACI rows keeps working — the check reads one claimant and the
  duplicate surfaces as the intended 409 rather than an untyped error — but
  which of the two accounts is refused depends on index order, so resolve
  such rows deliberately before deploying.

- **Removal and ban now revoke historical group-state reads.** `getGroup` with
  an explicit version authorized the requester against the roster of the
  *requested* snapshot, so anyone removed or banned at version N could keep
  fetching every snapshot of their former tenure indefinitely — a removal that
  does not revoke read access is not a removal. The server now authorizes
  every full-state read against the group as it is *now*, and adds the floor
  that snapshot-based authorization used to provide by accident: a member may
  not read state from before the version they joined at, so membership grants
  the group from when you joined, not its history.

  The change log deliberately keeps snapshot-at-`fromVersion` authorization,
  as the group specification already required: the walk serves entries only
  while the requester stays readable and stops at — and includes — the change
  that removed them, which is how a polling member learns of their removal.
  Authorizing the log at the current state would 403 them into silence. What
  this leaves reachable to a former member is bounded and not new: changes
  from within their own tenure, ending at their removal — bytes they were
  served while entitled.

  One client-visible consequence: a join that is accepted and then revoked
  before the joiner reads its baseline snapshot — an admin removing them in
  the race window — now fails with `GROUP_ACCESS_REVOKED` instead of
  reporting a membership the client could never verify or use. Nothing is
  installed locally, and the principal becomes the ordinary re-entitlement
  case: a later re-add serves a fresh signed baseline.

  An invitation grants the current state and nothing else. A
  pending-profile-key entry entitles its holder to read the group as it is —
  acceptance needs that — but it is not a tenure, and its wire format pins
  `joinedAtVersion` to zero, so deriving a history floor from it would read
  as "joined at the beginning of time". An invitee who never accepts holds
  the group master key, so every snapshot the server serves them decrypts;
  versioned reads are therefore refused outright for pending principals.

  This bounds `getGroup` only. The change log authorizes against the
  snapshot at `fromVersion`, and a pending-profile-key entry appears in that
  roster, so an invitee can still walk the log forward from their
  invitation — a window during which they could already fetch the current
  state at will, though the log additionally names who made each change.
  Flooring the log would deny a pending member the entries they need to
  reach the state their acceptance is submitted against, so closing that
  window means changing how pending members catch up, not adding a check.

- **The relay's send paths are bounded: per-recipient inbound budget, a
  content-size ceiling, and a device-existence check on sealed sends.** None
  of the component's send paths was rate limited or size limited, so one
  caller — anonymous on the sealed path, any authenticated account on the
  identified one — could grow a victim's message queue without bound for the
  full seven-day retention window. Three bounds close this, each matching the
  reference implementation's shape: message content is capped at 96 KiB for a
  single-recipient envelope and 256 KiB for the shared multi-recipient
  payload; single-recipient sends spend from a per-*recipient* byte budget
  (4 MiB burst, 1 MiB/minute sustained) — keyed by the target because a
  sealed sender is anonymous by design, so a per-sender limit on that path is
  either meaningless or a hole; and `sendUnidentified` now refuses a target
  device that does not exist, the check its multi-recipient sibling always
  had. The multi-recipient path is deliberately not metered, also matching
  the reference: the group-send token already prices it, and a per-recipient
  budget there would let one noisy group partially starve delivery to its
  quietest member.

  The shared bucket is bounded from the sender side too. Keying by target is
  forced on the sealed path — the sender is anonymous by design — but on the
  identified path the sender is known, and a single authenticated account
  must not be able to drain a victim's whole budget and starve every other
  sender: identified sends also spend a per-(sender, recipient) sub-limit of
  a quarter of the shared bucket. Neither bucket can be spent by a request
  that goes on to fail: the charges are written in the mutation's own
  transaction, so a send that 410s on the stale-device check — or trips the
  other limit — rolls its charge back with everything else.

- **The `STALE_DEVICE` error no longer discloses the recipient's current
  registration ID.** The 410 thrown when a sender's view of a device is stale
  echoed back `currentRegistrationId` — the live value — to any
  account-authenticated caller, with no rate limit. That is the same read the
  prekey-bundle fetch serves, minus its rate limiter: a free oracle for
  watching registration-ID changes (device reinstalls) on arbitrary devices.
  The error now names the stale device and nothing else, which is the
  reference implementation's 410 body; the sender's recovery path is
  unchanged, since recovering means re-fetching the bundle anyway.

- **BREAKING: no group identifier travels on a message envelope any more.**
  Every relayed message carried a plaintext `groupId` alongside its target, and
  the relay stored it on each `messages` row for the seven-day retention
  window. Grouping those rows by that column yielded the set of accounts that
  received traffic for a group, so a relay operator could reconstruct rosters
  without breaking any encryption. The column is gone, and so are the `groupId`
  arguments on `messages.send`, `sendUnidentified`, and
  `sendMultiRecipientUnidentified`, and the field on the envelopes those
  functions return.

  What replaces it is a message type. A group message is now typed
  `sender_key`, which tells the receiver to decrypt the payload as a framed
  SenderKeyMessage — and nothing else. The receiver reads the frame's
  distribution identifier, which is opaque, and resolves the group against its
  own sender key store. The envelope says how to decrypt, never which group.
  This also removes a small trust problem: the receiver no longer selects a
  sender key using a group id the sender asserted.

  This closes the group's *name*, not the group *partition*. The distribution
  identifier is unencrypted and stable for the life of a sender key, one send
  produces byte-identical ciphertext on every recipient's row, and the
  multi-recipient sealed path hands the relay a roster. A relay can still
  partition delivery pairs into unlabeled groups; it can no longer put a
  meaningful, cross-send label on one. The component README states the
  remaining channels explicitly.

  Sealed sender needed its own channel for this, because the outer envelope of
  a sealed message is always `unidentified_sender` and cannot carry an inner
  type. Sealed envelopes now begin with a content-type byte inside the seal,
  matching the `Type` enum of the reference implementation's
  `UnidentifiedSenderMessage.Message` (`PREKEY_MESSAGE`, `MESSAGE`,
  `SENDERKEY_MESSAGE`, `PLAINTEXT_CONTENT`), and `SealOptions.groupId` —
  encrypted, never populated by the send path — is removed in favor of
  `contentType`. This is a wire-format change to sealed sender for both V1 and
  V2.

  Deploying this against an existing Convex deployment needs a manual step:
  Convex validates stored documents against the new schema during the push,
  before any of your code runs, so a `messages` row still carrying a `groupId`
  fails the deploy and no migration can run ahead of it. Clear the `messages`
  table — or stop sending and let the seven-day retention window drain it —
  before deploying. Messages are transient and clients re-request undelivered
  ones. See "Upgrading" in the component README.

- **Fixed: on React Native, one member's sender key could permanently break
  another's group messages.** The store indexes sender keys by the frame's
  distribution identifier so a receiver can resolve a group without being told
  which one. Every other adapter scopes that index by sender; the React Native
  adapter keyed a flat pointer on the identifier alone, so a second sender
  presenting the same identifier overwrote the first, and the displaced
  sender's group messages failed to decrypt until it rotated. Distribution
  identifiers are chosen by their sender and travel in the clear, so this was
  reachable by any account sharing a group with the victim. The pointer key is
  now scoped by sender and device.

- **Fixed: on React Native, a host that issues colon-scoped user IDs could not
  receive group messages at all.** The adapter joins composite storage keys on
  `:` and split the sender key record key from the right, which silently
  mis-assigns the components when a user ID contains a `:` of its own — and
  nothing constrains user IDs, since they come from the host application's
  identify hook, where a tenant- or issuer-scoped subject is ordinary. Every
  group message resolved to nothing on such a deployment, deterministically and
  permanently. The same join made a group ID a prefix of `<groupId>:<sub>`, so
  deleting a group's sender keys also swept any group whose ID extended it.

  Key components are now percent-escaped before they are joined, so no
  identifier can carry a separator into a key or a scan prefix. This also
  retires the residue left by the sender-scoping fix above, which had only
  pushed the collision behind the same assumption.

  Sender key records and pointers are unaffected on upgrade for a deployment
  whose IDs contain neither `:` nor `%`, because such values escape to
  themselves; only the values that were already broken move. Retry records are
  different, and do move for everyone: their key is scanned by session ID, and
  a session ID is `<userId>:<deviceId>`, so it always carries a separator. That
  separator was load-bearing in the same way — a session ID of `alice:1` has
  scan prefix `alice:1:`, which also matches the records of user `alice:1` on
  device 2 — so the escaping applies there too.

  The cost is that retry records written before the upgrade are not reachable
  by session ID afterwards, so a retry request for a message sent before the
  upgrade cannot be served and the sender's peer re-requests or gives up. They
  are not leaked: the expiry sweep and the clear-all path scan the whole record
  prefix and filter on the stored timestamp, so they are reaped on the normal
  retention schedule regardless of key format.

- **BREAKING: the `plaintext_content` envelope type is removed.** It was in the
  relay's message-type union and the client's accepted list, but no send path
  ever produced one and neither decrypt path handled one — an envelope carrying
  it fell through to the pairwise ratchet and failed there. The reference uses
  the corresponding sealed content type to carry a decryption-error receipt
  when no session exists; this SDK delivers those over a dedicated relay
  channel instead, so the type has no role here. The sealed-sender parser now
  rejects the content-type byte outright rather than mapping it to an envelope
  type with no handler. `docs/DEVIATIONS.md` §6.2 records the difference.

  The literal is also gone from the relay's stored `messageType` union, so it
  carries the same deploy-time hazard as the `groupId` removal above: a stored
  row whose `messageType` is `plaintext_content` fails Convex schema validation
  during the push. Clearing the `messages` table handles both at once.

- **Sealed sender reads its content-type enum through a static import.** Four
  call sites in `client/sealed-sender-ops.ts` and
  `client/signal-service-cipher.ts` reached for
  `internal/protocol/sealed-sender/types` with `await import(...)` on every
  seal and unseal, to read `SealedSenderContentType` and the V2 version bytes.
  Two of them were already redundant with a static import of the same module at
  the top of the same file, and `client/client.ts` had none. This is a
  consistency and readability change, not a bug fix: the module has runtime
  exports, so a resolved dynamic import always carries the enum.

- **Sealed sender envelope parsing is now canonical and validated.** Both the
  V1 and V2 inner-envelope parsers accepted a payload with trailing bytes, an
  unrecognized content-type byte, a truncated varint, or a missing content
  hint. Parsing runs after authentication, so none of these was reachable by an
  attacker, but two distinct byte strings could parse to identical content and
  an unknown content type fell through to a routing default. The parsers now
  reject all four, and the content hint is a required field rather than an
  optional one.

- **`maxSenderKeyAge` is bounded at 90 days.** The age-based rotation policy
  already expired locally generated sender keys after a configurable interval,
  defaulting to the 14 days the reference implementation uses, and the group
  send path caught that expiry to rotate and redistribute before retrying. The
  interval itself was unbounded, so a host could configure an age no key would
  reach and switch rotation off without saying so. It is now clamped to 90
  days, the same ceiling the reference applies to its own remotely configured
  value — the difference being that this value comes from the host application
  rather than from the SDK, which is what makes the clamp load-bearing rather
  than belt-and-braces. A sender key is the group material no ratchet
  refreshes, so a member who holds it can read everything sent under it until
  it rotates; membership changes normally force that sooner, and the age bound
  is what covers a group whose membership never changes. A configured value
  that is not a positive finite number now falls back to the default instead of
  being used, since such a value states no policy at all and a zero is far more
  often an unset field than a request to rotate constantly. Both the clamp and
  the fallback log a warning.

- **`maxSenderKeyAge` is also bounded below, at one hour.** The interval had no
  lower bound, and one that is too short fails in a way that is worse than not
  rotating: expiry is enforced on the send path, which answers it by rotating
  the key and fanning a distribution message out to every other member over
  sequential network calls, then retrying the encrypt — against the age of the
  key it just created. Configure an interval shorter than that fan-out takes
  and the retry finds the new key expired too, so every group send fails
  permanently, having burned a rotation and a message to every member on each
  attempt. Since the field is milliseconds, a host that means fourteen days and
  passes `14` reaches this, and it does so without ever sending a message that
  would reveal the mistake in testing.

  Values below the floor are raised to it with a warning rather than rejected.
  Unlike the ceiling this is not a security bound — rotating sooner is strictly
  safer — so the honest reading of an unreachably short interval is "rotate as
  often as this implementation can actually deliver", which is what a host that
  wants aggressive rotation was asking for. An hour clears the worst realistic
  fan-out by a wide margin while leaving deliberately aggressive policies
  intact, which a bound measured in days would not. `SENDER_KEY_AGE_FLOOR` is
  exported alongside `SENDER_KEY_AGE_CEILING`.

  Note what the clamp leaves you with if you hit it by mistake: a host that
  passes `14` meaning days now rotates hourly, which is a distribution message
  to every member of every group every hour. That is functional but not free,
  and the warning is how you find out it is happening — which is the argument
  for clamping rather than rejecting, since the alternative was group messaging
  that simply did not work.

  Separately, the expiry check no longer skips a locally generated key whose
  stored creation time is missing or non-positive. Such a key is the one whose
  life is genuinely unbounded, so waiving the age check on it exempted exactly
  the case the check exists for; it is now treated as expired, which the send
  path answers by rotating to a key whose age is known.

- **Sender key identifiers are now opaque random UUIDs, closing a group
  metadata leak.** A sender key's id was built as
  `groupId:userId:deviceId:timestamp`, and that id travels the wire as the
  SenderKeyMessage `distribution_uuid` — a field outside the ciphertext that
  every relay on the delivery path reads off each group message. Sealed sender
  does not cover this: it conceals the frame from the relay but not from the
  rest of the path, and a deployment may have it disabled. A passive observer
  could therefore reconstruct group rosters by grouping messages on a field it
  cannot be prevented from reading. Ids are now random UUIDv4s carrying no
  group, sender, device, or clock, matching the reference implementation's
  random distribution UUID. The sender-keys specification states the
  requirement in a new section on identifier opacity. This also fixes a
  rotation bug: receivers detect a rotation by
  comparing the incoming id against their stored state, so two rotations inside
  the same millisecond produced an identical id and the second went unnoticed —
  the rotation tests previously needed a `Date.now()` mock advancing a
  millisecond per call to stay green, and now run against the real clock.
- **BREAKING: the Expo store now keeps sender keys on the device instead of
  sending them to a remote store.** Every sender-key and skipped-key operation
  was proxied to an optional `ISignalProtocolRemoteSenderStateStore`, which
  took the chain key and the sender's private signature key as parameters and
  wrote them to whatever backend the application supplied. Those two values
  together are enough to read every message on a sender's group chain and to
  forge new ones, so a server holding them would nullify group message
  confidentiality and authenticity; the skipped-key methods handed over the
  message keys themselves. The reference implementation keeps its sender key
  store local for exactly this reason. No shipped relay implemented the
  interface, so in practice these calls threw and Expo group messaging did not
  work at all — the fix is a real local implementation, not a guard.

  Sender key records and skipped message keys now live in the Expo store's own
  SQLCipher-encrypted database. The `sender_keys` table holds each record as
  one row so a rotation's current and previous states can never be written
  apart, and its `distribution_id` column is renamed `group_id` to match what
  it has always contained. A new `skipped_sender_keys` table replaces the
  remote skipped-key calls and bounds itself by evicting the lowest chain
  indexes first.

  `ISignalProtocolRemoteSenderStateStore` is removed, along with the `relay`
  option on `expoStore()` and the corresponding `ExpoSignalProtocolStore`
  constructor parameter. `expoStore({ relay })` becomes `expoStore()`. The
  `sender_keys` schema change is not migrated: applications own Expo database
  migrations, and any existing rows hold state that should not have left the
  device.
- **Device teardown no longer orphans key material, and the provisioning cron
  no longer risks stalling.** `purgeDeviceStorage` deleted at most 4096 rows
  per prekey table in a single transaction and stopped there. A device's
  one-time prekeys have no ceiling — the component marks a consumed prekey
  rather than deleting it, and no cron reclaims consumed rows — so a
  long-lived device could exceed that and leave the remainder behind, keyed to
  a deviceId a later link reuses. Teardown now deletes a fixed budget and
  schedules a continuation until nothing remains. The device's identity
  registration is always deleted in the first pass and `fetchPreKeyBundle`
  gates on that row, so the device is unreachable the moment teardown returns
  even while the sweep continues. Separately, the provisioning cleanup cron
  swept 100 sessions per transaction while each `linked_pending_ack` row
  cascades into a full device teardown; a cron that exceeds Convex's
  per-mutation limits does not degrade, it stalls, and expired sessions then
  stop being reaped at all. That sweep now uses a batch of 10 and relies on
  its existing self-reschedule for throughput.
- **Provisioning teardown now identifies the device it linked by an opaque
  token rather than a millisecond timestamp.** Device rows are reused across
  registrations, so rollback matched the device's `linkedAt` stamp to avoid
  reaping a device the user had legitimately re-registered into the freed
  slot. Two links landing in the same millisecond on the same slot produce
  equal stamps, and teardown would then unlink the wrong — newer — device.
  Every registration and link now mints a `linkToken`; it is never returned to
  clients. A test that removes and re-registers without advancing the clock at
  all fails against the old stamp comparison.
- **Removed five exported Convex row types that described tables no consumer
  can read.** `ConvexIdentityKey`, `ConvexEcSignedPreKey`, `ConvexEcPreKey`,
  `ConvexKemPreKey`, and `ConvexKemLastResortPreKey` were unreferenced and
  every one of them disagreed with `component/schema.ts`: all five omitted the
  `identityType` discriminator, `ConvexIdentityKey` claimed a `deviceId` and a
  raw `publicKey` where the real table holds a per-account
  `compositeIdentity`, and both one-time prekey types documented that keys are
  "DELETED when consumed" when the component marks `consumedAt` and leaves the
  row for the sweep. The premise was wrong to begin with — the component's
  tables are isolated, so an application cannot obtain these rows under any
  type. The file header claiming nine component tables, one of them a
  `prekeyBundleFetches` table that no longer exists, is corrected. The
  surviving `FetchedPreKeyBundle` is now derived from the component's own
  return validator instead of hand-written, so it cannot drift again.
- **`ConvexSignalProtocolRelayApi` now carries real argument and return
  types.** Its 43 function references were declared as bare
  `FunctionReference<'mutation'>` / `<'query'>`, so every argument the relay
  adapter passed to the component was `any` and a mismatch surfaced only as a
  runtime validator rejection in the deployment. The type is now *derived*
  from `defineConvexSignalProtocolBackend`'s return type via `ApiFromModules`
  rather than restated by hand, which is what makes it meaningful — a
  hand-written contract can drift from the functions it describes, and this
  one had. The `getProvisioningMessage` return cast is removed as a
  consequence: the reference now carries the component's own return
  validator, so a component change that stops satisfying the interface fails
  to compile instead of being cast away.
- **Fixed sealed-sender fallback detection**, which decided whether to retry a
  failed sealed send on the identified path by testing whether the error
  message contained the substring `'Unauthorized'`. That was wrong in both
  directions: any unrelated failure whose message happened to contain the word
  — a rate limit, an app-level wrapper — downgraded the send to identified
  delivery and disclosed the sender to the relay, while a genuine
  `code: 'UNAUTHORIZED'` rejection whose message did not spell the word went
  undetected and surfaced as a hard send failure. Detection now reads the
  structured `ConvexError` payload; the string contract is removed with no
  fallback.
- **Rewrote `docs/SCHEMA.md`.** It described a 7-table schema the application
  was instructed to define itself, with a multi-tenant `appId` column, index
  names, a `deliveredAt` field, and a `sender_key_distribution` message type
  that exist nowhere in the codebase, plus cleanup crons the component already
  runs. The component owns all sixteen tables; the document now describes what
  is stored, what the relay can and cannot see, and the real retention
  behavior.

- **Sealed sender can now be enabled.** `oe-groups trust-root` exports the
  Ed25519 sender-certificate root alongside the group trust root, printing both
  labeled (`group trust root:` / `sealed sender trust root:`). Previously only
  the group root was printed, so there was no supported way to obtain the value
  clients pin in `sealedSender.trustRoots`; inbound sealed-sender validation
  stayed disabled and every send fell back to identified delivery, disclosing
  the sender to the relay. The derivation now lives in one shared module
  (`internal/protocol/sealed-sender/trust-root`) used by both the CLI and the
  relay's certificate issuance, so the printed root cannot drift from the key
  the deployment signs with, and a contract test pins the two as equal.
  Corrects the `sealedSender` configuration docs, which required a
  `SEALED_SENDER_SIGNING_KEY` environment variable that has never existed.

- **`getProvisioningMessage` now returns `expiresAt`**, the session's absolute
  deadline in epoch milliseconds (`null` when the session is unknown). The
  Convex component already returned it, but the relay interface did not declare
  it and the adapter cast it away, so no client could compute expiry locally.
  The mock relay was brought to parity at the same time: it models the
  acknowledgment's own TTL window granted by `completeProvisioning` — without
  which a link completed near the deadline strands a device the client has
  already persisted keys for — rejects expired sessions in
  `connectNewDevice`, `sendProvisioningMessage`, `completeProvisioning`, and
  `acknowledgeProvisioning`, and reports expiry as a computed status instead of
  writing `expired` from inside a read. The shared relay contract suite now
  pins all three behaviors.
- **Security (Convex component):** the component now declares
  `OE_GROUPS_SERVER_SECRET` as a typed component environment variable and
  reads it through the declared-environment accessor. Convex components are
  isolated from app deployment environment variables, so the previous
  `process.env` read was unreachable in any real `app.use()` install and
  every group, credential-issuance, and sender-certificate call failed at
  runtime; apps must forward the secret with
  `app.use(signalProtocol, { env: { OE_GROUPS_SERVER_SECRET: app.env.OE_GROUPS_SERVER_SECRET } })`.
  The test-only injection seam is now default-deny: it refuses configuration
  outside a recognized test runner instead of allowing it whenever a
  deployment marker is absent.
- **Breaking (relay API):** removed `getGroupMembers` from the relay surface
  — the component, the app wrapper, `ConvexSignalProtocolRelayServer`, the
  mock adapter (including its `setGroupMembers` test seam), and
  `ISignalProtocolRelayServer`. The relay keeps no server-side group
  membership map by design; relayed group sends now require
  `SendOptions.groupMemberUserIds`, which the relay resolves to devices via
  `getActiveDevices`. Group sends without a roster previously dropped the
  message to zero recipients while reporting success.
- Fixed cross-sender message suppression: `clientMessageId` deduplication is
  now scoped to the sending account. The key was previously
  `(targetUserId, targetDeviceId, clientMessageId)`, so two senders that mint
  non-random client message IDs — a counter or a timestamp — silently
  suppressed each other's messages to a shared recipient, and the suppressed
  sender was handed the other sender's message ID and server timestamp.
  Same-sender retries still collapse as before.
- Documented two properties the component does not provide, both previously
  unstated or overstated. **Group metadata privacy:** the relay can still
  approximate a group's recipient set from delivery metadata — `messages` rows
  carry a plaintext `groupId`, and the unencrypted `distributionUuid` in the
  SenderKeyMessage frame embeds `groupId:senderUserId:senderDeviceId` — so the
  component README's previous claim to keep no membership map has been
  corrected to describe what removing `getGroupMembers` actually buys. Closing
  the leak requires opaque distribution identifiers in the sender-key layer and
  is tracked separately. **Device-scoped authorization:** `identify` resolves an
  account, not a device, so every `deviceId` argument is a caller-chosen
  routing selector and any session for an account can drain that account's
  other device queues, send as any of its device IDs, and rotate any of its key
  material.
- Fixed silent message loss for skipped multi-recipient sealed-sender
  recipients: the client now consumes the server's `uuids404` list,
  refreshes those users' device lists, and redelivers per-device instead of
  discarding the field while reporting the send as delivered.
- Fixed provisioning acknowledgment data loss: completing a session now
  grants the acknowledgment its own full session TTL (previously the ack
  deadline was whatever remained of the original five-minute window, and
  the every-minute cleanup cron could delete the freshly linked device
  before the ack arrived), `acknowledgeProvisioning` rejects expired
  sessions instead of racing the cron for the device's survival, and
  session teardown deletes only the device the session created (matched by
  its `linkedAt` stamp) with a full cascade of its key material, queued
  messages, and heartbeats. Dead `patch`-before-`throw` writes that Convex
  transaction rollback always discarded were removed, along with the never
  persisted stored `expired` status; `getProvisioningMessage` now also
  returns `expiresAt` so subscribed clients can compute expiry locally.
- Retry requests now expire with the same seven-day TTL as messages, backed
  by an hourly cleanup cron; `getPendingMessages` and
  `getPendingRetryRequests` filter expired rows at read time instead of
  serving them until the next cron pass.
- Reduced write contention on the per-account identity row: mutations now
  skip the account patch when the caller's identity bytes are unchanged,
  instead of unconditionally rewriting the row (an OCC conflict hotspot
  between a user's own concurrent mutations and sealed sends addressed to
  them).
- Corrected the exported `FetchedPreKeyBundle` type to the actual wire shape
  (`registrationId`, `ecSignedPreKey`, `ecOneTimePreKey`,
  `kemLastResortPreKey`, `kemOneTimePreKey`); the previous declaration
  omitted `registrationId` and named four of five fields incorrectly.
- `getActiveDevices` now caps its device scan at `MAX_DEVICES` instead of a
  hardcoded 5, and the missing-snapshot guard in `getGroupChanges` throws
  structured `ConvexError` data instead of a plain `Error`.
- Extended the installable Convex component to own the complete relay backend,
  adding isolated devices, identity and prekey storage, message and retry
  queues, provisioning sessions, and sender-certificate issuance behind five
  new public wrapper namespaces.
- Added `@convex-dev/rate-limiter` as an optional child component and enforce a
  ten-per-minute prekey-bundle fetch limit for each authenticated
  fetcher/target pair.
- Standardized component rejections on structured `ConvexError` data carrying
  `{ code, status, message }`, including sealed-sender authorization failures
  that retain an `Unauthorized:` message prefix for current client fallback
  handling.
- Added an installable Convex component defined as
  `defineComponent('signalProtocol')`, with isolated group state, change, and
  snapshot tables plus a `defineConvexSignalProtocolBackend()` app-wrapper
  factory. The credential-issuance wrappers resolve application identity and
  pass explicit ACI and optional PNI bytes into the component; group
  operations remain authorized solely by their zero-knowledge presentations
  and carry no caller identity.
- Added the `@open-e2ee/signal-protocol-sdk/convex.config` export for mounting
  the component with `app.use(signalProtocol)`.
- **Breaking (Convex group backend):** removed `defineConvexGroupServer`,
  `defineConvexGroupServerForTest`, `convexGroupServerTables`, and the
  `@open-e2ee/signal-protocol-sdk/remote/relay/convex/server` export. The
  pre-launch factory and app-owned tables are replaced directly by the
  component and wrapper, with no compatibility aliases.

## 0.1.0-alpha.7

- **Security (Convex group server):** structured rejection data now survives
  real deployments. Engine rejections and the adapter's own conflict and
  missing-group rejections are thrown as `ConvexError` values carrying
  `{ code, status, message }`; production Convex strips custom properties
  from plain errors, which silently disabled the client's documented
  `VERSION_CONFLICT` rebase-and-retry path on live deployments.
- Fixed the Convex group server reading snapshots and changes through a
  partial index range with a post-filter, which scanned every stored row for
  the group on each lookup; catch-up reads for long-lived groups could exceed
  Convex transaction limits and permanently fail. Snapshot lookups now use
  the full compound index and change reads constrain the version range in
  the index.
- **Security (groups):** the pending-member, requesting-member, and
  banned-member collections are now bounded by the same 1000-entry limit as
  full members, enforced during change application and on every validated
  state, with the client-side structural validation mirroring the caps. A
  single change could previously inflate a group's stored state without
  bound.
- The Convex group server now derives its server parameters once per isolate
  and caches them keyed by the environment secret, instead of re-deriving on
  every request; the deployment seed is also zeroized when validation of the
  configured secret fails, and `identify()` returning no identity is
  rejected with a structured `UNAUTHORIZED` error instead of a `TypeError`.
- Fixed `oe-groups trust-root` failing on Windows by importing its runtime
  modules via `file://` URLs.
- **Security (relay group bridge):** `ConvexSignalProtocolRelayServer.submitGroupChange`
  now rejects legacy six-argument submissions carrying a caller-selected
  epoch, matching `ConvexGroupServer`'s S13 guard; the relay bridge is now
  certified by its own run of the §14 conformance suite, and endorsement
  issuance is cryptographically verified against the reference server in the
  parity suite.
- Documented that the Convex group-server modules must be mounted inside the
  relay's generated `api.signal` namespace (`convex/signal/groups.ts` and
  `convex/signal/zkAuth.ts`); the previous top-level placement compiled
  cleanly but never enabled the relay's `groupServer` capability. Also
  documented snapshot-retention growth, the placeholder-PNI prohibition for
  `identify()`, and updated `docs/DEVIATIONS.md` to describe the enforcing
  group server and its unblinded profile-key issuance deviation.
- Added the production `defineConvexGroupServer` integration at
  `@open-e2ee/signal-protocol-sdk/remote/relay/convex/server`, including
  package-scoped canonical-state, signed-change, and historical-snapshot
  tables; S1–S14 enforcement; auth/profile-key credential issuance;
  group-send endorsements; environment-secret custody; and the
  `oe-groups trust-root` CLI. Profile-key credential issuance receives the
  raw profile key and is not blinded. The public
  `ConvexSignalProtocolRelayApi` now makes `groups` and `zkAuth` optional,
  and the relay advertises its `groupServer` capability only when both API
  modules are configured.
- **Breaking (groups):** client configuration now accepts one versioned,
  serialized `trustRoot` instead of separate credential, change-signing,
  profile-key credential, and endorsement trust fields. Group identities are
  derived from the client's own identity configuration, and group state
  defaults to the SDK storage layer. Relays may expose an optional
  `groupServer` capability containing the server and credential-issuance
  transports; clients use it automatically while retaining explicit server
  and issuer overrides for custom deployments. Configuring groups without
  either the relay capability or complete explicit overrides now fails with a
  targeted configuration error, and configured endorsement verification must
  match the endorsement root in the pinned blob. No compatibility aliases are
  provided.
- **Breaking (groups): removed the borrowed `v2` naming from the group
  system.** `GroupsV2Manager` is now `GroupManager`,
  `GroupsV2ManagerOptions` is now `GroupManagerOptions`, the client
  configuration key is now `groups`, and the client group methods no longer
  carry a `V2` suffix. The implementation now lives entirely under
  `internal/groups/`. No compatibility aliases are provided.
- **Breaking (group identifiers):** `GROUP_V2_PREFIX` is now
  `GROUP_ID_PREFIX`, and group IDs use the package-owned
  `open-e2ee:group:` prefix. The pre-launch prefix has no migration or
  dual-read path.
- **Breaking (group validation):** `validateChange` is now
  `validateChangeStructure` to make clear that it checks well-formedness, not
  authorization. It now rejects already-banned additions and promotion
  targets that are absent after explicit ACI/PNI-to-ServiceId widening.
- **Breaking (group membership):** group setup now requires the account's
  profile-key credential issuer, trust root, and 32-byte profile key.
  `createGroup()` and `addGroupMember()` accept either a target with verified
  presentation material for an immediate add or a ServiceId-only invitation;
  invited targets call `acceptGroupMemberInvitation()` and present their own
  profile key. The old `{ aciBytes, profileKey }` direct-add path is removed,
  and runtime inputs must match exactly one variant's complete field and byte
  domains instead of being omitted, partially discarded, or processed
  ambiguously.
- Fixed pending-member promotion comparing 16-byte ACI/PNI values directly
  with 17-byte ServiceIds, silently skipping valid promotions. Promotions now
  fail when the pending entry is absent or the destination is already a
  member, preserve the invited role, and apply in the normative action order.
- Fixed `AccessRequired.ANY` excluding non-members, and implemented the full
  target-sensitive group authorization table including self-leave,
  self-decline, self-withdraw, invite-link requests, and member-label access.
- Fixed group mutations encoding their editor as a raw 16-byte ACI instead of
  a canonical 17-byte ServiceId, and consistently use full ServiceIds for
  authorization principals and banned-member checks.
- Fixed encrypted group state storing only the 32-byte group identifier in
  `publicKey`; it now stores the canonical 96-byte serialized
  `GroupPublicParams` required for credential verification.
- **Breaking (group server contract):** group changes now carry exact
  server-accepted `actions`, `changeEpoch`, and the independently presented
  invite-link password; clients no longer submit a replacement encrypted
  snapshot. Group servers must also implement the password-gated reduced
  `getGroupJoinInfo` read and exact-version `getGroup` snapshots for race-safe
  post-join baselines. Every full-state response now carries a
  `baselineSignature` over its group ID, version, and exact encrypted-state
  bytes; clients accept signed snapshots only for a first baseline or after
  their own verified revocation ends an entitlement span. Change submissions
  no longer carry a caller-selected epoch: the server derives epoch 0, 5, or
  6 from the canonical accepted actions and signs it, and clients recompute
  the same value exactly before applying the change.
- **Security (groups):** every applied change is now checked for its server
  signature, group binding, strict sequence, pre-state authorization, and
  structural validity. Signatures bind the exact accepted actions together
  with their compatibility epoch.
- **Breaking (group state storage):** `IGroupStateStore` now atomically stores
  accepted state with a durable sender-key rotation barrier and exposes
  revision-checked barrier read/clear methods. Removal, ban, and termination
  block every group-send path until rotation succeeds, including after
  callback failure or client reconstruction. Endorsement invalidation remains
  non-fatal.
- **Security (group sending):** managed groups now require verified accepted
  state at send time showing an unterminated group, current ACI membership,
  and no ban on either of the sender's own identifiers. A stored master key
  with missing state fails closed until sync restores a verified baseline;
  ad-hoc sender-key groups with no group master key remain unaffected.
- **Security (group governance):** every non-terminated group must retain at
  least one stored administrator. Creation, server-side atomic application,
  complete-state client transitions, and signed baselines enforce the same
  result-state invariant; last administrators may leave only while installing
  a successor atomically. The deliberately member-free invite-link projection
  remains private and is exempt only for its single additive self-join or
  self-request action, with direct membership installed through the complete
  signed baseline that follows.
- **Security (groups):** authentication credentials now represent a missing
  PNI as true absence instead of a shared nil-UUID principal. Issuance and
  client encryption/decryption reject nil identifiers; the reference server
  applies ACI/PNI alias matching to roles, reads, bans, deterministic
  attribution, and requester-specific pending status without attempting to
  decrypt opaque identifiers.
- **Security (groups):** access-control fields now enforce their
  specification-defined domains on creation, mutation, and decryption.
  Out-of-domain hostile state fails closed, so `members = ANY` cannot become a
  password-free self-add or third-party recruitment path.
- **Security (groups):** every creation or action path that introduces or
  changes a profile-key ciphertext now requires a credential presentation
  bound to the submitted ACI, profile key, and group. Missing, empty, or
  mismatched proofs are rejected, pending invitations carry no profile
  material, and verified request credentials are stripped before state or
  signed history is persisted.
- **Security (group creation):** creation submissions no longer carry
  client-asserted invitation provenance or pre-existing requesting and banned
  entries. The enforcing server derives the creator and timestamp, signs only
  canonical version zero, and the creator verifies and caches that exact
  baseline instead of its optimistic submission.
- **Security (groups):** group actions now have exact per-action field
  surfaces. The reference relay rejects client-asserted inviters, timestamps,
  join revisions, labels, and PNIs where those fields are not defined; derives
  accepted provenance and join metadata itself; and signs only that canonical
  form. One shared exhaustive wire-domain validator makes the reference server
  reject malformed submissions before applying or signing and makes clients
  reject malformed signed actions and baselines before decrypting or
  installing them, including wrong primitive, container, byte, enum,
  timestamp, and join-revision types.
- **Security (groups):** nil or undecryptable pending, requesting, and banned
  entry targets are now retained byte-for-byte as inert quarantined entries
  instead of making a signed revision permanently unappliable. Activation
  targets remain strict, and administrator delete actions can remove
  quarantined entries by their preserved ciphertext.
- **Security (groups):** change-log reads in the executable reference server
  are authorized at the requested historical snapshot and include the first
  signed transition that removes, bans, or un-invites the requester, while
  withholding every later transition.
- Fixed PNI-to-ACI promotion when both ACI- and PNI-keyed invitations exist.
  Equal-role aliases are consumed atomically into one ACI member; conflicting
  roles are rejected by both authorization monitors and can be resolved by
  declining either invitation before promotion. Self-decline attribution now
  follows the invitation alias named by the action, including when the same
  requester also matches an ACI membership.
- **Breaking (groups):** omitting `serverSigningPublicKey` no longer silently
  selects unsigned group history. Deployments without a conforming signing
  server must explicitly set `allowUnauthenticatedGroupHistory: true`, which
  continues to emit the documented security warning.
- The development-only in-memory relay is now the executable reference for the
  complete encrypted group-server authorization contract: zk presentation
  verification, server-derived requester attribution, pre-state authorization,
  atomic sequencing, group binding, exact-byte signing, reduced invite reads,
  independent invite-password checks, ACI/PNI field separation, and
  representation-independent structural validation. Repeated invite joins are
  idempotent. No production enforcing group server is supplied; explicitly
  opting into operation without a pinned signing key emits the documented
  non-conforming-deployment warning.
- Fixed `deserializeGroupPublicParams()` calling CommonJS `require()` from the
  ESM package, which crashed the first real server-side group credential
  verification before the proof could be checked.

## 0.1.0-alpha.6

- **Breaking (key derivation): the X3DH and PQXDH info strings now name this
  application and this KEM.** `X3DH_INFO_DEFAULT` becomes `OpenE2EE` and
  `PQXDH_INFO_DEFAULT` becomes `OpenE2EE_X25519_SHA-256_ML-KEM-1024`; they were
  `WhisperText` and `WhisperText_X25519_SHA-256_CRYSTALS-KYBER-1024`. Both
  parameters were wrong. PQXDH §2.2 requires the info string to name the
  `pqkem` actually in use, and the SDK runs ML-KEM-1024 (FIPS 203), not
  round-3 CRYSTALS-Kyber — so two implementations feeding an identical label
  derived _different_ shared secrets, which is precisely what the info string
  exists to prevent. And §2.1 defines `info` as an identifier of the
  application deriving the key; this SDK is not Signal Messenger. **Sessions
  established under the old labels derive a different `SK` and cannot be
  continued** — clear session state or re-establish. Nothing else about the
  derivation changed. An application that needs `libsignal`'s known-answer
  vectors can still set `protocolStrategy.keyExchangeInfoString` to the old
  label explicitly. `docs/DEVIATIONS.md` §2.1 recorded this as an open
  specification violation and now records it as fixed.
- **Breaking (naming): every remaining exported identifier spelled `Signal`
  now spells `SignalProtocol`.** "Signal" alone names a product and an
  organization this project has no affiliation with; the specifications it
  implements are the Signal Protocol, and the exported names now say so. This
  renames roughly ninety exports — `MockSignalStore` to
  `MockSignalProtocolStore`, `ISignalLocalStore` to `ISignalProtocolLocalStore`,
  `SignalServiceCipher` to `SignalProtocolServiceCipher`, `defaultSignalLogger`
  to `defaultSignalProtocolLogger`, `SignalMessage` and `PreKeySignalMessage` to
  `SignalProtocolMessage` and `PreKeySignalProtocolMessage`, and so on
  throughout. No aliases are provided. Nothing on the wire changes: the message
  type names were protobuf type labels, which protobuf does not serialize, and
  every domain-separation and key-derivation constant is untouched — including
  the `Signal_ZKGroup_*`, `Signal_ZKCredential_*`, and `Signal_PQCKA_*`
  families, which are byte inputs to key derivation rather than names.
- The public-surface guard now asserts that each retired name stays absent, and
  is typechecked in CI. It is entirely type-level, so running it under jest —
  which transpiles without typechecking — could never have failed; only `tsc`
  can catch a reintroduced name.
- **Breaking (`SessionEstablisher`): `failedDeviceErrors` is now required.** The
  exported `SessionEstablisher` type declared it optional, so an implementation
  could return a result that said nothing about which devices failed and why.
  Every implementation must now return the array; return `[]` when nothing
  failed. Implementations that already populate it need no change.
- Changed device establishment to surface a failing device's own error instead
  of a generic wrapper, and to route it through the retry classifier so a
  transient failure is retried rather than failing the whole send on the first
  attempt.
- Fixed the retry classifier treating permanent session-establishment failures
  as retryable. `UNTRUSTED_IDENTITY`, `SIGNATURE_VERIFICATION_FAILED`,
  `RECIPIENT_NOT_REGISTERED`, and `PREKEY_FETCH_RATE_LIMITED` now fail
  immediately. They reach the classifier only because of the change above;
  retrying a security event delays it reaching the caller, and retrying a
  prekey-drainage rate limit aggravates the condition it reports.
- Fixed the exported in-memory relay delivering reorder-buffered envelopes to a
  first subscriber, which duplicated messages that reordering had already held
  back, and fixed reorder state being lost when a subscriber was replaced.

## 0.1.0-alpha.5

- **Breaking (wording and one error message): "Signal" is no longer used as a
  loose shorthand.** Prose names the specifications "the Signal Protocol", the
  product "Signal Messenger", and the reference implementation `libsignal`;
  shipped source comments say "the reference implementation". Compatibility
  shorthand such as "Signal-style", "Signal-aligned", and "Signal-grade" is
  gone. Protocol domain-separation strings are untouched and remain
  byte-identical. The Expo storage error message no longer carries a "Signal
  Protocol " prefix; it now reads `Expo storage DB bindings not configured.
Configure them from the host app before using Expo storage.` Anything
  matching on that text must be updated.
- Corrected group-system source comments that described the permission model as
  server-enforced. The checks in `access-control.ts` run on the client over
  already-decrypted state and bind an honest client, not a hostile one — the
  server sees only opaque state and a version number. Change application order
  is this SDK's own choice, taken from the proto field numbering for
  determinism, not an order the specifications define; and the SDK does not
  encrypt avatar content.
- Changed the exported in-memory relay to upsert EC and KEM one-time prekeys by
  `keyId`. Re-uploading a batch is now idempotent; consumers that relied on
  duplicate uploads inflating prekey counts will observe the corrected count.
- Changed the exported in-memory relay to enforce device IDs 1-5 and the
  production-contract `Maximum devices limit reached` error. Removed and
  disabled devices are excluded from active fanout, and unknown users now have
  no invented device.
- Fixed `MockSignalProtocolRelayServer.clear()` retaining idempotency receipts, which
  made a reused `clientMessageId` look already accepted after reset.
- Fixed the exported mock store and relay to structured-clone mutable values at
  every persistence/API boundary, matching serialization ownership in durable
  adapters for sessions, users, devices, prekeys, sender keys, and envelopes.
- Added opt-in, seeded mock failure controls for latency, disconnect/reconnect,
  duplicate and reordered delivery, storage writes, authorization rejection,
  and one-time-prekey exhaustion. Default construction is unchanged.
- Fixed duplicate relay delivery requesting a SESAME resend after the session
  layer had already rejected the replay, which could surface plaintext twice.
  Duplicate envelopes are now acknowledged without a retry request.
- Fixed session-establishment persistence failures being misreported as a
  problem with the peer. An adapter failure at the atomic commit seam now
  surfaces as `KEY_STORAGE_ERROR` with the adapter failure retained as the
  cause, instead of `RECIPIENT_NOT_REGISTERED` or `INVALID_PREKEY_BUNDLE`, so
  applications retry their own storage rather than refetching a bundle.
- Added shared storage contracts for Mock, Node, Web/IndexedDB, and Expo
  adapters, plus an extensible relay contract. Fixed Web/IndexedDB `UserRecord`
  decoding so `DeviceRecord.identityKey` remains an owned `Uint8Array`.
- Documentation now labels mock examples as real protocol and cryptography over
  simulated in-memory infrastructure. CI executes every classified mock snippet
  from the shipped onboarding, recipe, composition, and pricing docs against
  the packed package.
- Fixed the npm publish workflow folding registry warnings into the value it
  read as the current `latest` version. A warning containing a hyphen parsed as
  a prerelease, which after a stable release would have routed a prerelease to
  the `latest` dist-tag.

## 0.1.0-alpha.4

- **Security: a forged message header could force unbounded key derivation
  before authentication.** When an inbound message triggered a DH ratchet, the
  loop that drains the previous receiving chain ran once per message claimed by
  the header's `previousCounter` field — an attacker-controlled value that is
  not authenticated, and cannot be, because the message key that would
  authenticate it is what the loop derives. A single forged header could
  therefore pin a CPU and grow the session record without bound, from an
  unauthenticated sender. The catch-up is now bounded by the same skip limit
  that already governed the current chain, and rejects before deriving or
  storing anything.
- **Fixed: registration IDs could be generated as `16384`,** one past the 14
  bits the wire format reserves. Multi-recipient sealed sender masks with
  `0x3FFF` rather than rejecting, so such an ID was written to the wire as `0`,
  affecting roughly 1 install in 16,384. The range is now `[1, 16383]`.
- Fixed: the `AuthCredentialPresentation` documentation stated its privacy
  property backwards, describing the server as able to decrypt the ACI and PNI
  ciphertexts to learn which member is authenticating. The server verifies the
  proof without learning the member; only holders of the group's secret params
  can decrypt. The comment ships in the public package.
- Docs: `docs/DEVIATIONS.md` records where this profile follows, deliberately
  departs from, and extends the Signal Protocol specifications, and states
  plainly that the SDK is not wire-compatible with Signal Messenger or
  `libsignal`.

## 0.1.0-alpha.3

- Fix: the first inbound responder session is no longer archived into itself
  when a storage adapter surfaces device records synthesized from live protocol
  state; SESAME device state is snapshotted before protocol decryption, so a
  brand-new session can never appear pre-existing. Receiving on that session
  now records responder metadata correctly.
- Tests: the SESAME "Receiving Messages" spec suite now exercises the real
  SesameManager end to end (previously a file-local mock), covering active-
  session receive, responder synchronization, delayed and out-of-order
  delivery, transactional PreKey persistence, and identity replacement.

## 0.1.0-alpha.2

- **Fixed: every first message from a new contact was reported as an identity
  key change.** The receiver pinned a device's identity as the bare 32-byte
  X25519 key but compared incoming PreKeyMessages against the 67-byte versioned
  X25519 + Ed25519 composite tuple. The two encodings could never be equal, so
  first contact logged a SECURITY warning, fired `onIdentityKeyChanged` and
  `onSecurityEvent('identity_key_changed')`, and set `pendingVerification` -
  which gates sending. Apps surfacing those events showed a "safety number
  changed" warning to users who had never talked before, training them to
  dismiss the one warning that matters. First contact is now trust-on-first-use
  as documented; a genuine identity change on an already-pinned device still
  raises the event.
- **`DeviceRecord.identityKey` is now always the 67-byte composite tuple**, the
  same identity the relay publishes and safety numbers are computed over, so
  pinning and verification finally refer to the same thing. Zero length still
  means unpinned. `SesameManager.addDevice()` and `syncDeviceList()` reject
  identity bytes that are not a valid composite tuple instead of pinning a
  partial key. **Breaking for persisted state:** device records written by
  `0.1.0-alpha.1` hold 32-byte keys and will be treated as a changed identity.
  No migration is provided - this is pre-`1.0` and the alpha is not deployed;
  clear device records or re-pair.
- Fixed the mock storage adapter unpinning a device as soon as its session was
  archived, and dropping `pendingVerification`, which defeated the send gate.
- Fixed `syncDeviceList()` treating a device list carrying no identity keys as
  an identity change for every device, dropping live sessions and raising a
  security event on each sync.
- Added `keys.canonicalizeDeviceIdentityKey()`, `keys.isValidDeviceIdentityKey()`,
  `keys.compareDeviceIdentityKeys()`, and `keys.UNPINNED_DEVICE_IDENTITY_KEY`.
- Docs: signed prekey and Kyber last-resort prekey rotation is driven by
  `KEY_REFRESH_INTERVAL_MS_DEFAULT` (2 days), not the weekly cadence the JSDoc
  and prekey docs claimed. `docs/ERROR_HANDLING.md` no longer references a
  `signal.trustIdentity()` method that does not exist; the real API is
  `acceptIdentityRotation()`.

## 0.1.0-alpha.1

- Initial public alpha for the OpenE2EE Signal Protocol SDK's independently versioned,
  Signal Protocol-based APIs.
- Public package surface is dist-first with explicit platform and backend subpaths.
- Remote object uploads separate retry `requestId`s, canonical `objectId`s, and
  private provider keys. The Convex R2 integration accepts generated app modules
  directly and provides an optional server-only broker helper.
- ML-KEM Braid HEK follows the normative
  `SHA3-256(ek_seed || ek_vector)` order. Pre-release Braid sessions created
  with any earlier nonconforming order must be reset.
