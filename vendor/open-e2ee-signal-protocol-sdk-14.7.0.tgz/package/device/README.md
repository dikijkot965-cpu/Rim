# Device Lifecycle, Linking, and Transfer

The device module contains the platform-bound workflows for device identity,
registration, device-name encryption, and encrypted device-to-device state
transfer.

## Why it exists

Signal Protocol sessions address individual devices. The application therefore
needs a lifecycle that coordinates a locally persisted device ID with the
authenticated backend's device registry.

A linked device needs the account identity before it joins the account. Three
separate operations do that work:

- **Transfer** sends an identity-only bundle over an application-owned
  encrypted device-to-device channel. The receiving device generates fresh
  prekeys and sessions after import. The application can also put the account
  identity into the new device's store by a channel that it owns.
- **The managed device link** is `linkHostedSignalProtocolRelayDevice()` from the package
  root. It joins a store that already holds the account identity to the Relay
  account. Only the primary device (device 1) can link a device. The call runs
  in one process that holds the primary device's store and the new device's
  store. It sends no private key to the Relay.
- **The two-device link** joins a new device that has an empty store. The new
  device calls `joinHostedSignalProtocolRelayAccount()` and shows a link code.
  The primary device scans the code and calls
  `approveHostedSignalProtocolRelayDeviceLink()`. Show a confirmation screen
  on the primary device before it approves. See
  [`joinHostedSignalProtocolRelayAccount()`](../docs/api/functions/joinHostedSignalProtocolRelayAccount.md)
  and
  [`approveHostedSignalProtocolRelayDeviceLink()`](../docs/api/functions/approveHostedSignalProtocolRelayDeviceLink.md).

  Private keys can move between the devices of one user. They move only
  inside an end-to-end encrypted envelope. The envelope uses hybrid X25519 and
  post-quantum ML-KEM-768 key agreement. The Relay carries the envelope and
  cannot decrypt it.

The primary device removes a linked device with
`removeHostedSignalProtocolRelayDevice()`, and any device can remove itself.
Removal is a Relay revocation only. The removed device keeps the account
identity key pair and the group master keys that it had. For a lost or stolen
device, run an account recovery. See
[`removeHostedSignalProtocolRelayDevice()`](../docs/api/functions/removeHostedSignalProtocolRelayDevice.md).

The new device names itself with `hosted.deviceName` at the join. The primary
device renames any device with `renameHostedSignalProtocolRelayDevice()`, and a
linked device renames only itself. The SDK encrypts each name to the account
identity key. See
[`renameHostedSignalProtocolRelayDevice()`](../docs/api/functions/renameHostedSignalProtocolRelayDevice.md).

The primary device uses ID `1`. The backend allocates linked device IDs from
`2` through `5`. A client must not choose its own linked-device ID.

## Platform requirements

The shared device entries import no platform package. They keep the device ID
and lifecycle state in the `SignalProtocolLocalSecretVault` that the
application passes, and they take platform metadata as an input. They omit each
metadata field that the application does not supply.

Two platform entries read that metadata. Install the peers of the entry that
you use.

`@open-e2ee/signal-protocol-sdk/device/expo` reads `react-native` 0.83.6 or
later, `expo-constants` 55.0.7 or later, and `expo-device` 55.0.15 or later.

```sh
npx expo install react-native expo-constants expo-device
```

`@open-e2ee/signal-protocol-sdk/device/react-native` reads `react-native`
0.83.6 or later and `react-native-device-info` 15.0.1 or later.

```sh
npm install react-native react-native-device-info
```

The lifecycle core is available from:

<!-- doc-snippet:skip requires-external-context -->
```ts
import { DeviceLifecycleManager } from "@open-e2ee/signal-protocol-sdk/device/lifecycle";
import { getDeviceLifecyclePlatform } from "@open-e2ee/signal-protocol-sdk/device/expo";
import { ExpoSecureStoreSignalProtocolSecretVault } from "@open-e2ee/signal-protocol-sdk/local/vault/expo-secure-store";

const manager = new DeviceLifecycleManager(userId, {
  vault: new ExpoSecureStoreSignalProtocolSecretVault(),
  convex,
  api,
  keyStorage,
  logger,
  ...getDeviceLifecyclePlatform(),
});
```

`DeviceLifecycleManager` takes the user ID and a `DeviceLifecycleDeps` object.
That object holds the secret vault, the Convex client, the generated backend
references, key operations, logging, and device metadata. The constructor
throws an `EncryptionError` with code `SECRET_VAULT_REQUIRED` when the vault
is absent. The application remains responsible for authenticated backend
functions and for placing initialization in its own startup lifecycle.

## Device ID access

<!-- doc-snippet:skip requires-external-context -->
```ts
import {
  getDeviceId,
  preloadDeviceId,
} from "@open-e2ee/signal-protocol-sdk/device/device-id";

await preloadDeviceId(secretVault);
const deviceId = await getDeviceId(secretVault);
```

Both functions read the device ID from the application's
`SignalProtocolLocalSecretVault`. With no vault, they throw an
`EncryptionError` with code `SECRET_VAULT_REQUIRED`.

`getDeviceIdSync()` returns the cached value or the primary-device default. Use
it only after preload or in code that can safely tolerate that fallback.

## Link a device

Put the account identity into the new device's store first, by device transfer
or by a channel that the application owns. Then join the new device to the
Relay account:

<!-- doc-snippet:skip requires-external-context -->
```ts
import { linkHostedSignalProtocolRelayDevice } from "@open-e2ee/signal-protocol-sdk";

const signalRelayUrl = process.env.OPEN_E2EE_SIGNAL_RELAY_URL!;
const client = await linkHostedSignalProtocolRelayDevice({
  adapters: { storage: linkedStorage },
  activeDeviceStorage,
  hosted: { relayUrl: signalRelayUrl },
});
```

`activeDeviceStorage` is the store of the primary device (device 1). Only the
primary device can link a device. On another device, the call throws
`HostedSignalProtocolRelayDeviceProvisioningError` with the code
`NOT_PRIMARY`. Without `hosted.adapter`, the call throws it before it writes to
a store or sends a request. With a custom `hosted.adapter`, the Relay refuses
the link, and the adapter's `HostedSignalProtocolRelayHttpError` has the code
`NOT_PRIMARY`.

The account identity in `activeDeviceStorage` must match the identity in
`linkedStorage`. The call reads
the device-authentication private key from each store and signs the link
challenge in the calling process. Thus that process must hold the active
device's store, private keys included. The adapter's `linkDevice()` gets a
challenge signer for each device and no private key.

Without `hosted.adapter`, the SDK uses the active device's stored Relay session
to submit both proofs and persists the linked device's session before synchronization.
It requests no second identity-provider assertion. Pass `hosted.adapter` to keep
an application-owned transport. That adapter needs no stored Relay session.

Retry with the same stores after an uncertain result. The SDK retains the
operation and registration material. Token renewal rebuilds both proofs without
replacing that operation. An expired replay response renews through the linked
device's key. Existing custom-adapter refusal and rollback rules still apply.

The link copies the master key of each group that the active device's group
store lists into the new device's group store. The copy runs in the calling
process, so the link sends no master key through the Relay. A client with
`groups` on the new device then fetches each copied group. The application calls
no group method for this. The link copies no protocol state, so sessions start
fresh.

A group record that a release before 12.0.0 wrote, and that the active device
has not read since, is not listed and is not copied. Read each group once on
the active device before the link to copy it. Otherwise the group initializes
on the new device from its first group message.

If a client runs on the active device during the link, pass its group store as
`activeGroupStore`, or stop that client first. The new device's store must hold
no group state. The link refuses a store that lists a group with
`HostedSignalProtocolRelayDeviceLinkError`.

The copied keys live in the new device's group store. The SDK does not move
them again. A later move of that store is the application's store move.

The new device gets its own registration ID. The link writes it into the new
device's store before it registers. A device that a 12.0.x release linked
keeps the ID that it has.

The application calls no sender-key method for the new device. A group send
gives the sender key to the listed devices of other members that have no
handoff row. A handoff row records that the Relay accepted a distribution of
the sender's key for one device. So the next group send of each other member
that lists the new device gives it that member's key. The sender's own other
devices get the sent transcript and no distribution.

## Transfer cryptographic state

<!-- doc-snippet:skip requires-external-context -->
```ts
import {
  prepareNewDeviceTransfer,
  prepareOldDeviceTransferWithBackup,
} from "@open-e2ee/signal-protocol-sdk/device";
import { getTransferDeviceInfo } from "@open-e2ee/signal-protocol-sdk/device/expo";

const device = getTransferDeviceInfo();

const receiving = await prepareNewDeviceTransfer(device);
await appQr.show(receiving.qrCode);

const sending = await prepareOldDeviceTransferWithBackup(backupStorage, device);
const backup = await sending.getBackup();
```

The QR code and the backup carry only the metadata fields that `device`
supplies. Pass `{}` to send none.

The application owns transport selection, peer confirmation, progress UI,
interruption recovery, and wiping old-device state after a successful
replacement. Do not erase the old device before the new device validates and
durably restores the backup.

## Security boundaries

- Ephemeral ECDH keys derive the transfer encryption keys.
- The SDK encrypts identity material before it reaches a relay or transport.
- Transfer bundles never contain signed prekeys, one-time prekeys, ratchet
  sessions, sender-key state, message state, or retry outbox state.
- The transfer QR code authenticates the channel only to the extent that the
  application protects what the user scans or shares.
- The managed device link sends no private key to the Relay. The process that
  calls it must hold the primary device's store.
- The SDK encrypts device names for backend storage.
- Backend authentication must bind registration, unlink, and removal to the
  owning account.
- Account reset must clear the device-ID cache, platform secret storage, and
  protocol store as one product-level lifecycle.

See the [client guide](../client/README.md), [remote guide](../remote/README.md),
and [API reference](../docs/api/README.md).
