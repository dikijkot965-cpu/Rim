# Groups

The groups module provides group identifiers, encrypted group state,
membership transitions, access-control checks, invite links, and the
`GroupManager` orchestration API.

## Why it exists

Group state has a different lifecycle from pairwise sessions. The application
backend stores opaque encrypted group state and sequences changes, while each
member device owns group secrets, decrypted state, authorization credentials,
and sender-key rotation.

## Client usage

The OpenE2EE Signal Protocol Relay supplies group authorization and encrypted
state storage. The SDK contains the group client, local cryptography, and public
transport types. Server authorization engines and credential issuers are outside
the published package.

The following advanced example composes an application-owned group transport.
Its credential callbacks request credentials from the authenticated service.

<!-- doc-snippet:skip requires-external-context -->
```ts
import {
  GroupManager,
  createGroupId,
  type GroupServer,
  type GroupStateStore,
} from "@open-e2ee/signal-protocol-sdk/groups";

const groups = new GroupManager({
  store: appGroupStore as GroupStateStore,
  server: appGroupServer as GroupServer,
  issueCredential: () => appGroupCredentials.issue(),
  credentialPublicKey,
  serverSigningPublicKey,
  aci: localAccountServiceId,
  pni: localPhoneNumberServiceId,
  issueProfileKeyCredential: (request) => appGroupCredentials.issueProfileKey(request),
  profileKeyCredentialPublicKey,
  profileKey: localProfileKey,
});

const groupId = createGroupId(rawGroupId);
const state = await groups.syncGroup(groupId);
```

The server must enforce authenticated access and version sequencing without
receiving plaintext group attributes or group master keys. Membership removal
must also invalidate or rotate group messaging state through the callbacks
required by `GroupManagerOptions`. Every `getGroup()` response must include a
baseline signature over the group ID, version, and exact encrypted-state bytes.
The client verifies that signature before installing a first or post-revocation
baseline.

Deployments whose server does not yet sign group changes must opt in explicitly
with `allowUnauthenticatedGroupHistory: true`. The SDK emits a security warning
because that mode has no authenticated group history.

See the [API reference](../docs/api/README.md) and
[security model](../docs/SECURITY.md).
