# RIM continuation handoff — Iteration 124

Current canonical source: `RIM_4.0.0_CONTINUATION_2026-11-19_ITERATION_124.zip`.

Active Supabase project: `Императорский Мессенджер` (`xxvcsaomkyknudoaixbs`). Do not switch to the inactive `Русский Императорский Мессенджер` project.

## Iteration 124 additions

- Cloudflare static-client build pipeline (`scripts/build-cloudflare.mjs`).
- `dist/` is generated from an explicit allowlist and excludes `supabase/`, migrations, tests, docs, SQL, and build scripts.
- Added `wrangler.jsonc` with `assets.directory = ./dist`.
- Added `build:cloudflare`, `deploy:cloudflare`, and `preview:cloudflare` npm scripts; Wrangler version is pinned in the command to 4.165.0.
- Added automated tests for static output isolation and Wrangler configuration.
- Added `docs/CLOUDFLARE_DEPLOYMENT.md` with distinct settings for Workers Builds, Pages, and manual uploads.
- Added CI workflow for regression verification and Cloudflare build artifact generation.

## Iteration 123 retained

- Telegram OIDC PKCE client flow and deployed `telegram-auth` Edge Function.
- Additive database migration for Telegram identity mapping and idempotent offline message replay.
- Account-scoped offline outbox with safe retry behavior.
- Telegram-first login UI and disabled Google/GitHub/VK placeholders.

## Cloudflare setup

The reported log is from Workers Builds (it runs `npx wrangler deploy`). Set root directory to repository root, build command to `npm run build:cloudflare`, deploy command to `npx wrangler deploy`. The checked-in Wrangler config serves `dist/`. If the Cloudflare project is Pages instead, set build command to `npm run build:cloudflare` and output directory to `dist`; do not run `wrangler deploy` for Pages. See `docs/CLOUDFLARE_DEPLOYMENT.md`.

The Worker name in `wrangler.jsonc` is currently `rim-messenger`; if the existing Cloudflare Worker has a different name, set it to that exact service name before deploying.

## Telegram live setup still required

Before a real Telegram login, the owner must set Supabase Edge Function Secrets `TELEGRAM_CLIENT_SECRET` and `TELEGRAM_REDIRECT_URI`, and register the exact redirect URI in BotFather. The owner must provide the deployed RIM origin + pathname to determine that URI. Never ask for the Telegram secret in chat.

## Remaining sovereignty work (not implemented yet)

- Independent RIM ID + password credentials for Telegram-created accounts.
- One-time recovery codes with server-side hashes, atomic single-use redemption, and rate limiting.
- Passkeys/WebAuthn registration and assertion verification.
- Safe linking/unlinking of provider identities with re-authentication and collision handling.
- Session/device management and provider-loss recovery tests.

Also outstanding: live Telegram login with two accounts, Playwright browser E2E, six HTML insertion review sites, individual review of existing SECURITY DEFINER functions, and a 10k-concurrency load test.

Do not rewrite the project. Continue incrementally from Iteration 124 and preserve existing behavior.
