import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');

test('Cloudflare build emits only public RIM client assets', () => {
  execFileSync(process.execPath, ['scripts/build-cloudflare.mjs'], { cwd: root, stdio: 'pipe' });
  assert.ok(fs.existsSync(path.join(dist, 'index.html')));
  assert.ok(fs.existsSync(path.join(dist, 'src/app.js')));
  assert.ok(fs.existsSync(path.join(dist, 'assets/css/rim.css')));
  assert.ok(fs.existsSync(path.join(dist, 'manifest.json')));
  for (const privateEntry of ['supabase', 'tests', 'docs', 'sql', 'scripts', 'package.json', 'wrangler.jsonc']) {
    assert.equal(fs.existsSync(path.join(dist, privateEntry)), false, `${privateEntry} must not be deployed as a public asset`);
  }
  const publicFiles = [];
  const walk = dir => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const file = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(file);
      else publicFiles.push(file);
    }
  };
  walk(dist);
  assert.ok(publicFiles.length > 100, 'expected the full modular client to be included');
  assert.equal(publicFiles.some(file => file.endsWith('.ts')), false, 'TypeScript server functions must not leak into the static bundle');
});

test('Wrangler config points at the generated static asset directory', () => {
  const config = fs.readFileSync(path.join(root, 'wrangler.jsonc'), 'utf8');
  assert.match(config, /"name"\s*:\s*"rim-messenger"/);
  assert.match(config, /"directory"\s*:\s*"\.\/dist"/);
});

test('package scripts provide separate Cloudflare build and deploy commands', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.equal(pkg.scripts['build:cloudflare'], 'node scripts/build-cloudflare.mjs');
  assert.match(pkg.scripts['deploy:cloudflare'], /build:cloudflare.*wrangler@4\.165\.0 deploy/);
});
