import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'dist');
const publicEntries = ['index.html', 'manifest.json', 'icons', 'assets', 'src'];
const forbiddenPublicEntries = ['supabase', 'tests', 'docs', 'sql', 'scripts', 'package.json', 'wrangler.jsonc', 'README.md'];

function fail(message) {
  console.error(`[cloudflare-build] ERROR: ${message}`);
  process.exitCode = 1;
}

for (const entry of publicEntries) {
  if (!fs.existsSync(path.join(root, entry))) fail(`Required public entry is missing: ${entry}`);
}
if (process.exitCode) process.exit(1);

fs.rmSync(output, { recursive: true, force: true });
fs.mkdirSync(output, { recursive: true });
for (const entry of publicEntries) {
  fs.cpSync(path.join(root, entry), path.join(output, entry), { recursive: true });
}

const html = fs.readFileSync(path.join(output, 'index.html'), 'utf8');
const localRefs = [...html.matchAll(/(?:src|href)=["']([^"']+)["']/g)]
  .map(match => match[1])
  .filter(value => !/^(?:https?:|data:|mailto:|tel:|#|\/)/i.test(value));
for (const ref of localRefs) {
  const clean = ref.split(/[?#]/, 1)[0];
  if (clean && !fs.existsSync(path.join(output, clean))) fail(`Broken local reference in index.html: ${ref}`);
}

for (const entry of forbiddenPublicEntries) {
  if (fs.existsSync(path.join(output, entry))) fail(`Server/build-only entry leaked into dist: ${entry}`);
}

const files = [];
function walk(directory, prefix = '') {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const relative = path.posix.join(prefix, entry.name);
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(absolute, relative);
    else files.push(relative);
  }
}
walk(output);
if (!files.includes('index.html')) fail('dist/index.html was not generated');
if (files.some(file => /(^|\/)(?:\.env(?:\..*)?|\.dev\.vars.*|service[_-]?role|.*secret.*)$/i.test(file))) {
  fail('Potential secret-bearing file detected in public output');
}
if (process.exitCode) process.exit(1);

console.log(`[cloudflare-build] Built ${files.length} public files into dist/`);
console.log('[cloudflare-build] Supabase Edge Functions, migrations, tests, and engineering docs are excluded.');
