# Cloudflare deployment — RIM 4.0

RIM is a static browser client backed by Supabase. `supabase/functions/**` contains Supabase Edge Functions (Deno/TypeScript); those files are not Cloudflare Worker entrypoints and must not be exposed as static website files.

## What the build does

`npm run build:cloudflare` creates `dist/` from an explicit allowlist:

- `index.html`
- `manifest.json`
- `icons/`
- `assets/`
- `src/`

It deliberately excludes Supabase functions and migrations, tests, docs, SQL files, scripts, package metadata, Wrangler config, and secrets. The build fails if required browser assets are missing or a forbidden server/build-only directory appears in the output.

## Cloudflare Workers Builds (the flow shown in the failed log)

The repository must be connected at its root. Configure the Worker under **Settings → Builds**:

| Setting | Value |
|---|---|
| Root directory | `/` (repository root) |
| Build command | `npm run build:cloudflare` |
| Deploy command | `npx wrangler deploy` |
| Preview command | `npx wrangler deploy` only if preview builds should publish; otherwise use the dashboard's preview workflow |

The checked-in `wrangler.jsonc` points Wrangler at `./dist`. The deploy command must run after the build command. Do not set the build command to `npx wrangler deploy`; that is a deploy command, not a static-site build.

The Worker name in `wrangler.jsonc` is `rim-messenger`. If the existing Cloudflare Worker has a different immutable service name, change this one `name` value to the exact Worker name before deploying; otherwise Wrangler may target a different Worker.

## Cloudflare Pages (different product / deployment path)

If the Cloudflare project is a **Pages** project rather than a **Worker with Workers Builds**, configure:

| Setting | Value |
|---|---|
| Build command | `npm run build:cloudflare` |
| Build output directory | `dist` |
| Root directory | `/` (repository root) |

Do not run `wrangler deploy` as a Pages build command. Pages deploys the output directory itself. The `wrangler.jsonc` file is for Workers Builds, not a replacement for Pages' build-output setting.

## Manual static upload

If using a dashboard static-asset uploader, upload the contents of `dist/` only. Do not upload the repository root: it intentionally contains Supabase TypeScript functions and engineering files that are not part of the public site.

## Supabase remains separate

Telegram OAuth verification remains in `supabase/functions/telegram-auth`. Deploy it with Supabase Edge Functions, not Wrangler. The browser calls the Supabase function URL. Cloudflare serves the RIM static client only.
