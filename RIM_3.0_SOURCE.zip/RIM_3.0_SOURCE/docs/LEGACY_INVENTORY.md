# Legacy inventory

The current release still carries 25 ordered classic scripts under `assets/js/legacy/`. They are retained to avoid silently dropping mature messenger features during a high-risk rewrite. This is an explicit compatibility zone, not a claim that all old code is already clean.

New feature work belongs under `src/`. The next engineering work is to migrate feature-by-feature and delete each legacy implementation after browser characterization tests pass. Do not add another wrapper to the legacy chain.
