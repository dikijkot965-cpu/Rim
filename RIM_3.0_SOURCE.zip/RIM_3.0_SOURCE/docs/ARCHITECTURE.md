# RIM 2.1 — architecture and operating model

## Honest status

This release introduces a clean, dependency-injected application core and moves new functionality into explicit modules. The historic messenger remains behind `assets/js/legacy/` as a compatibility boundary. It has not yet been fully rewritten: the legacy scripts still contain global functions and historical function replacement. Do not mistake the new folder structure for a completed strangler migration.

## Layers

- `src/core/`: Result values, domain errors, event bus, dependency container, structured logger and health registry. No Supabase or DOM business rules.
- `src/domain/`: pure rules and conversation title policy.
- `src/application/`: use cases orchestrating domain and repositories.
- `src/infrastructure/supabase/`: database adapters. RLS remains the authorization boundary.
- `src/features/`: feature-level UI modules (Favorites and local music).
- `src/compatibility/`: the only intended bridge to the old global application.
- `assets/js/legacy/`: frozen compatibility surface to be migrated incrementally. New features must not be added here.

## Dependency direction

`features/application -> domain` and `infrastructure -> domain contracts`. Domain code must not import DOM, Supabase, or legacy globals. Composition and dependency injection happen in `src/app.js`.

## Configuration and secrets

The browser contains only the Supabase publishable key. Never put `service_role` or a secret key into this static application. Browser environment variables are not secret. Privileged operations belong in Edge Functions or another trusted server environment. Authorization must be enforced by RLS/server-side checks, not UI checks.

## Error handling and observability

- Supabase adapters return explicit `{ ok, value }` / `{ ok, error }` results.
- Unexpected errors are normalized to `RimError` at boundaries.
- Logger events carry timestamp, app version and correlation ID.
- `window.RIM.diagnostics()` runs lightweight Supabase Data API and IndexedDB health checks. It is not a complete infrastructure health check.

## Performance rules

1. Paginate all potentially unbounded reads. Never fetch full message history for a chat view.
2. Query only required columns; avoid `select('*')` on high-volume tables.
3. Batch profile and attachment lookups; never perform one query per message.
4. Realtime subscriptions must be scoped to the current user's conversations and disposed when context changes.
5. Use cursor pagination `(created_at, id)` for message history.
6. Keep static assets on a CDN and enable immutable caching for hashed assets.
7. Use server-side aggregation for analytics; do not count large histories in the browser.

## 100,000 users: what this means

100,000 registered accounts and 100,000 simultaneous active connections are very different capacity targets. This code is stateless at the application boundary and is a better base for horizontal scaling, but this release does **not** certify 100,000 concurrent users. That requires a production Supabase plan and capacity review, realistic workload modelling, connection/Realtime quotas, RLS query plans, storage egress analysis, rate limits, monitoring, and load tests against a staging project. Do not run a 100k-user load test against production.

Before claiming a capacity number, test at least these independent workloads: authenticated sign-in bursts, active Realtime sockets, messages/sec, concurrent channel reads, media uploads/egress, and database p95/p99 latency. Establish target SLOs first. The current frontend cannot manufacture backend capacity by itself.

## Legacy migration plan

1. Characterize existing behavior with browser tests before changing a legacy feature.
2. Move one bounded vertical slice at a time (repository + use case + UI) into `src/`.
3. Add a compatibility adapter only at the boundary; do not create another wrapper chain.
4. Remove the legacy implementation only after tests prove feature parity.
5. Do not merge new features into `assets/js/legacy/`.

## Definition of Done

- Unit and characterization tests pass.
- No unhandled promise rejections in smoke tests.
- No missing local assets or syntax errors.
- RLS and storage policies are reviewed for any touched data path.
- Pagination, retry/timeout behavior and error messages are tested.
- Mobile viewport and keyboard interaction are tested.
- Load test is run in staging and report includes p50/p95/p99, error rate and saturation points.
- Rollback artifact is available.
