
(()=>{'use strict';function mount(){if(!document.body||document.getElementById('rimHalloweenOrnaments'))return;const layer=document.createElement('div');layer.id='rimHalloweenOrnaments';layer.innerHTML='<span class="rim-halloween-ornament one">🎃</span><span class="rim-halloween-ornament two">🕯️</span><span class="rim-halloween-ornament three">🦇</span>';document.body.appendChild(layer);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
