
/* RIM 2026-11-05: consolidated stability layer. Kept isolated for safe rollback. */
(()=>{'use strict';
 const R=window.RIM=window.RIM||{};
 const $=id=>document.getElementById(id);
 const getDb=()=>window.db||(typeof db!=='undefined'?db:null), user=()=>window.currentUser||(typeof currentUser!=='undefined'?currentUser:null), chats=()=>typeof conversations!=='undefined'?conversations:(window.conversations||[]), messages=()=>typeof messagesCache!=='undefined'?messagesCache:(window.messagesCache||[]);
 const say=s=>(window.toast||window.notify||window.notifyMsg||console.warn)(String(s??''));
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const err=e=>e?.message||String(e||'Неизвестная ошибка');
 const fmt=v=>v?new Date(v).toLocaleString('ru-RU',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'давно не заходил';

 // Favorites is an ordinary list item, not a pinned/highlighted special card.
 function normalizeFavoritesRow(){
  const list=$('chatList'); if(!list)return;
  list.querySelectorAll('#rimFavoritesRow,#rimFavoritesRowStable,[data-rim-favorites-row]').forEach(n=>n.remove());
  const row=document.createElement('div'); row.id='rimFavoritesRowStable'; row.dataset.rimFavoritesRow='1'; row.className='chat-item';
  row.innerHTML='<div class="avatar">★</div><div class="chat-item-info"><div class="chat-item-name">Избранное</div><div class="chat-item-preview">Личные заметки и документы</div></div>';
  row.addEventListener('click',()=>window.openFavorites?.()); list.appendChild(row);
 }
 const favCss=document.createElement('style'); favCss.textContent='#rimFavoritesRow,#rimFavoritesRowStable{border:0!important;background:transparent!important;box-shadow:none!important;border-radius:0!important}#rimFavoritesRow .avatar,#rimFavoritesRowStable .avatar{background:var(--panel2,rgba(255,255,255,.06))!important;color:var(--gold)!important;border:1px solid var(--border)!important}'; document.head.appendChild(favCss);
 const prevRender=window.renderConversationList;
 if(typeof prevRender==='function'&&!R.favoritesRenderer){window.renderConversationList=function(){const v=prevRender.apply(this,arguments);normalizeFavoritesRow();return v;};R.favoritesRenderer=true;}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',normalizeFavoritesRow,{once:true});else normalizeFavoritesRow();

 // Music: protect against concurrent loads, duplicate rows, and N sequential signed-URL requests.
 let musicLoadToken=0;
 window.loadMusic=async function(){
  const list=$('musicList'),d=getDb(),u=user(); if(!list||!d||!u)return;
  const token=++musicLoadToken; list.innerHTML='<div class="loading">Загружаем музыкальный каталог…</div>';
  try{
   const {data,error}=await d.from('music_tracks').select('id,user_id,title,artist,file_path,visibility,created_at').order('created_at',{ascending:false}).limit(300);
   if(error)throw error; if(token!==musicLoadToken)return;
   const unique=new Map(); for(const t of data||[]){if(!t?.id||!t.file_path)continue; const key=String(t.user_id||'')+'|'+String(t.file_path); if(!unique.has(key))unique.set(key,t);}
   const tracks=[...unique.values()];
   const signed=await Promise.all(tracks.map(async t=>{const {data:s,error:e}=await d.storage.from('music-library').createSignedUrl(t.file_path,1800);return {track:t,url:s?.signedUrl||'',error:e};}));
   if(token!==musicLoadToken)return;
   const valid=signed.filter(x=>x.url);
   if(!valid.length){list.innerHTML='<div class="empty-state">Музыкальные файлы пока недоступны. Проверьте доступ к хранилищу.</div>';return;}
   const frag=document.createDocumentFragment();
   for(const {track:t,url} of valid){const item=document.createElement('article');item.className='card';item.dataset.trackId=t.id;
    const title=document.createElement('strong');title.textContent=t.title||'Без названия';
    const meta=document.createElement('div');meta.className='muted';meta.style.cssText='font-size:12px;margin:5px 0';meta.textContent=`${t.artist||'Неизвестный исполнитель'} · ${t.visibility==='public'?'public':'private'}${t.user_id===u.id?' · Ваш трек':''}`;
    const audio=document.createElement('audio');audio.controls=true;audio.preload='none';audio.src=url;audio.style.cssText='width:100%;margin-top:8px';
    item.append(title,meta,audio);frag.appendChild(item);
   }
   list.replaceChildren(frag);
  }catch(e){if(token===musicLoadToken)list.innerHTML=`<div class="notice">Не удалось загрузить музыку: ${esc(err(e))}</div>`;}
 };

 // Forward menu was still wired to the legacy function. Route it to the working flow.
 if(typeof window.rimForwardChoose==='function')window.rimForward=window.rimForwardChoose;
 const oldMenu=window.rimMessageMenu;
 if(typeof oldMenu==='function'&&!R.forwardMenu){window.rimMessageMenu=function(id){oldMenu.apply(this,arguments);const modal=$('#modalRoot .modal');if(!modal)return;const buttons=[...modal.querySelectorAll('button')];const f=buttons.find(b=>/Переслать/.test(b.textContent||''));if(f){f.onclick=()=>{window.closeModal?.();window.rimForwardChoose?.(id);};}};R.forwardMenu=true;}


 // Copy legacy attachment columns as well as normalized attachment rows when forwarding.
 const priorForward=window.rimDoForward;
 if(typeof priorForward==='function'&&!R.forwardAttachments){window.rimDoForward=async function(id,targetId,hideSender=false){
  const d=getDb(),u=user(),m=messages().find(x=>String(x.id)===String(id));if(!m)throw new Error('Исходное сообщение не найдено.');
  const {data:member,error:me}=await d.from('conversation_members').select('conversation_id').eq('conversation_id',targetId).eq('user_id',u.id).maybeSingle();if(me)throw me;if(!member)throw new Error('Нет доступа к выбранной переписке.');
  const payload={conversation_id:targetId,sender_id:u.id,body:m.body||'',sticker_id:m.sticker_id||null,reply_to_message_id:null,forwarded_from_user_id:m.forwarded_from_user_id||m.sender_id,forwarded_from_message_id:m.forwarded_from_message_id||m.id,forwarded_hide_sender:!!hideSender};
  const copied=[];const ext=n=>{const x=String(n||'file').split('.').pop().toLowerCase();return /^[a-z0-9]{1,8}$/.test(x)?x:'bin';};
  async function clonePath(path,name){if(!path)return null;const target=u.id+'/'+targetId+'/'+crypto.randomUUID()+'.'+ext(name||path);const {error}=await d.storage.from('chat-files').copy(path,target);if(error)throw error;copied.push(target);return target;}
  try{
   if(m.image_path)payload.image_path=await clonePath(m.image_path,m.image_path);
   if(m.attachment_path){payload.attachment_path=await clonePath(m.attachment_path,m.attachment_name);for(const k of ['attachment_name','attachment_mime_type','attachment_size','attachment_kind','duration_seconds','width','height'])if(m[k]!==undefined)payload[k]=m[k];}
   const {data:created,error:ie}=await d.from('chat_messages').insert(payload).select('id').single();if(ie)throw ie;
   // Legacy normalized attachments are optional in older messages; copy them when present.
   const {data:rows,error:ae}=await d.from('chat_message_attachments').select('*').eq('message_id',m.id);
   if(!ae&&rows?.length){for(const a of rows){const path=await clonePath(a.storage_path,a.file_name);const {error:meta}=await d.from('chat_message_attachments').insert({message_id:created.id,storage_path:path,file_name:a.file_name,mime_type:a.mime_type,media_kind:a.media_kind,byte_size:a.byte_size,duration_seconds:a.duration_seconds,width:a.width,height:a.height});if(meta)throw meta;}}
   return created.id;
  }catch(e){if(copied.length)await d.storage.from('chat-files').remove(copied);throw e;}
 };R.forwardAttachments=true;}

 // Active sessions panel is not part of the product settings UI; keep app integrations intact.
 const oldSettings=window.openSettings;
 if(typeof oldSettings==='function'&&!R.settingsClean){window.openSettings=function(){const result=oldSettings.apply(this,arguments);$('#rimMySessionsCard')?.remove();return result;};R.settingsClean=true;}


 // Fast startup: do not block first paint on music catalog and signed audio URLs.
 window.initializeApp=async function(){
  const u=user();if(!u)return;if(typeof initializing!=='undefined'&&initializing)return;
  try{if(typeof initializing!=='undefined')initializing=true; if($('authScreen'))$('authScreen').classList.add('hidden');
   const jobs=[['profile',()=>window.loadProfile?.()],['settings',()=>window.loadSettings?.()],['chats',()=>window.loadConversations?.()],['channels',()=>window.loadChannels?.()]];
   const results=await Promise.allSettled(jobs.map(([,fn])=>Promise.resolve().then(fn)));
   results.forEach((r,i)=>{if(r.status==='rejected')console.warn('RIM startup '+jobs[i][0]+':',r.reason);});
   if($('chatHeadStatus'))$('chatHeadStatus').textContent='На связи';
   if(typeof window.rimTrackEvent==='function')window.rimTrackEvent('session_start',{source:'web_app'}).catch(()=>{});
   bindChatListRealtime();
  }catch(e){console.error('RIM startup:',e);say('Ошибка запуска: '+err(e));}
  finally{if(typeof initializing!=='undefined')initializing=false;}
 };

 // Global message stream updates the chat list even when another conversation is open.
 let listChannel=null;
 async function bindChatListRealtime(){
  const d=getDb(),u=user();if(!d||!u)return;
  if(listChannel){try{await d.removeChannel(listChannel)}catch(_){}listChannel=null;}
  listChannel=d.channel('rim-chat-list-'+u.id)
   .on('postgres_changes',{event:'INSERT',schema:'public',table:'chat_messages'},payload=>{
    const m=payload?.new;if(!m?.conversation_id)return;
    const rows=window.conversations||[];const c=rows.find(x=>String(x.id)===String(m.conversation_id));if(!c)return;
    c._rimLastMessageAt=m.created_at||new Date().toISOString();c._rimLastMessagePreview=m.body|| (m.image_path?'Фото/вложение':'Новое сообщение');
    rows.sort((a,b)=>new Date(b._rimLastMessageAt||b.last_message_at||b.created_at||0)-new Date(a._rimLastMessageAt||a.last_message_at||a.created_at||0));
    if(typeof window.renderConversationList==='function')window.renderConversationList();
   }).subscribe();
 }
 R.bindChatListRealtime=bindChatListRealtime;
 const oldInit=window.initializeApp;
 if(typeof oldInit==='function'&&!R.chatListRealtime){window.initializeApp=async function(){const out=await oldInit.apply(this,arguments);bindChatListRealtime();return out;};R.chatListRealtime=true;}

 // Last-seen and read ticks for direct chats. Typing remains the ephemeral Realtime broadcast.
 const oldOpen=window.openConversation;
 if(typeof oldOpen==='function'&&!R.directPresence){window.openConversation=async function(id){const result=await oldOpen.apply(this,arguments);try{
   const c=chats().find(x=>String(x.id)===String(id));if(!c||c.type!=='direct')return result;
   const d=getDb(),u=user();if(!d||!u)return result;
   const {data:members,error}=await d.from('conversation_members').select('user_id').eq('conversation_id',id).neq('user_id',u.id);
   if(error||!members?.length)return result;
   const other=members[0].user_id;const {data:p,error:pe}=await d.from('profiles').select('last_seen_at').eq('id',other).maybeSingle();
   const status=$('chatHeadStatus');if(status&&!pe)status.textContent=p?.last_seen_at?'Был(а) в сети: '+fmt(p.last_seen_at):'Время последнего посещения неизвестно';
  }catch(e){console.debug('RIM last seen:',err(e));}return result;};R.directPresence=true;}


 // Refresh outgoing read ticks when the peer advances their read cursor in Realtime.
 let readStateChannel=null,readStateConversation=null;
 async function bindReadStateRealtime(conversationId){const d=getDb();if(!d||!conversationId)return;if(readStateChannel){try{await d.removeChannel(readStateChannel)}catch(_){}readStateChannel=null;}readStateConversation=conversationId;
  readStateChannel=d.channel('rim-read-state-'+conversationId).on('postgres_changes',{event:'*',schema:'public',table:'conversation_read_state',filter:'conversation_id=eq.'+conversationId},async()=>{
   if(readStateConversation!==conversationId)return;const {data:states}=await d.from('conversation_read_state').select('last_read_at').eq('conversation_id',conversationId).neq('user_id',user()?.id);const latest=(states||[]).reduce((a,x)=>!a||new Date(x.last_read_at)>new Date(a)?x.last_read_at:a,null);
   for(const m of messages().filter(x=>x.sender_id===user()?.id)){const el=document.querySelector('.message[data-id="'+CSS.escape(String(m.id))+'"]'),tick=el?.querySelector('.rim-send-check');if(tick&&latest&&new Date(latest)>=new Date(m.created_at)){tick.textContent='✓✓';tick.title='Прочитано';}}
  }).subscribe();
 }
 const openForReadState=window.openConversation;
 if(typeof openForReadState==='function'&&!R.readStateRealtime){window.openConversation=async function(id){const result=await openForReadState.apply(this,arguments);bindReadStateRealtime(id);return result;};R.readStateRealtime=true;}
 const tickCss=document.createElement('style');tickCss.textContent='.rim-send-check{display:inline-block;margin-left:5px;color:var(--gold,#c9a45d);font-size:12px;font-weight:800;letter-spacing:-2px}';document.head.appendChild(tickCss);

 // Ensure the chat menu calls the forwarding chooser even if a legacy handler is recreated.
 document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const label=(b.textContent||'').trim();if(label==='➦ Переслать'||label==='Переслать'){const m=b.getAttribute('onclick')?.match(/rimForward\('([^']+)'\)/);if(m){e.preventDefault();e.stopImmediatePropagation();window.closeModal?.();window.rimForwardChoose?.(m[1]);}}},true);

 // Channel settings: resolve the channel from the rendered channel page if global state was lost.
 const oldChannelSettings=window.rimOpenChannelSettings;
 if(typeof oldChannelSettings==='function'&&!R.channelSettings){window.rimOpenChannelSettings=async function(){let c=window.currentChannel; if(!c&&window.__rimCurrentChannelId){const {data}=await getDb().from('channels').select('*').eq('id',window.__rimCurrentChannelId).maybeSingle();c=data;}
   if(!c){const full=$('rimChannelFull');const id=full?.dataset?.channelId;if(id){const {data}=await getDb().from('channels').select('*').eq('id',id).maybeSingle();c=data;}}
   if(c){window.currentChannel=c;try{currentChannel=c}catch(_){} }
   if(!c)return say('Не удалось определить открытый канал. Закройте канал и откройте его снова.');
   return oldChannelSettings.apply(this,arguments);
  };R.channelSettings=true;}

 // Sent tick is immediate; read tick is promoted to double when peer read cursor passes it.
 const renderWithTicks=window.renderMessages;
 if(typeof renderWithTicks==='function'&&!R.messageTicks){window.renderMessages=async function(){await renderWithTicks.apply(this,arguments);const own=messages().filter(m=>m.sender_id===user()?.id);for(const m of own){const el=document.querySelector('.message[data-id="'+CSS.escape(String(m.id))+'"]');const meta=el?.querySelector('.message-meta');if(meta){meta.querySelector('.rim-read-check')?.remove();if(!meta.querySelector('.rim-send-check'))meta.insertAdjacentHTML('beforeend','<span class="rim-send-check" title="Отправлено">✓</span>');}}
   const c=window.activeConversation;if(c){const d=getDb();const {data:states}=await d.from('conversation_read_state').select('last_read_at').eq('conversation_id',c.id).neq('user_id',user()?.id);const latest=(states||[]).reduce((a,x)=>!a||new Date(x.last_read_at)>new Date(a)?x.last_read_at:a,null);if(latest){for(const m of own){if(new Date(latest)>=new Date(m.created_at)){const el=document.querySelector('.message[data-id="'+CSS.escape(String(m.id))+'"]'),meta=el?.querySelector('.message-meta'),tick=meta?.querySelector('.rim-send-check');if(tick){tick.textContent='✓✓';tick.title='Прочитано';}}}}}
  };R.messageTicks=true;}

 console.info('[RIM] stability layer loaded');
})();

