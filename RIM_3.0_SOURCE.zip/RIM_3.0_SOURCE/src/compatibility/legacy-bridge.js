/** Единственная граница совместимости со старым интерфейсом. Новый код не обращается к legacy-глобалам напрямую. */
export function createLegacyBridge(context) {
  const required = ['db', 'getUser'];
  for (const key of required) if (!context[key]) throw new Error(`Legacy bridge missing: ${key}`);
  return Object.freeze({ db: context.db, getUser: context.getUser, getConversations: context.getConversations, getActiveConversation: context.getActiveConversation, notify: context.notify });
}
