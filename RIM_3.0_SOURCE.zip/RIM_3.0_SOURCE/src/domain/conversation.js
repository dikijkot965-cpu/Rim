export const isDirectConversation = conversation => conversation?.type === 'direct';
export const displayConversationTitle = (conversation, peer) => {
  if (isDirectConversation(conversation)) return peer?.display_name?.trim() || peer?.username?.trim() || conversation?.title?.trim() || 'Личные сообщения';
  return conversation?.title?.trim() || 'Групповая беседа';
};
