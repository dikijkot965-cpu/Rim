import { Err, Ok } from '../../core/result.js';

export class ConversationRepository {
  constructor(client) { this.client = client; }

  async getDirectPeers(conversationIds, currentUserId) {
    const ids = [...new Set((conversationIds || []).filter(Boolean).map(String))];
    if (!ids.length || !currentUserId) return Ok({});

    const members = await this.client.from('conversation_members')
      .select('conversation_id,user_id')
      .in('conversation_id', ids);
    if (members.error) return Err(members.error);

    const peerByConversation = new Map();
    for (const row of members.data || []) {
      if (String(row.user_id) === String(currentUserId)) continue;
      if (!peerByConversation.has(String(row.conversation_id))) {
        peerByConversation.set(String(row.conversation_id), String(row.user_id));
      }
    }
    const peerIds = [...new Set(peerByConversation.values())];
    if (!peerIds.length) return Ok({});

    // Read public profile fields first. Do not even request last_seen_at for
    // people who disabled online visibility.
    const profiles = await this.client.from('profiles')
      .select('id,username,display_name,avatar_url,avatar_path,show_online')
      .in('id', peerIds);
    if (profiles.error) return Err(profiles.error);

    const byId = new Map((profiles.data || []).map(profile => [String(profile.id), {
      ...profile,
      showOnline: profile.show_online === true,
      last_seen_at: null
    }]));
    const visibleIds = [...byId.values()].filter(profile => profile.showOnline).map(profile => profile.id);
    if (visibleIds.length) {
      const presence = await this.client.from('profiles')
        .select('id,last_seen_at')
        .in('id', visibleIds);
      if (presence.error) return Err(presence.error);
      for (const row of presence.data || []) {
        const profile = byId.get(String(row.id));
        if (profile) profile.last_seen_at = row.last_seen_at || null;
      }
    }

    const result = {};
    for (const [conversationId, peerId] of peerByConversation) {
      result[conversationId] = byId.get(peerId) || null;
    }
    return Ok(result);
  }

  async getDirectPeer(conversationId, currentUserId) {
    const result = await this.getDirectPeers([conversationId], currentUserId);
    if (!result.ok) return result;
    return Ok(result.value[String(conversationId)] || null);
  }
}
