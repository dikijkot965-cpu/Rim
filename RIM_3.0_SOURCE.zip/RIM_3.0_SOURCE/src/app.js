import { Container } from './core/container.js';
import { EventBus } from './core/event-bus.js';
import { Logger } from './core/logger.js';
import { HealthRegistry } from './core/health.js';
import { ConversationRepository } from './infrastructure/supabase/conversation-repository.js';
import { resolveChatHeader } from './application/resolve-chat-header.js';
import { FavoritesWorkspace } from './features/favorites-workspace.js';
import { LocalMusicLibrary } from './features/local-music.js';
import { LiteWriterWorkspace } from './features/lite-writer.js';
import { createLegacyBridge } from './compatibility/legacy-bridge.js';

const context = window.__RIM_LEGACY_CONTEXT;
if (!context?.db) throw new Error('RIM bootstrap: legacy database client is unavailable');
const legacy = createLegacyBridge(context);
const container = new Container();
const logger = new Logger({ version: '3.0.0' });
const events = new EventBus();
const health = new HealthRegistry();
container.value('db', legacy.db).value('logger', logger).value('events', events).value('health', health);
container.factory('conversationRepository', c => new ConversationRepository(c.get('db')));
const favorites = new FavoritesWorkspace({ db: legacy.db, getUser: legacy.getUser, writer: () => window.rimOpenWriter?.(), logger });
const writer = new LiteWriterWorkspace({ db: legacy.db, getUser: legacy.getUser, logger });
const musicRoot = document.createElement('div'); musicRoot.id = 'rimLocalMusicRoot'; document.body.append(musicRoot);
const music = new LocalMusicLibrary({ root: musicRoot, logger });
health.register('supabase-data-api', async () => { const { error } = await legacy.db.from('profiles').select('id').limit(1); if (error) throw error; });
health.register('local-indexeddb', async () => { if (!('indexedDB' in window)) throw new Error('IndexedDB unavailable'); });

window.RIM = Object.freeze({ version: '3.0.0', container, events, logger, health, features: Object.freeze({ favorites, music, writer }), diagnostics: async () => health.run() });

// Direct-message identity is resolved before and after the legacy loader.
const repository = container.get('conversationRepository');
const avatarUrlFor = async peer => {
  if (peer?.avatar_url && /^https:\/\//i.test(peer.avatar_url)) return peer.avatar_url;
  if (peer?.avatar_path) {
    try {
      const { data, error } = await legacy.db.storage.from('avatars').createSignedUrl(peer.avatar_path, 1800);
      if (!error && data?.signedUrl) return data.signedUrl;
    } catch (error) { logger.warn('chat.avatar.sign.failed', { message: error?.message }); }
  }
  return null;
};
const applyPeerAvatar = async (node, peer, fallback = 'П') => {
  if (!node) return;
  const src = await avatarUrlFor(peer);
  if (!node.isConnected) return;
  node.replaceChildren();
  if (src) {
    const img = document.createElement('img');
    img.src = src; img.alt = ''; img.loading = 'lazy'; img.referrerPolicy = 'no-referrer';
    img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:inherit';
    node.append(img);
  } else node.textContent = (fallback || 'П').trim().slice(0, 1).toUpperCase();
};

async function enrichConversationList() {
  const chats = legacy.getConversations?.() || [];
  const user = legacy.getUser();
  if (!user || !chats.length) return;
  const direct = chats.filter(chat => chat?.type === 'direct');
  const unresolved = direct.filter(chat => !chat.other_profile && !chat.peer_profile);
  if (unresolved.length) {
    const result = await repository.getDirectPeers(unresolved.map(chat => chat.id), user.id);
    if (result.ok) {
      for (const chat of unresolved) {
        const peer = result.value[String(chat.id)];
        if (peer) chat.other_profile = peer;
      }
    } else logger.warn('chat.list.peers.failed', { message: result.error?.message });
  }

  const list = document.getElementById('chatList');
  if (!list) return;
  for (const item of list.querySelectorAll('.chat-item[onclick*="openConversation"]')) {
    const match = item.getAttribute('onclick')?.match(/openConversation\(['"]([^'"]+)['"]\)/);
    if (!match) continue;
    const chat = chats.find(value => String(value.id) === String(match[1]));
    if (!chat || chat.type !== 'direct') continue;
    const peer = chat.other_profile || chat.peer_profile || null;
    const title = peer?.display_name?.trim() || peer?.username?.trim() || chat.title || 'Личные сообщения';
    const name = item.querySelector('.chat-item-name');
    if (name) name.textContent = title;
    const avatar = item.querySelector('.avatar');
    if (avatar && avatar.dataset.peerId !== String(peer?.id || '')) {
      avatar.dataset.peerId = String(peer?.id || '');
      await applyPeerAvatar(avatar, peer, title);
    }
    const preview = item.querySelector('.chat-item-preview');
    if (preview && !preview.dataset.rimPeerPreview) {
      preview.textContent = peer?.username ? `@${peer.username}` : 'Личная переписка';
      preview.dataset.rimPeerPreview = '1';
    }
  }
}

const originalRenderConversationList = window.renderConversationList;
if (typeof originalRenderConversationList === 'function' && !window.__rimConversationListV30) {
  window.__rimConversationListV30 = true;
  window.renderConversationList = function (...args) {
    const result = originalRenderConversationList.apply(this, args);
    enrichConversationList().catch(error => logger.warn('chat.list.enrich.failed', { message: error?.message }));
    return result;
  };
}

const originalOpenConversation = window.openConversation;
if (typeof originalOpenConversation === 'function' && !window.__rimOpenConversationV30) {
  window.__rimOpenConversationV30 = true;
  window.openConversation = async function (id, ...args) {
    if (document.getElementById('rimWorkspaceOverlay')) {
      try { await writer.closeForNavigation(); }
      catch (error) { logger.error('writer.flush.before.navigation.failed', error); return; }
    }
    favorites.close();
    const result = await originalOpenConversation.call(this, id, ...args);
    try {
      const state = context.getActiveConversation();
      if (state?.type === 'direct') {
        // Paint cached identity immediately; refresh the profile asynchronously below.
        const cachedPeer = state.other_profile || state.peer_profile || null;
        const cachedTitle = cachedPeer?.display_name?.trim() || cachedPeer?.username?.trim() || state.title || 'Личные сообщения';
        const titleNode = document.getElementById('chatHeadName');
        if (titleNode) titleNode.textContent = cachedTitle;
        const avatarNode = document.getElementById('chatHeadAvatar');
        await applyPeerAvatar(avatarNode, cachedPeer, cachedTitle);

        const resolved = await resolveChatHeader({ conversation: state, user: legacy.getUser(), repository, logger });
        const current = context.getActiveConversation();
        if (String(current?.id) !== String(state.id)) return result;
        if (titleNode) titleNode.textContent = resolved.title;
        const status = document.getElementById('chatHeadStatus');
        const seenAt = resolved.peer?.last_seen_at ? new Date(resolved.peer.last_seen_at) : null;
        const visible = resolved.peer?.showOnline === true || resolved.peer?.show_online === true;
        const validSeen = seenAt && Number.isFinite(seenAt.getTime()) && seenAt.getTime() <= Date.now();
        const online = visible && validSeen && (Date.now() - seenAt.getTime() < 120000);
        if (status) status.textContent = !visible ? 'Статус скрыт' : (online ? 'В сети' : (validSeen ? `Был(а) в сети ${seenAt.toLocaleString('ru-RU')}` : 'Время посещения неизвестно'));
        await applyPeerAvatar(avatarNode, resolved.peer, resolved.title);
        events.emit('chat.opened', { conversation: state, peer: resolved.peer });
      }
    } catch (error) { logger.error('chat.header.resolve.failed', error, { conversationId: id }); }
    return result;
  };
}

// Lite Writer is now a first-party feature module; it does not depend on a CDN editor bundle.
window.rimOpenWriter = async () => {
  try { await writer.open(); }
  catch (error) { logger.error('writer.open.failed', error); alert(`Не удалось открыть Lite Writer: ${error?.message || error}`); }
};
window.rimSaveDocument = () => writer.save();
window.rimNewDocument = () => writer.newDocument();
window.rimSelectDocument = id => writer.select(id);
window.rimWriterBack = () => writer.back();

// Favorites is one ordinary row; keep its existing visual identity, change only the inner workspace.
window.openFavorites = async () => {
  if (writer.root?.isConnected) await writer.closeForNavigation();
  favorites.mount();
};
window.rimSaveMessageToFavorites = async id => {
  const messages = context.getMessages?.() || [];
  const message = messages.find(item => item.id === id);
  if (!message) { alert('Сообщение не найдено в текущей переписке.'); return; }
  await favorites.saveMessage(message);
};

// Add a compact save action to each rendered message; event delegation keeps listener count constant.
const messagesRoot = document.getElementById('messages');
if (messagesRoot && !messagesRoot.dataset.rimSaveBound) {
  messagesRoot.dataset.rimSaveBound = '1';
  const addSaveButtons = () => messagesRoot.querySelectorAll('.message[data-id]:not([data-rim-save-ready])').forEach(node => {
    node.dataset.rimSaveReady = '1'; const button = document.createElement('button'); button.type = 'button'; button.className = 'rim-save-message-btn'; button.textContent = '☆'; button.title = 'Сохранить в Избранное'; button.dataset.rimSave = node.dataset.id; node.append(button);
  });
  new MutationObserver(addSaveButtons).observe(messagesRoot, { childList: true, subtree: true }); addSaveButtons();
  messagesRoot.addEventListener('click', event => { const button = event.target.closest('[data-rim-save]'); if (button) { event.preventDefault(); event.stopPropagation(); window.rimSaveMessageToFavorites(button.dataset.rimSave); } });
}

// Local-only music: file selection is always user initiated; browsers do not permit silent phone-library scanning.
const musicButton = document.getElementById('tabMusic');
if (musicButton) {
  musicButton.removeAttribute('onclick');
  musicButton.addEventListener('click', event => { event.preventDefault(); event.stopImmediatePropagation(); document.getElementById('app')?.classList.add('rim-feature-hidden'); music.render(); }, true);
}

logger.info('app.ready', { modules: ['core', 'supabase-adapter', 'chat-identity', 'favorites', 'lite-writer', 'local-music'] });
window.dispatchEvent(new CustomEvent('rim:ready', { detail: { version: '3.0.0' } }));
