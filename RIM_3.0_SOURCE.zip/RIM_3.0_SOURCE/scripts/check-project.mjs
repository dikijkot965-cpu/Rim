import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const files = [];
function walk(dir) { for (const entry of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, entry.name); if (entry.isDirectory()) walk(p); else if (p.endsWith('.js') || p.endsWith('.mjs')) files.push(p); } }
walk(path.join(root, 'src')); walk(path.join(root, 'scripts')); walk(path.join(root, 'tests'));
let failed = false;
for (const file of files) { const source = fs.readFileSync(file, 'utf8'); if (/\b(eval|new Function)\s*\(/.test(source)) { console.error('Forbidden dynamic execution:', path.relative(root, file)); failed = true; } }
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
for (const match of html.matchAll(/(?:src|href)="([^"]+)"/g)) { const ref = match[1]; if (/^(https?:|#|data:|\/)/.test(ref)) continue; const target = path.join(root, ref); if (!fs.existsSync(target)) { console.error('Missing local asset:', ref); failed = true; } }
if (failed) process.exit(1); console.log(`Project check passed: ${files.length} JS files; local HTML assets resolved.`);
